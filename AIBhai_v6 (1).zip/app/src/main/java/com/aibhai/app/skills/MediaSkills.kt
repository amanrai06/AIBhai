package com.aibhai.app.skills

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import com.aibhai.app.Prefs
import com.aibhai.app.core.ActionLog
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Txt
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL

// =================================================================== DOWNLOAD via VidMate (or any downloader app)

/**
 * "Arijit Singh ka ye song download kar do (audio)"
 * Flow: link from clipboard OR from the app on screen (Share → VidMate / Copy link) → VidMate → pick quality → Download → verify.
 * Every step is reported. Asks for quality if not told (missing data → stop & ask).
 */
object DownloadSkill : Skill {
    private val linkRe = Regex("https?://\\S+")

    override fun matches(c: Cmd, env: Env): Boolean {
        if (c.has("vidmate", "vid mate", "snaptube")) return true
        if (!Regex("\\b(download|dawnload|downlod|downlode)\\b").containsMatchIn(c.norm) && !c.raw.contains("डाउनलोड")) return false
        if (c.has("organize", "organise", "sort", "folder", "pdf", "file", "files", "update", "notes")) return false
        return c.has("song", "gaana", "gana", "gaane", "video", "reel", "audio", "mp3", "ye", "isko", "isse", "link", "youtube", "insta", "movie", "status", "chal raha", "sun raha", "dekh raha") ||
            linkRe.containsMatchIn(c.raw)
    }

    fun downloaderPkg(ctx: Context): Pair<String, String>? {
        val pm = ctx.packageManager
        val pref = Prefs(ctx).downloaderPkg
        @Suppress("DEPRECATION")
        val apps = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { Pair(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
        if (pref.isNotBlank()) apps.firstOrNull { it.first == pref }?.let { return it }
        return apps.firstOrNull { it.second.lowercase().contains("vidmate") || it.first.contains("vidmate") }
            ?: apps.firstOrNull { it.second.lowercase().contains("snaptube") }
    }

    private fun clipboardLink(ctx: Context): String? = try {
        val cm = ctx.getSystemService(ClipboardManager::class.java)
        val t = cm?.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
        linkRe.find(t)?.value
    } catch (e: Exception) {
        null
    }

    /** "audio" or e.g. "720" ; null = ask */
    private fun quality(c: Cmd): String? {
        Regex("(144|240|360|480|720|1080|1440|2160)\\s*p?").find(c.norm)?.let { return it.groupValues[1] }
        if (c.has("4k")) return "2160"
        if (c.has("full hd", "hd")) return "720"
        if (c.has("mp3", "audio", "awaaz", "sirf gaana", "only audio", "m4a", "music")) return "audio"
        if (c.has("video")) return "720"
        if (c.has("song", "gaana", "gana", "gaane")) return "audio"
        return null
    }

    override suspend fun run(c: Cmd, env: Env): Reply = runWith(c, env, linkRe.find(c.raw)?.value)

    suspend fun runWith(c: Cmd, env: Env, givenLink: String?): Reply {
        val dl = downloaderPkg(env.ctx) ?: return c.reply(
            "📥 Phone mein VidMate (ya koi downloader) nahi mila. Install karke dobara bolo.",
            "📥 No VidMate/downloader app found.",
            kind = Kind.WARN, status = "needs_input"
        )
        val q = quality(c) ?: return c.reply(
            "🎚️ Kaunsi quality chahiye?", "🎚️ Which quality?",
            speakHi = "Audio chahiye ya video? Quality chuno.", speakEn = "Audio or video? Pick a quality.",
            kind = Kind.INFO, status = "needs_input",
            actions = listOf(
                ReplyAction("🎵 Audio (MP3)") { runWith(Cmd(c.raw + " audio", c.norm + " audio"), env, givenLink) },
                ReplyAction("🎬 Video 720p") { runWith(Cmd(c.raw + " 720p", c.norm + " 720p"), env, givenLink) },
                ReplyAction("🎬 Video 360p") { runWith(Cmd(c.raw + " 360p", c.norm + " 360p"), env, givenLink) }
            )
        )
        val qLabel = if (q == "audio") "Audio (MP3)" else "Video ${q}p"
        if (!PhoneControl.enabled) {
            return c.reply(
                "🤖 Download automation ke liye Settings → 'Phone control (Accessibility)' ON karo.",
                "🤖 Turn on Phone control (Accessibility) first.",
                kind = Kind.WARN, status = "needs_input",
                actions = listOf(ReplyAction(c.t("Accessibility kholo", "Open Accessibility")) { PhoneControl.openSettings(env.ctx); null })
            )
        }
        val steps = ArrayList<String>()
        // 1) link: given > clipboard (AIBhai is in front, so it may read the clipboard)
        var link = givenLink ?: clipboardLink(env.ctx)
        env.hideUi()
        delay(900)
        if (link != null) {
            steps.add("🔗 Link mila: ${Txt.short(link, 50)}")
            env.launch(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, link).setPackage(dl.first))
                .also { if (!it) env.launch(env.ctx.packageManager.getLaunchIntentForPackage(dl.first) ?: Intent()) }
            steps.add("📤 ${dl.second} ko bheja")
        } else {
            // 2) from the app on screen: Share → VidMate, else Copy link → open VidMate (it detects copied links)
            val src = PhoneControl.currentPackage()
            steps.add("📱 Screen pe app: ${src.substringAfterLast('.')}")
            val shared = waitClick(listOf("Share", "शेयर", "Send")) != null
            if (!shared) {
                return report(c, env, steps + "⚠️ 'Share' button nahi mila — video/gaana khol ke dobara bolo, ya link copy karke bolo.", false, qLabel)
            }
            steps.add("👆 Share dabaya")
            delay(1200)
            var viaSheet = waitClick(listOf(dl.second, "VidMate"), tries = 4) != null
            if (!viaSheet) {
                PhoneControl.scroll(true)
                delay(500)
                viaSheet = waitClick(listOf(dl.second, "VidMate"), tries = 3) != null
            }
            if (viaSheet) {
                steps.add("📤 Share sheet se ${dl.second} chuna")
            } else {
                val copied = waitClick(listOf("Copy link", "Copy", "लिंक कॉपी करें", "कॉपी"), tries = 4) != null
                if (!copied) return report(c, env, steps + "⚠️ Share sheet mein ${dl.second} ya 'Copy link' nahi mila.", false, qLabel)
                steps.add("📋 Link copy kiya")
                delay(600)
                env.launch(env.ctx.packageManager.getLaunchIntentForPackage(dl.first) ?: Intent())
                steps.add("🚀 ${dl.second} khola (copied link detect karega)")
            }
        }
        // 3) in VidMate: open download dialog, pick quality, download
        delay(2500)
        waitClick(listOf("Download", "डाउनलोड", "Download now"), tries = 6)?.let { steps.add("⬇️ Download options khule") }
        delay(1200)
        val picked = pickQuality(q)
        if (picked != null) steps.add("🎚️ Quality chuni: $picked") else steps.add("⚠️ '$qLabel' option nahi mila — jo default tha wahi chalega")
        delay(600)
        val started = waitClick(listOf("Download", "डाउनलोड", "OK", "Start"), tries = 5) != null
        delay(1500)
        val screen = PhoneControl.screenText().joinToString(" ").lowercase()
        val verified = started && Regex("download(ing|ed)?|queue|%|added|started|डाउनलोड").containsMatchIn(screen)
        steps.add(if (verified) "✅ Download shuru ho gaya (screen pe confirm)" else if (started) "🟡 Download dabaya, confirm nahi ho paya — VidMate ki Downloads list check karo" else "❌ Download button nahi mila")
        return report(c, env, steps, verified, qLabel)
    }

    private fun report(c: Cmd, env: Env, steps: List<String>, ok: Boolean, qLabel: String): Reply {
        ActionLog.add(env.ctx, c.raw, "Download", steps.lastOrNull() ?: "", if (ok) "verified" else "failed")
        return c.reply(
            if (ok) "📥 Download chalu — $qLabel ✓" else "📥 Download poora nahi ho paya",
            if (ok) "📥 Download started — $qLabel ✓" else "📥 Couldn't finish the download",
            speakHi = if (ok) "Download shuru ho gaya, $qLabel mein." else "Download mein dikkat aayi, details screen pe hain.",
            speakEn = if (ok) "Download started." else "Download had a problem.",
            kind = if (ok) Kind.SUCCESS else Kind.WARN, status = if (ok) "verified" else "failed",
            items = steps + listOf("ℹ️ Sirf wahi download karo jiski permission ho (copyright).")
        )
    }

    private suspend fun waitClick(labels: List<String>, tries: Int = 8): String? {
        repeat(tries) {
            for (l in labels) PhoneControl.click(l)?.let { return it }
            delay(450)
        }
        return null
    }

    private suspend fun pickQuality(q: String): String? {
        repeat(6) {
            val texts = PhoneControl.screenText()
            if (q == "audio") {
                val a = texts.firstOrNull { Regex("\\bmp3\\b", RegexOption.IGNORE_CASE).containsMatchIn(it) }
                    ?: texts.firstOrNull { Regex("m4a|audio|music", RegexOption.IGNORE_CASE).containsMatchIn(it) }
                if (a != null && PhoneControl.click(a) != null) return a
            } else {
                val want = q.toInt()
                val opts = texts.mapNotNull { t -> Regex("(\\d{3,4})\\s*[pP]").find(t)?.groupValues?.get(1)?.toIntOrNull()?.let { Pair(t, it) } }
                val best = opts.filter { it.second <= want }.maxByOrNull { it.second } ?: opts.minByOrNull { it.second }
                if (best != null && PhoneControl.click(best.first) != null) return best.first
            }
            delay(500)
        }
        return null
    }
}

// =================================================================== STORY / CAPTION IDEAS FROM A PHOTO

object CaptionBridge {
    @Volatile
    var pending: CompletableDeferred<Pair<List<String>, Uri?>>? = null
}

object CaptionSkill : Skill {
    override fun matches(c: Cmd, env: Env): Boolean =
        c.has("caption", "captions") ||
            (c.has("story", "status", "post", "bio", "reel") && c.has("likhu", "likhun", "kya likhe", "kya likhna", "line", "lines", "idea", "ideas", "suggest", "shayari", "quote", "kya daalu", "kya dalu", "what to write"))

    private val themeOf = linkedMapOf(
        "nature" to listOf("sky", "cloud", "plant", "flower", "mountain", "sunset", "lake", "tree", "beach", "sea", "river", "grass", "leaf", "garden", "rainbow", "field"),
        "food" to listOf("food", "dessert", "cuisine", "pizza", "cake", "tea", "coffee", "drink", "fruit", "meal", "snack", "cookie"),
        "ride" to listOf("car", "vehicle", "motorcycle", "bike", "wheel", "bicycle", "scooter", "tire", "road", "helmet"),
        "friends" to listOf("team", "crowd", "event", "party", "fun", "concert", "stadium", "group"),
        "pet" to listOf("dog", "cat", "pet", "bird", "animal", "cow", "horse"),
        "study" to listOf("paper", "book", "desk", "computer", "laptop", "pen", "notebook", "whiteboard", "text"),
        "night" to listOf("night", "darkness", "moon", "star", "lights", "neon"),
        "festival" to listOf("fireworks", "candle", "lamp", "diya", "temple", "rangoli"),
        "selfie" to listOf("smile", "selfie", "person", "beard", "hair", "eyelash", "sunglasses", "jacket", "shirt", "jeans", "cool", "muscle")
    )

    private val byTheme = mapOf(
        "nature" to listOf("Kudrat ka apna filter 🌿✨", "Sukoon wahi jahan network kam aur nazare zyada ⛰️", "Aasmaan bhi aaj mere mood jaisa hai ☁️💙", "Thoda break, thodi hawa, bahut saara sukoon 🍃", "Nature mode: ON 🌄"),
        "food" to listOf("Diet kal se, aaj sirf swaad 😋", "Pehle khaana, phir duniya 🍽️", "Chai + mood = perfect combo ☕💛", "Pet bhara, dil khush 🤤", "Foodie hoon, pareshan mat karo 🍕"),
        "ride" to listOf("Road mera, rules mere, safety pehle 🏍️", "Sapne bade aur raste lambe 🛣️", "Engine se zyada josh mere andar hai 🔥", "Future electric, irade fantastic ⚡🚗", "Har mod pe naya scene 🛵"),
        "friends" to listOf("Dost kam hain, par sab ek number ke 🤝", "Ye gang hi meri asli property hai 😎", "Yaadein banane ka kaam chal raha hai 📸", "Pagal log, par apne log ❤️", "Squad goals achieved ✅"),
        "pet" to listOf("Isse zyada wafadaar koi nahi 🐾", "Mera stress buster aa gaya 🐶", "Cuteness overload 🥹", "Sabse sachcha dost, bina shart 💛"),
        "study" to listOf("Abhi mehnat, baad mein maze 📚", "Engineer ban raha hoon, dheere dheere ⚙️", "Notes kam, sapne zyada 😅📖", "Grind mode ON 🔥", "Exam ke baad milte hain 👋"),
        "night" to listOf("Raatein lambi, khayal gehre 🌙", "City lights aur thoda sa sukoon ✨", "Chaand bhi jaag raha hai mere saath 🌕", "Night mode: ON 🌃"),
        "festival" to listOf("Roshni, mithai aur apno ka saath 🪔", "Tyohaar ka asli maza family ke saath 🎉", "Har din aisa hi jagmagata rahe ✨"),
        "selfie" to listOf("Main jaisa hoon, waisa hi best hoon 😎", "Smile free hai, isliye bahut deta hoon 😁", "Khud pe bharosa, baaki sab khuda pe ✨", "New day, same swag 🔥", "Simple hoon, par special hoon 💫")
    )

    private val byTone = mapOf(
        "attitude" to listOf("Mera time aayega nahi, main laaunga 🔥", "Log baatein karte hain, hum kaam 😎", "Copy karna hai to karo, level kaise laoge? 👑", "Shaant hoon, kamzor nahi 🦁", "Apni race, apna pace 🏁"),
        "funny" to listOf("Smart kaam karta hoon, isliye aaraam bhi karta hoon 😴", "Mere andar talent bahut hai, bas bahar nahi aata 😂", "Padhai kal se, ye promise pichle saal ka hai 🤡", "Main late nahi, baaki sab jaldi aa jaate hain ⏰😅", "Dimaag full charge, dil 10% pe 🔋😂"),
        "sad" to listOf("Kuch baatein samajh aati hain, par samjhai nahi jaati 🥀", "Muskurahat bhi kabhi kabhi parda hoti hai 🙂", "Waqt sab theek kar deta hai, intezaar hai ⏳", "Khamoshi bhi bahut kuch kehti hai 🌙"),
        "love" to listOf("Tum ho to har din khaas hai ❤️", "Dil ne kaha, tum hi ho 💞", "Sabse pyaari jagah: tumhari muskaan 😊", "Kuch log dil mein ghar kar jaate hain 🏡❤️"),
        "motivational" to listOf("Mehnat itni khamoshi se karo ki safalta shor macha de 💪", "Aaj ka dard, kal ki taakat 🔥", "Sapne wo nahi jo sote waqt aaye, wo jo sone na de ⚡", "Har din 1% better 📈", "Haar tab hoti hai jab maan lo ⛰️"),
        "festival" to listOf("Khushiyan baanto, double ho jaati hain 🎉", "Roshni andar bhi, bahar bhi 🪔"),
        "english" to listOf("Making memories, one frame at a time 📸", "Good vibes only ✨", "Less perfection, more authenticity 💯", "Chasing dreams, not people 🚀", "Built different ⚡")
    )

    private fun tone(c: Cmd): String? = when {
        c.has("attitude", "swag", "rob", "dabang") -> "attitude"
        c.has("funny", "comedy", "mazedaar", "hasi", "majak", "mazak") -> "funny"
        c.has("sad", "dukhi", "udaas", "broken") -> "sad"
        c.has("love", "pyaar", "pyar", "romantic", "gf", "bf") -> "love"
        c.has("motivation", "motivational", "gym", "mehnat", "success", "inspire") -> "motivational"
        c.has("diwali", "holi", "festival", "tyohar", "tyohaar", "eid") -> "festival"
        c.has("english") -> "english"
        else -> null
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val d = CompletableDeferred<Pair<List<String>, Uri?>>()
        CaptionBridge.pending = d
        val camera = c.has("camera", "photo khicho", "photo lo", "abhi ki photo")
        env.launch(Intent(env.ctx, PhotoActivity::class.java).putExtra("gallery", !camera).putExtra("mode", "label"))
        val res = withTimeoutOrNull(240_000) { d.await() }
        CaptionBridge.pending = null
        if (res == null || res.second == null) return c.reply("📷 Photo select nahi hui.", "📷 No photo selected.", kind = Kind.WARN, status = "cancelled")
        return captions(c, env, res.first, res.second)
    }

    suspend fun captions(c: Cmd, env: Env, labels: List<String>, uri: Uri?, seed: Int = 0): Reply {
        val tn = tone(c)
        val low = labels.map { it.lowercase() }
        val themes = themeOf.entries.map { (t, keys) -> Pair(t, keys.count { k -> low.any { it.contains(k) } }) }
            .filter { it.second > 0 }.sortedByDescending { it.second }.map { it.first }
        // 1) Smart: PC brain with a vision model (free, local) if configured
        val ai = if (uri != null) visionCaptions(env, uri, c.raw, tn) else null
        val pool = LinkedHashSet<String>()
        ai?.forEach { pool.add(it) }
        val rnd = java.util.Random((labels.hashCode() + seed).toLong())
        if (tn != null) byTone[tn]?.shuffled(rnd)?.take(2)?.forEach { pool.add(it) }
        themes.take(2).forEach { t -> byTheme[t]?.shuffled(rnd)?.take(2)?.forEach { pool.add(it) } }
        if (pool.size < 4) (byTone["english"] ?: emptyList()).shuffled(rnd).forEach { if (pool.size < 4) pool.add(it) }
        val four = pool.take(4)
        val seen = labels.take(5).joinToString(", ").ifBlank { "photo" }
        return c.reply(
            "✍️ Story ke liye ${four.size} options" + (if (tn != null) " ($tn)" else "") + "\n👀 Photo mein: $seen",
            "✍️ ${four.size} caption ideas" + (if (tn != null) " ($tn)" else "") + "\n👀 Seen: $seen",
            speakHi = "Ye ${four.size} options hain. Pehla: ${four.firstOrNull() ?: ""}", speakEn = "Here are ${four.size} options.",
            kind = Kind.SUCCESS,
            items = four.mapIndexed { i, s -> "${i + 1}. $s" } + listOf("💡 Mood bolke try karo: attitude / funny / sad / love / motivational / english"),
            actions = four.mapIndexed { i, s ->
                ReplyAction("📋 Copy ${i + 1}") {
                    env.ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("AIBhai", s))
                    c.reply("📋 Copy ho gaya — story mein paste karo", "📋 Copied — paste in your story", kind = Kind.SUCCESS)
                }
            } + ReplyAction(c.t("🔄 Aur options", "🔄 More")) { captions(c, env, labels, uri, seed + 1) }
        )
    }

    /** Ollama vision model on your PC (e.g. llava / gemma3) — optional, free, same Wi-Fi */
    private suspend fun visionCaptions(env: Env, uri: Uri, question: String, tone: String?): List<String>? = withContext(Dispatchers.IO) {
        var base = env.prefs.pcUrl.trim().trimEnd('/')
        if (base.isBlank()) return@withContext null
        if (!base.startsWith("http")) base = "http://$base"
        if (!base.substringAfter("://").contains(':')) base = "$base:11434"
        try {
            val bmp = env.ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) } ?: return@withContext null
            val scale = 640f / maxOf(bmp.width, bmp.height).coerceAtLeast(1)
            val small = if (scale < 1f) Bitmap.createScaledBitmap(bmp, (bmp.width * scale).toInt(), (bmp.height * scale).toInt(), true) else bmp
            val bos = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 80, bos)
            val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
            val prompt = "Is photo ke liye Instagram/WhatsApp story ke 4 chhote captions do, Hinglish (Roman) mein, emojis ke saath" +
                (tone?.let { ", tone: $it" } ?: "") + ". User ne poocha: \"$question\". Sirf 4 lines, numbering ke saath, kuch aur mat likho."
            val body = JSONObject().put("model", env.prefs.pcVisionModel.ifBlank { "llava" }).put("stream", false)
                .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt).put("images", JSONArray().put(b64))))
            val con = URL("$base/api/chat").openConnection() as HttpURLConnection
            con.requestMethod = "POST"
            con.connectTimeout = 3000
            con.readTimeout = 60000
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            if (con.responseCode != 200) return@withContext null
            val txt = JSONObject(con.inputStream.bufferedReader().use { it.readText() }).getJSONObject("message").getString("content")
            txt.lines().map { it.trim().replace(Regex("^\\d+[.)]\\s*"), "").trim('"', ' ') }.filter { it.length in 4..160 }.take(4).ifEmpty { null }
        } catch (e: Exception) {
            null
        }
    }
}
