package com.aibhai.app.voice

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionListener
import android.speech.RecognitionService
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.aibhai.app.AssistActivity
import com.aibhai.app.Prefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume

// ------------------------------------------------------------------ Speech to text

class SpeechInput(private val ctx: Context, private val cb: Callback) {
    interface Callback {
        fun onReady()
        fun onRms(v: Float)
        fun onPartial(t: String)
        fun onResults(list: List<String>)
        fun onError(msg: String)
    }

    private var rec: SpeechRecognizer? = null
    private var lastLang = "hi-IN"
    private var triedOffline = false

    private fun create(preferOffline: Boolean): SpeechRecognizer? {
        if (preferOffline && Build.VERSION.SDK_INT >= 31) {
            try {
                if (SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)) {
                    return SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
                }
            } catch (e: Exception) {
            }
        }
        val services = try {
            ctx.packageManager.queryIntentServices(Intent(RecognitionService.SERVICE_INTERFACE), 0)
                .mapNotNull { it.serviceInfo }
                .filter { it.packageName != ctx.packageName }
        } catch (e: Exception) {
            emptyList()
        }
        val pref = listOf("com.google.android.googlequicksearchbox", "com.google.android.tts", "com.google.android.as")
        val chosen = services.sortedBy { s -> pref.indexOf(s.packageName).let { if (it < 0) 99 else it } }.firstOrNull()
        if (chosen != null) {
            return SpeechRecognizer.createSpeechRecognizer(ctx, ComponentName(chosen.packageName, chosen.name))
        }
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                if (SpeechRecognizer.isOnDeviceRecognitionAvailable(ctx)) {
                    return SpeechRecognizer.createOnDeviceSpeechRecognizer(ctx)
                }
            } catch (e: Exception) {
            }
        }
        return null
    }

    fun start(lang: String, preferOffline: Boolean) {
        lastLang = lang
        triedOffline = preferOffline
        destroy()
        val r = create(preferOffline)
        if (r == null) {
            cb.onError("Phone mein speech service nahi mili. Play Store se 'Google' app install/update karo. Tab tak ⌨️ se type karke command do.")
            return
        }
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                cb.onReady()
            }

            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {
                cb.onRms(rmsdB)
            }

            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                val netErr = error == SpeechRecognizer.ERROR_NETWORK || error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                    error == SpeechRecognizer.ERROR_SERVER
                if (netErr && !triedOffline) {
                    // hybrid: no internet -> retry instantly with on-device (offline) recognition
                    start(lastLang, true)
                    return
                }
                cb.onError(errorText(error))
            }

            override fun onResults(results: Bundle?) {
                val l = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION) ?: arrayListOf()
                if (l.isEmpty()) cb.onError(errorText(SpeechRecognizer.ERROR_NO_MATCH)) else cb.onResults(l)
            }

            override fun onPartialResults(partialResults: Bundle?) {
                partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { cb.onPartial(it) }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, preferOffline)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, ctx.packageName)
        }
        try {
            r.startListening(i)
        } catch (e: Exception) {
            cb.onError("Mic start nahi hua: ${e.message}")
        }
    }

    fun stop() {
        try {
            rec?.stopListening()
        } catch (e: Exception) {
        }
    }

    fun destroy() {
        try {
            rec?.destroy()
        } catch (e: Exception) {
        }
        rec = null
    }

    private fun errorText(e: Int): String = when (e) {
        SpeechRecognizer.ERROR_NO_MATCH -> "Samajh nahi aaya, phir se bolo 🙂"
        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Kuch suna nahi. Orb dabao aur bolo 🎙️"
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
            "Internet nahi mila. Settings mein 'Offline sunna' ON karo (aur Google app mein Hindi offline pack download karo)."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Mic permission chahiye — Settings se allow karo."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Mic busy hai, 2 second baad try karo."
        12, 13 -> "Ye language offline available nahi. Google app → Settings → Voice → Offline speech recognition mein Hindi download karo."
        else -> "Sunne mein dikkat aayi (code $e). Phir se try karo."
    }
}

// ------------------------------------------------------------------ Text to speech

class VoiceOutput(private val ctx: Context, private val prefs: Prefs) {
    private var tts: TextToSpeech? = null
    @Volatile
    private var ttsReady = false
    private var player: MediaPlayer? = null
    var lastError: String = ""
        private set

    init {
        tts = TextToSpeech(ctx) { st ->
            ttsReady = st == TextToSpeech.SUCCESS
        }
    }

    private val emojiRegex = Regex("[\\x{1F000}-\\x{1FAFF}\\x{2600}-\\x{27BF}\\x{2B00}-\\x{2BFF}\\x{FE0F}\\x{200D}\\x{2190}-\\x{21FF}•·]")

    fun clean(text: String): String =
        text.replace(emojiRegex, " ").replace("→", " ").replace(Regex("\\s+"), " ").trim()

    private fun online(): Boolean = try {
        val cm = ctx.getSystemService(ConnectivityManager::class.java)
        cm?.activeNetwork != null
    } catch (e: Exception) {
        false
    }

    private fun currentVoiceId(): String =
        if (prefs.voice == "nidhi") prefs.nidhiVoiceId else prefs.adamVoiceId.ifBlank { Prefs.DEFAULT_ADAM }

    suspend fun speak(text: String, lang: String = "hi") {
        val t = clean(text)
        if (t.isBlank()) return
        val key = prefs.elevenKey
        val vid = currentVoiceId()
        if (prefs.useEleven && key.isNotBlank() && vid.isNotBlank() && online() && !com.aibhai.app.core.Eco.active(ctx)) {
            val f = withContext(Dispatchers.IO) { elevenTts(t, vid, key) }
            if (f != null) {
                playFile(f)
                return
            }
        }
        speakAndroid(t, lang)
    }

    /** ElevenLabs human-like voice (needs internet + your free API key). Cached to save credits. */
    private fun elevenTts(text: String, voiceId: String, key: String): File? {
        return try {
            val dir = File(ctx.cacheDir, "tts").apply { mkdirs() }
            val f = File(dir, "v" + Integer.toHexString((voiceId + "|" + text).hashCode()) + ".mp3")
            if (f.exists() && f.length() > 1000) return f
            val con = URL("https://api.elevenlabs.io/v1/text-to-speech/$voiceId?output_format=mp3_44100_128")
                .openConnection() as HttpURLConnection
            con.requestMethod = "POST"
            con.connectTimeout = 8000
            con.readTimeout = 25000
            con.doOutput = true
            con.setRequestProperty("xi-api-key", key)
            con.setRequestProperty("Content-Type", "application/json")
            con.setRequestProperty("Accept", "audio/mpeg")
            val body = JSONObject()
                .put("text", text)
                .put("model_id", "eleven_multilingual_v2")
                .put(
                    "voice_settings", JSONObject()
                        .put("stability", 0.45)
                        .put("similarity_boost", 0.8)
                        .put("style", 0.25)
                        .put("use_speaker_boost", true)
                )
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            if (con.responseCode != 200) {
                lastError = "ElevenLabs ${con.responseCode}: " + (con.errorStream?.bufferedReader()?.use { it.readText() }?.take(200) ?: "")
                return null
            }
            con.inputStream.use { inp -> f.outputStream().use { inp.copyTo(it) } }
            lastError = ""
            val all = dir.listFiles()?.sortedBy { it.lastModified() } ?: emptyList()
            if (all.size > 300) all.take(all.size - 300).forEach { it.delete() }
            f
        } catch (e: Exception) {
            lastError = "ElevenLabs: ${e.message}"
            null
        }
    }

    private suspend fun playFile(f: File) = suspendCancellableCoroutine<Unit> { cont ->
        val done = AtomicBoolean(false)
        fun finish() {
            if (done.compareAndSet(false, true)) cont.resume(Unit)
        }
        try {
            player?.release()
            val mp = MediaPlayer()
            player = mp
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            mp.setDataSource(f.absolutePath)
            mp.setOnCompletionListener { finish() }
            mp.setOnErrorListener { _, _, _ ->
                finish()
                true
            }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            finish()
        }
        cont.invokeOnCancellation {
            try {
                player?.stop()
            } catch (e: Exception) {
            }
        }
    }

    private suspend fun speakAndroid(text: String, lang: String) {
        var waited = 0
        while (!ttsReady && waited < 3000) {
            kotlinx.coroutines.delay(100)
            waited += 100
        }
        val t = tts ?: return
        if (!ttsReady) return
        val v = pickVoice(lang)
        var explicit = false
        if (v != null) {
            try {
                t.setVoice(v)
                explicit = true
            } catch (e: Exception) {
            }
        }
        if (!explicit) {
            val loc = if (lang == "en") Locale("en", "IN") else Locale("hi", "IN")
            val res = t.setLanguage(loc)
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) t.setLanguage(Locale.ENGLISH)
        }
        val sameVoiceForBoth = v != null && v.name == pickVoiceFor(if (prefs.voice == "nidhi") "adam" else "nidhi", lang)?.name
        if (prefs.voice == "nidhi") {
            t.setPitch(if (explicit && !sameVoiceForBoth) 1.05f else 1.18f)
            t.setSpeechRate(1.0f)
        } else {
            t.setPitch(if (explicit && !sameVoiceForBoth) 0.95f else 0.8f)
            t.setSpeechRate(0.97f)
        }
        suspendCancellableCoroutine<Unit> { cont ->
            val done = AtomicBoolean(false)
            val id = "u" + System.nanoTime()
            fun finish() {
                if (done.compareAndSet(false, true)) cont.resume(Unit)
            }
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    finish()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    finish()
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    finish()
                }

                override fun onStop(utteranceId: String?, interrupted: Boolean) {
                    finish()
                }
            })
            val r = t.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            if (r != TextToSpeech.SUCCESS) finish()
            cont.invokeOnCancellation { t.stop() }
        }
    }

    /** Free + unlimited voices installed on the phone (Google TTS). */
    fun availableVoices(): List<Voice> = try {
        (tts?.voices ?: emptySet()).filter { v ->
            val l = v.locale
            (l.language == "hi" || (l.language == "en" && l.country == "IN")) &&
                !v.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED)
        }.sortedWith(compareBy<Voice>({ it.locale.language != "hi" }, { it.isNetworkConnectionRequired }, { it.name }))
    } catch (e: Exception) {
        emptyList()
    }

    private val femaleHints = listOf("female", "hia", "hid", "enc", "ene")
    private val maleHints = listOf("male", "hic", "hie", "end", "enf")

    fun pickVoiceFor(persona: String, lang: String): Voice? {
        val all = availableVoices()
        if (all.isEmpty()) return null
        val chosen = if (persona == "nidhi") prefs.nidhiTts else prefs.adamTts
        if (chosen.isNotBlank()) all.firstOrNull { it.name == chosen }?.let { return it }
        val wantHi = lang != "en"
        val pool = all.filter { (it.locale.language == "hi") == wantHi && !it.isNetworkConnectionRequired }
            .ifEmpty { all.filter { !it.isNetworkConnectionRequired } }
            .ifEmpty { all }
        val hints = if (persona == "nidhi") femaleHints else maleHints
        pool.firstOrNull { v ->
            val n = v.name.lowercase()
            hints.any { n.contains(it) } && !(persona != "nidhi" && n.contains("female"))
        }?.let { return it }
        return if (persona == "nidhi") pool[0] else pool[if (pool.size > 1) 1 else 0]
    }

    private fun pickVoice(lang: String): Voice? = pickVoiceFor(prefs.voice, lang)

    fun stop() {
        try {
            player?.stop()
        } catch (e: Exception) {
        }
        try {
            tts?.stop()
        } catch (e: Exception) {
        }
    }

    fun shutdown() {
        stop()
        try {
            player?.release()
        } catch (e: Exception) {
        }
        player = null
        tts?.shutdown()
        tts = null
    }
}

// ------------------------------------------------------------------ Default assistant plumbing

class AIBhaiVoiceService : VoiceInteractionService() {
    override fun onLaunchVoiceAssistFromKeyguard() {
        try {
            startActivity(Intent(this, AssistActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK).putExtra("listen", true))
        } catch (e: Exception) {
        }
    }
}

class AIBhaiSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession = AIBhaiSession(this)
}

class AIBhaiSession(ctx: Context) : VoiceInteractionSession(ctx) {
    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        val i = Intent(context, AssistActivity::class.java).putExtra("listen", true)
        try {
            startAssistantActivity(i)
        } catch (e: Exception) {
            try {
                context.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (e2: Exception) {
            }
        }
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                hide()
            } catch (e: Exception) {
            }
        }, 500)
    }
}

/** Required by Android for an assistant; real recognition is done by Google's service. */
class AIBhaiRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try {
            listener?.error(SpeechRecognizer.ERROR_CLIENT)
        } catch (e: Exception) {
        }
    }

    override fun onCancel(listener: Callback?) {}
    override fun onStopListening(listener: Callback?) {}
}
