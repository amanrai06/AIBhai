package com.aibhai.app.core

import android.content.Context
import android.os.BatteryManager
import android.os.PowerManager
import com.aibhai.app.Prefs

/**
 * Eco mode (battery saver for AIBhai itself).
 * Auto-ON when Android battery saver is on or battery <= 15%:
 * no background news fetch, no update checks, no hands-free re-listening,
 * no ElevenLabs (network) voice, orb animation stops.
 */
object Eco {
    fun active(ctx: Context): Boolean {
        val prefs = Prefs(ctx)
        if (prefs.ecoForce) return true
        if (!prefs.ecoAuto) return false
        return try {
            val pm = ctx.getSystemService(PowerManager::class.java)
            val bm = ctx.getSystemService(BatteryManager::class.java)
            val pct = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: 100
            val charging = bm?.isCharging == true
            (pm?.isPowerSaveMode == true) || (!charging && pct in 0..15)
        } catch (e: Exception) {
            false
        }
    }
}
