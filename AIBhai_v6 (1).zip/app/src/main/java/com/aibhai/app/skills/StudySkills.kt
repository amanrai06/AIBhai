package com.aibhai.app.skills

import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Subjects
import com.aibhai.app.core.Txt
import com.aibhai.app.system.Notif
import com.aibhai.app.system.NotificationStore
import com.aibhai.app.system.Perms
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar
import kotlin.math.PI
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.roundToLong

fun startOfToday(): Long = Calendar.getInstance().apply {
    set(Calendar.HOUR_OF_DAY, 0)
    set(Calendar.MINUTE, 0)
    set(Calendar.SECOND, 0)
    set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun fmtNum(x: Double): String {
    if (x.isNaN() || x.isInfinite()) return "∞"
    if (kotlin.math.abs(x - x.roundToLong()) < 1e-9 && kotlin.math.abs(x) < 1e15) return x.roundToLong().toString()
    return String.format(java.util.Locale.US, "%.4f", x).trimEnd('0').trimEnd('.')
}

// =================================================================== MESSAGES

object MessagesSkill : Skill {
    private val msgWords = arrayOf(
        "message", "messages", "msg", "mesej", "messej", "massage", "sms", "whatsapp",
        "notification", "notifications", "email", "mail", "sandesh"
    )
    private val askWords = arrayOf(
        "aaj", "aaye", "aaya", "aye", "aya", "kaun", "kon", "batao", "bata", "padho", "sunao", "important", "imp",
        "check", "dikhao", "summary", "naye", "new", "koi", "kitne", "read", "kis", "kisne", "today", "any", "what", "tell", "show"
    )

    override fun matches(c: Cmd, env: Env) = c.has(*msgWords) && c.has(*askWords)

    data class Conv(
        val pkg: String, val app: String, val title: String, val count: Int,
        val lastText: String, val speakText: String, val score: Double
    )

    private val pos = listOf(
        "urgent", "jaldi", "important", "imp", "asap", "exam", "test", "assignment", "deadline", "college", "class",
        "lab", "sir", "mam", "ma'am", "professor", "hod", "fees", "fee", "result", "interview", "call me", "call karo",
        "meeting", "kal", "today", "aaj", "emergency", "hospital", "help", "papa", "mummy", "mom", "dad", "submit",
        "practical", "viva", "attendance", "notice", "holiday", "chutti", "paisa", "payment", "credited", "debited"
    )
    private val neg = listOf(
        "offer", "sale", "% off", "cashback", "discount", "deal", "coupon", "win ", "free ", "subscribe", "live now",
        "new video", "liked your", "followed you", "recharge now", "limited time", "shop now", "order now", "reels"
    )
    private val otpRegex = Regex("(otp|one time password|verification code|code is|ओटीपी)", RegexOption.IGNORE_CASE)
    private val promoSender = Regex("^[A-Z]{2}-[A-Z0-9]{3,}")

    private fun appWeight(pkg: String): Double = when {
        pkg.startsWith("com.whatsapp") -> 2.5
        pkg.contains("telecom") || pkg.contains("dialer") || pkg.contains("incallui") -> 2.5
        pkg.contains("classroom") -> 3.0
        pkg.contains("messaging") || pkg.contains("mms") || pkg.contains("sms") -> 2.0
        pkg.contains("gm") && pkg.contains("google") -> 1.5
        pkg.contains("telegram") || pkg.contains("teams") -> 1.5
        pkg.contains("linkedin") -> 1.0
        pkg.contains("instagram") || pkg.contains("facebook") -> 0.3
        pkg.contains("youtube") -> -1.5
        listOf("amazon", "flipkart", "meesho", "myntra", "ajio", "swiggy", "zomato", "blinkit", "zepto", "snapdeal", "games").any { pkg.contains(it) } -> -2.0
        else -> 0.0
    }

    private fun score(pkg: String, title: String, text: String, count: Int): Double {
        val t = "$title $text".lowercase()
        var s = appWeight(pkg)
        s += (pos.count { t.contains(it) } * 2.0).coerceAtMost(6.0)
        s -= neg.count { t.contains(it) } * 2.0
        s += (count - 1).coerceIn(0, 3) * 0.7
        if (t.contains("?")) s += 0.5
        if (t.contains("missed call") || t.contains("missed voice call") || t.contains("missed video call")) s += 3.0
        if (promoSender.containsMatchIn(title)) s -= 1.5
        return s
    }

    fun conversations(all: List<Notif>): List<Conv> =
        all.groupBy { it.pkg + "|" + it.title }.map { (_, list) ->
            val latest = list.maxBy { it.time }
            val isOtp = list.any { otpRegex.containsMatchIn(it.text) || otpRegex.containsMatchIn(it.title) }
            val shown = if (isOtp) latest.text.replace(Regex("\\d{4,8}"), "••••") else latest.text
            val spoken = if (isOtp) "ek OTP ya verification code aaya hai" else latest.text
            Conv(latest.pkg, latest.app, latest.title.ifBlank { latest.app }, list.size, shown, spoken,
                score(latest.pkg, latest.title, list.joinToString(" ") { it.text }, list.size))
        }.sortedByDescending { it.score }

    fun counts(env: Env): Pair<Int, Int> {
        if (!Perms.notifAccess(env.ctx)) return Pair(-1, 0)
        val all = NotificationStore.since(env.ctx, startOfToday())
        return Pair(all.size, conversations(all).count { it.score >= 3.0 })
    }

    private fun dot(s: Double) = when {
        s >= 5 -> "🔴"
        s >= 3 -> "🟠"
        else -> "⚪"
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        if (!Perms.notifAccess(env.ctx)) {
            return c.reply(
                "Messages padhne ke liye mujhe 'Notification access' chahiye. Button dabao → AIBhai ON karo. Uske baad aane wale saare messages main yaad rakhunga.",
                "I need 'Notification access' to read your messages. Tap the button and turn AIBhai ON.",
                kind = Kind.WARN,
                actions = listOf(ReplyAction(c.t("Access do", "Give access")) {
                    Perms.openNotifAccess(env.ctx)
                    null
                })
            )
        }
        val all = NotificationStore.since(env.ctx, startOfToday())
        if (all.isEmpty()) {
            return c.reply(
                "${env.name}, aaj abhi tak koi naya message nahi aaya. Chill karo 😎",
                "${env.name}, no new messages today so far. Relax 😎",
                kind = Kind.MESSAGES
            )
        }
        val convs = conversations(all)
        val important = convs.filter { it.score >= 3.0 }.take(5)
        val show = if (important.isNotEmpty()) important else convs.take(3)
        val items = show.map {
            "${dot(it.score)} ${it.app} · ${it.title}${if (it.count > 1) " (${it.count})" else ""}: ${Txt.short(it.lastText, 90)}"
        }
        val hi = StringBuilder()
        val en = StringBuilder()
        hi.append("${env.name}, aaj ${all.size} notifications aaye, ${convs.size} jagah se. ")
        en.append("${env.name}, you got ${all.size} notifications today from ${convs.size} sources. ")
        if (important.isNotEmpty()) {
            hi.append("Important ye hain. ")
            en.append("Here are the important ones. ")
        } else {
            hi.append("Kuch khaas important nahi, latest ye hain. ")
            en.append("Nothing really important, here are the latest. ")
        }
        show.take(3).forEachIndexed { i, cv ->
            hi.append("${i + 1}. ${cv.title}, ${cv.app} pe: ${Txt.short(cv.speakText, 70)}. ")
            en.append("${i + 1}. ${cv.title} on ${cv.app}: ${Txt.short(cv.speakText, 70)}. ")
        }
        return c.reply(
            if (important.isNotEmpty()) "📬 Aaj ${all.size} notifications • ${important.size} important" else "📬 Aaj ${all.size} notifications • kuch khaas important nahi",
            if (important.isNotEmpty()) "📬 ${all.size} notifications today • ${important.size} important" else "📬 ${all.size} notifications today • nothing urgent",
            speakHi = hi.toString(),
            speakEn = en.toString(),
            kind = Kind.MESSAGES,
            items = items
        )
    }
}

// =================================================================== TODAY'S TASKS

object TaskSkill : Skill {
    private val listAsk = arrayOf(
        "kya karna", "kya kaam hai", "kaam batao", "kaam kya hai", "task list", "todo list", "to do list", "show tasks",
        "list tasks", "what do i have", "what should i do", "my tasks", "plan batao", "kaam bacha", "kya bacha", "kaam dikhao"
    )
    private val actionWords = arrayOf(
        "alarm", "timer", "call", "torch", "flash", "pdf", "file", "volume", "kholo", "open", "whatsapp", "attendance", "message"
    )

    private fun load(env: Env): JSONArray = try {
        JSONArray(env.prefs.tasks)
    } catch (e: Exception) {
        JSONArray()
    }

    private fun save(env: Env, a: JSONArray) {
        env.prefs.tasks = a.toString()
    }

    private val addRegex = Regex(
        "(?:aaj|today|kal|tomorrow)?\\s*(?:ka|ke|ki)?\\s*(?:mera|meri|mere|mujhe|my|i have to|i need to|maine)?\\s*(?:aaj|today)?\\s*(?:ka|ke)?\\s*(?:kaam|kam|task|tasks|karna)\\s*(?:hai|he|h|are|is)?\\s*[:\\-]?\\s*(.+)"
    )

    override fun matches(c: Cmd, env: Env): Boolean {
        if (c.has(*listAsk)) return true
        if (c.has("ho gaya", "ho gya", "kar liya", "done", "complete", "khatam") && hasTaskLike(c, env)) return true
        val addCue = c.has("add", "likh lo", "likho", "record", "note karo", "note kar", "yaad rakh", "save")
        val dayCue = c.has("aaj", "today", "kal", "tomorrow", "mujhe", "mera", "meri", "i have to", "i need to")
        val taskWord = Regex("\\b(kaam|kaam|task|tasks|todo|to do)\\b|\\b(ka|mera|ke) kam\\b|\\bkam (hai|he|h)\\b").containsMatchIn(c.norm)
        if (taskWord && (addCue || dayCue)) return true
        if (c.has(*actionWords)) return false
        if (dayCue && Regex("\\b[a-z]+na (hai|he|h)\\b").containsMatchIn(c.norm)) return true
        return false
    }

    private fun hasTaskLike(c: Cmd, env: Env): Boolean {
        val a = load(env)
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (!o.optBoolean("done") && matchTask(c, o.optString("t"))) return true
        }
        return false
    }

    private fun matchTask(c: Cmd, task: String): Boolean {
        val tk = Txt.simplify(Txt.normalize(task)).split(' ').filter { it.length >= 3 }
        if (tk.isEmpty()) return false
        val hits = tk.count { k -> c.s.split(' ').any { Txt.tokenMatch(it, k) } }
        return hits.toDouble() / tk.size >= 0.5
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val a = load(env)
        // mark done
        if (c.has("ho gaya", "ho gya", "kar liya", "done", "complete", "khatam") && !c.norm.contains("karna hai")) {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                if (!o.optBoolean("done") && matchTask(c, o.optString("t"))) {
                    o.put("done", true)
                    save(env, a)
                    val left = (0 until a.length()).count { !a.getJSONObject(it).optBoolean("done") }
                    return c.reply(
                        "✅ Shabash! '${o.optString("t")}' ho gaya. Ab $left kaam bache hain.",
                        "✅ Nice! '${o.optString("t")}' is done. $left tasks left.",
                        kind = Kind.TASKS
                    )
                }
            }
        }
        // clear
        if (c.has("clear", "saaf", "delete", "hata", "reset") && c.has("kaam", "task", "tasks", "list")) {
            save(env, JSONArray())
            return c.reply("🧹 Saare kaam hata diye.", "🧹 Cleared all tasks.", kind = Kind.TASKS)
        }
        // add
        val isAsk = c.has(*listAsk) && !c.has("add", "likh", "likho", "record", "note")
        if (!isAsk) {
            val raw = c.raw.trim()
            val body = addRegex.find(c.norm)?.groupValues?.get(1)?.trim()
            val source = if (Txt.hasDevanagari(raw) || body == null) c.norm else body
            val parts = splitTasks(source)
            if (parts.isNotEmpty()) {
                val today = startOfToday()
                // remove old done/previous-day tasks
                val fresh = JSONArray()
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    if (o.optLong("d") >= today && !o.optBoolean("done")) fresh.put(o)
                }
                parts.forEach { fresh.put(JSONObject().put("t", it).put("d", System.currentTimeMillis()).put("done", false)) }
                save(env, fresh)
                return c.reply(
                    "📝 Note kar liya! Aaj ke ${parts.size} naye kaam add ho gaye. 'Aaj kya karna hai' bolo, main yaad dila dunga.",
                    "📝 Got it! Added ${parts.size} tasks for today. Ask 'what do I have today' anytime.",
                    kind = Kind.TASKS,
                    items = parts.mapIndexed { i, s -> "${i + 1}. $s" }
                )
            }
        }
        // list
        val pending = ArrayList<String>()
        val done = ArrayList<String>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optBoolean("done")) done.add(o.optString("t")) else pending.add(o.optString("t"))
        }
        if (pending.isEmpty() && done.isEmpty()) {
            return c.reply(
                "Abhi koi kaam record nahi hai. Aise bolo: 'Aaj mujhe assignment likhna hai, gym jana hai aur BEEE padhna hai'.",
                "No tasks yet. Say: 'Today I have to finish the assignment, go to gym and study BEEE'.",
                kind = Kind.TASKS
            )
        }
        val items = pending.mapIndexed { i, s -> "⬜ ${i + 1}. $s" } + done.map { "✅ $it" }
        val sayHi = if (pending.isEmpty()) "Wah ${env.name}! Aaj ke saare kaam ho gaye 🎉" else
            "${env.name}, aaj ${pending.size} kaam bache hain: " + pending.mapIndexed { i, s -> "${i + 1}, $s" }.joinToString(". ")
        val sayEn = if (pending.isEmpty()) "Awesome ${env.name}! All tasks done today 🎉" else
            "${env.name}, you have ${pending.size} tasks left: " + pending.mapIndexed { i, s -> "${i + 1}, $s" }.joinToString(". ")
        return c.reply(
            "📋 Aaj ke kaam: ${pending.size} baaki, ${done.size} ho gaye",
            "📋 Today: ${pending.size} pending, ${done.size} done",
            speakHi = sayHi, speakEn = sayEn, kind = Kind.TASKS, items = items
        )
    }

    private fun splitTasks(s: String): List<String> {
        var t = " $s "
        val lead = listOf(
            "aaj mujhe", "aaj ka mera kaam hai", "aaj ka mera kam hai", "aaj ke kaam", "mera kaam hai", "mujhe aaj",
            "aaj", "mujhe", "today i have to", "i have to", "i need to", "add karo", "likh lo", "note karo", "record karo"
        )
        for (l in lead) t = t.replace(" $l ", " ")
        val pieces = t.split(Regex("\\s*(?:,|\\baur\\b|\\band\\b|\\bphir\\b|\\buske baad\\b|\\bthen\\b|\\bthird\\b|\\bsecond\\b|\\bfirst\\b|\\bek\\b|\\bdusra\\b|\\bteesra\\b|\\b\\d+\\b)\\s*"))
        return pieces.map {
            it.trim()
                .replace(Regex("\\b(karna hai|karna he|karna h|hai|he|tha|ye|yeh|bhi|kaam|kam)$"), "")
                .trim()
        }.filter { it.length >= 3 }
            .map { it.replaceFirstChar { ch -> ch.uppercase() } }
            .take(12)
    }
}

// =================================================================== ATTENDANCE

object AttendanceSkill : Skill {
    private val words = arrayOf("attendance", "hazri", "haziri", "hajri", "attend", "present", "absent", "bunk", "lecture", "class li")

    override fun matches(c: Cmd, env: Env): Boolean {
        if (c.has("attendance", "hazri", "haziri", "hajri")) return true
        val subj = Subjects.detectAll(c.s)
        return subj.isNotEmpty() && (c.has(*words) || c.has("miss kiya", "miss kar", "chhut", "nahi gaya", "skip"))
    }

    private fun load(env: Env): JSONObject = try {
        JSONObject(env.prefs.attendance)
    } catch (e: Exception) {
        JSONObject()
    }

    private fun get(o: JSONObject, s: String): IntArray {
        val a = o.optJSONArray(s) ?: return intArrayOf(0, 0)
        return intArrayOf(a.optInt(0), a.optInt(1))
    }

    private fun put(o: JSONObject, s: String, att: Int, tot: Int) {
        o.put(s, JSONArray().put(att).put(tot))
    }

    fun advice(att: Int, tot: Int, en: Boolean): String {
        if (tot == 0) return if (en) "no classes yet" else "abhi koi class nahi"
        val pct = att * 100.0 / tot
        return if (pct >= 75.0) {
            val canBunk = floor((4.0 * att - 3.0 * tot) / 3.0).toInt()
            if (en) "${fmtNum(pct)}% — safe, you can skip $canBunk" else "${fmtNum(pct)}% — safe, $canBunk class bunk kar sakte ho"
        } else {
            val need = ceil(3.0 * tot - 4.0 * att).toInt()
            if (en) "${fmtNum(pct)}% ⚠️ attend next $need classes to reach 75%" else "${fmtNum(pct)}% ⚠️ 75% ke liye lagatar $need class jao"
        }
    }

    fun lowSubjects(env: Env): List<String> {
        val o = load(env)
        val out = ArrayList<String>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            val v = get(o, k)
            if (v[1] > 0 && v[0] * 100.0 / v[1] < 75.0) out.add(k)
        }
        return out
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val o = load(env)
        val subs = Subjects.detectAll(c.s)
        if (c.has("reset")) {
            if (subs.isEmpty()) env.prefs.attendance = "{}" else {
                subs.forEach { o.remove(it) }
                env.prefs.attendance = o.toString()
            }
            return c.reply("🧹 Attendance reset ho gayi.", "🧹 Attendance reset.", kind = Kind.SUCCESS)
        }
        val set = Regex("(\\d+)\\s*(out of|me se|mein se|men se|mai se|me|mein|men|/)\\s*(\\d+)").find(c.norm)
        if (set != null && subs.isNotEmpty()) {
            var a = set.groupValues[1].toInt()
            var t = set.groupValues[3].toInt()
            if (set.groupValues[2] != "out of" && set.groupValues[2] != "/") {
                val tmp = a; a = t; t = tmp
            }
            if (a > t) {
                val tmp = a; a = t; t = tmp
            }
            subs.forEach { put(o, it, a, t) }
            env.prefs.attendance = o.toString()
            val s = subs.first()
            return c.reply(
                "📊 $s attendance set: $a/$t • ${advice(a, t, false)}",
                "📊 $s attendance set: $a/$t • ${advice(a, t, true)}",
                kind = Kind.SUCCESS
            )
        }
        val report = subs.isEmpty() || c.has("batao", "kitni", "kitna", "status", "report", "dikhao", "check", "percent", "how much", "show", "tell")
        val absent = c.has("miss", "bunk", "absent", "chhut", "chuti", "nahi gaya", "nahi gya", "skip", "missed")
        if (!report || (subs.isNotEmpty() && (absent || c.has("attend", "present", "li", "liya", "gaya", "attended")) && !c.has("batao", "kitni", "kitna", "status"))) {
            val target = subs.ifEmpty { return c.reply("Kaunsa subject? Jaise: 'aaj Maths attend kiya'", "Which subject? e.g. 'attended Maths today'", kind = Kind.WARN) }
            val lines = ArrayList<String>()
            for (s in target) {
                val v = get(o, s)
                val att = v[0] + if (absent) 0 else 1
                val tot = v[1] + 1
                put(o, s, att, tot)
                lines.add("$s: $att/$tot • ${advice(att, tot, c.en)}")
            }
            env.prefs.attendance = o.toString()
            return c.reply(
                if (absent) "📉 Absent mark kar diya" else "✅ Present mark kar diya",
                if (absent) "📉 Marked absent" else "✅ Marked present",
                speakHi = (if (absent) "Absent lag gayi. " else "Present lag gayi. ") + lines.joinToString(". "),
                speakEn = (if (absent) "Marked absent. " else "Marked present. ") + lines.joinToString(". "),
                kind = if (lines.any { it.contains("⚠️") }) Kind.WARN else Kind.SUCCESS,
                items = lines
            )
        }
        val keys = if (subs.isNotEmpty()) subs else {
            val l = ArrayList<String>()
            val it = o.keys()
            while (it.hasNext()) l.add(it.next())
            l
        }
        if (keys.isEmpty()) {
            return c.reply(
                "Abhi attendance record nahi hai. Bolo 'aaj Maths attend kiya' ya 'Maths 20 me se 16'.",
                "No attendance yet. Say 'attended Maths today' or 'Maths 16 out of 20'.",
                kind = Kind.INFO
            )
        }
        val lines = keys.map { s -> val v = get(o, s); "$s: ${v[0]}/${v[1]} • ${advice(v[0], v[1], c.en)}" }
        return c.reply(
            "📊 Attendance report", "📊 Attendance report",
            speakHi = lines.joinToString(". "), speakEn = lines.joinToString(". "),
            kind = if (lines.any { it.contains("⚠️") }) Kind.WARN else Kind.INFO,
            items = lines
        )
    }
}

// =================================================================== ENGINEERING CALCULATOR

object CalcSkill : Skill {
    private val opWords = arrayOf(
        "plus", "jod", "jodo", "add", "minus", "ghata", "ghatao", "into", "guna", "times", "multiply", "divide",
        "divided", "bhag", "percent", "pratishat", "square", "root", "cube", "calculate", "hisab", "power"
    )
    private val num = "(\\d+(?:\\.\\d+)?)"

    override fun matches(c: Cmd, env: Env): Boolean {
        if (!c.norm.any { it.isDigit() }) return false
        if (c.has("stress", "pratibal")) return true
        if (c.has("kwh") || c.norm.contains("kmph") || c.norm.contains("km per hour")) return true
        if (c.has("ohm", "ohms", "volt", "voltage", "ampere", "amp", "current", "resistance") && c.numbers.size >= 2) return true
        if (Regex("\\d\\s*[+\\-*/×÷^%x]\\s*\\d").containsMatchIn(c.norm)) return true
        return c.has(*opWords)
    }

    private fun find(re: String, s: String): Double? = Regex(re).find(s)?.groupValues?.get(1)?.toDoubleOrNull()

    override suspend fun run(c: Cmd, env: Env): Reply {
        val n = c.norm
        // Stress = F / A
        if (c.has("stress", "pratibal")) {
            var f = find("$num\\s*(?:kn|kilo ?newton)\\b", n)?.times(1000) ?: find("$num\\s*(?:n|newton|nyuton|newtons)\\b", n)
            val area = find("$num\\s*(?:mm2|mm\\^2|sq ?mm|square mm)", n)
            var d = find("$num\\s*mm\\b", n) ?: find("$num\\s*cm\\b", n)?.times(10) ?: find("$num\\s*m\\b", n)?.times(1000)
            if (f == null && c.numbers.isNotEmpty()) f = c.numbers.first()
            if (area == null && d == null && c.numbers.size >= 2) d = c.numbers[1]
            if (f != null && (area != null || d != null)) {
                val a = area ?: (PI * d!! * d / 4.0)
                val sigma = f / a
                val steps = ArrayList<String>()
                if (area == null) steps.add("A = π·d²/4 = π × ${fmtNum(d!!)}² / 4 = ${fmtNum(a)} mm²")
                steps.add("σ = F / A = ${fmtNum(f)} N / ${fmtNum(a)} mm²")
                steps.add("σ = ${fmtNum(sigma)} N/mm² = ${fmtNum(sigma)} MPa")
                return c.reply(
                    "🧮 Stress = ${fmtNum(sigma)} MPa", "🧮 Stress = ${fmtNum(sigma)} MPa",
                    speakHi = "Stress ${fmtNum(sigma)} mega pascal aata hai.", speakEn = "The stress is ${fmtNum(sigma)} megapascal.",
                    kind = Kind.SUCCESS, items = steps
                )
            }
        }
        // EV range
        if (c.has("kwh")) {
            val e = find("$num\\s*(?:kwh|kilowatt hour)", n)
            val cons = find("$num\\s*(?:wh ?/ ?km|wh per km|wh km|watt hour per km)", n)
            if (e != null) {
                val used = cons ?: 35.0
                val range = e * 1000 / used
                val items = listOf(
                    "Range = Energy / Consumption",
                    "= ${fmtNum(e)} kWh × 1000 / ${fmtNum(used)} Wh/km",
                    "= ${fmtNum(range)} km" + if (cons == null) " (35 Wh/km maan ke — 2-wheeler typical)" else ""
                )
                return c.reply(
                    "🔋 EV Range ≈ ${fmtNum(range)} km", "🔋 EV range ≈ ${fmtNum(range)} km",
                    speakHi = "Range lagbhag ${fmtNum(range)} kilometer aayegi.", speakEn = "The range is about ${fmtNum(range)} kilometers.",
                    kind = Kind.SUCCESS, items = items
                )
            }
        }
        // speed conversion
        find("$num\\s*(?:kmph|km per hour|km h|kilometer per hour)", n)?.let { v ->
            val ms = v * 5.0 / 18.0
            return c.reply(
                "🚗 ${fmtNum(v)} km/h = ${fmtNum(ms)} m/s", "🚗 ${fmtNum(v)} km/h = ${fmtNum(ms)} m/s",
                kind = Kind.SUCCESS, items = listOf("m/s = km/h × 5/18")
            )
        }
        // Ohm's law
        if (c.has("ohm", "ohms", "volt", "voltage", "ampere", "amp", "current", "resistance")) {
            val v = find("$num\\s*(?:v|volt|volts)\\b", n)
            val r = find("$num\\s*(?:ohm|ohms|om)\\b", n)
            val i = find("$num\\s*(?:a|amp|amps|ampere|ampear)\\b", n)
            val res: Triple<String, String, List<String>>? = when {
                v != null && r != null -> {
                    val cur = v / r
                    Triple("I = ${fmtNum(cur)} A", "Current ${fmtNum(cur)} ampere", listOf("I = V/R = ${fmtNum(v)}/${fmtNum(r)} = ${fmtNum(cur)} A", "P = V·I = ${fmtNum(v * cur)} W"))
                }
                v != null && i != null -> {
                    val rr = v / i
                    Triple("R = ${fmtNum(rr)} Ω", "Resistance ${fmtNum(rr)} ohm", listOf("R = V/I = ${fmtNum(v)}/${fmtNum(i)} = ${fmtNum(rr)} Ω", "P = V·I = ${fmtNum(v * i)} W"))
                }
                i != null && r != null -> {
                    val vv = i * r
                    Triple("V = ${fmtNum(vv)} V", "Voltage ${fmtNum(vv)} volt", listOf("V = I·R = ${fmtNum(i)}×${fmtNum(r)} = ${fmtNum(vv)} V", "P = V·I = ${fmtNum(vv * i)} W"))
                }
                else -> null
            }
            if (res != null) {
                return c.reply("⚡ ${res.first}", "⚡ ${res.first}", speakHi = res.second, speakEn = res.second, kind = Kind.SUCCESS, items = res.third)
            }
        }
        // plain maths
        val expr = buildExpr(n)
        val value = try {
            Parser(expr).parse()
        } catch (e: Exception) {
            null
        }
        if (value == null || expr.isBlank()) {
            return c.reply(
                "Ye calculation samajh nahi aaya. Jaise bolo: '25 into 4 plus 10' ya '500 newton 20 mm rod ka stress'.",
                "Couldn't parse that. Try: '25 times 4 plus 10' or 'stress for 500 newton on 20 mm rod'.",
                kind = Kind.WARN
            )
        }
        val pretty = expr.replace("*", " × ").replace("/", " ÷ ").replace("+", " + ").replace("-", " − ")
        return c.reply(
            "🧮 ${fmtNum(value)}", "🧮 ${fmtNum(value)}",
            speakHi = "Jawab hai ${fmtNum(value)}", speakEn = "The answer is ${fmtNum(value)}",
            kind = Kind.SUCCESS, items = listOf("$pretty = ${fmtNum(value)}")
        )
    }

    fun buildExpr(n: String): String {
        var e = " " + n.replace('×', '*').replace('÷', '/') + " "
        e = Regex("$num\\s*ka\\s*$num\\s*(?:percent|pratishat|%)").replace(e) { "(${it.groupValues[2]}/100*${it.groupValues[1]})" }
        e = Regex("$num\\s*(?:percent|pratishat|%)\\s*(?:of|ka)\\s*$num").replace(e) { "(${it.groupValues[1]}/100*${it.groupValues[2]})" }
        val reps = listOf(
            "square root of" to " √ ", "square root" to " √ ", "under root" to " √ ", "root" to " √ ", "vargmool" to " √ ",
            "ka square" to " ^2 ", "square" to " ^2 ", "ka cube" to " ^3 ", "cube" to " ^3 ",
            "to the power" to " ^ ", "power" to " ^ ", "divided by" to " / ", "multiplied by" to " * ",
            "plus" to " + ", "jodo" to " + ", "jod" to " + ", "add" to " + ",
            "minus" to " - ", "ghatao" to " - ", "ghata" to " - ",
            "into" to " * ", "guna" to " * ", "times" to " * ", "multiply" to " * ", "x" to " * ",
            "divide" to " / ", "bhag" to " / ", "by" to " / "
        )
        for ((k, v) in reps) e = e.replace(Regex("(?<![a-z])" + Regex.escape(k) + "(?![a-z])"), v)
        val kept = e.filter { it.isDigit() || it in ".+-*/^()√" }
        return kept.trimStart('+', '*', '/', '^').trimEnd('+', '-', '*', '/', '^', '√')
    }

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double {
            val v = expr()
            if (i < s.length) throw IllegalArgumentException("bad")
            return v
        }

        private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

        private fun expr(): Double {
            var v = term()
            while (peek() == '+' || peek() == '-') {
                val op = s[i++]
                val r = term()
                v = if (op == '+') v + r else v - r
            }
            return v
        }

        private fun term(): Double {
            var v = factor()
            while (peek() == '*' || peek() == '/') {
                val op = s[i++]
                val r = factor()
                v = if (op == '*') v * r else v / r
            }
            return v
        }

        private fun factor(): Double {
            val b = unary()
            if (peek() == '^') {
                i++
                return Math.pow(b, factor())
            }
            return b
        }

        private fun unary(): Double = when (peek()) {
            '-' -> {
                i++
                -unary()
            }
            '+' -> {
                i++
                unary()
            }
            '√' -> {
                i++
                Math.sqrt(unary())
            }
            else -> primary()
        }

        private fun primary(): Double {
            if (peek() == '(') {
                i++
                val v = expr()
                if (peek() == ')') i++
                return v
            }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            if (st == i) throw IllegalArgumentException("num")
            return s.substring(st, i).toDouble()
        }
    }
}
