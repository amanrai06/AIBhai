package com.aibhai.app.core

/**
 * Text brain: Devanagari -> Roman, phonetic simplification (autocorrect friendly),
 * fuzzy matching, Haryanvi / Bhojpuri dialect normalisation, language detection.
 */
object Txt {
    private val cons: Map<Char, String> = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "n",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v", 'श' to "sh",
        'ष' to "sh", 'स' to "s", 'ह' to "h", 'ळ' to "l",
        'क़' to "q", 'ख़' to "kh", 'ग़' to "g", 'ज़' to "z",
        'ड़' to "d", 'ढ़' to "dh", 'फ़' to "f", 'य़' to "y"
    )
    private val nuktaMap: Map<Char, String> = mapOf(
        'क' to "q", 'ख' to "kh", 'ग' to "g", 'ज' to "z", 'ड' to "d", 'ढ' to "dh", 'फ' to "f"
    )
    private val vowels: Map<Char, String> = mapOf(
        'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo",
        'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o", 'ऍ' to "e"
    )
    private val matras: Map<Char, String> = mapOf(
        'ा' to "aa", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'ृ' to "ri",
        'े' to "e", 'ै' to "ai", 'ो' to "o", 'ौ' to "au", 'ॉ' to "o", 'ॅ' to "e"
    )
    private const val VIRAMA = '्'
    private const val NUKTA = '़'

    private fun isDev(c: Char): Boolean = c in 'ऀ'..'ॿ'

    fun hasDevanagari(s: String): Boolean = s.any { it in 'ऀ'..'ॿ' }

    fun translit(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            val con = cons[c]
            if (con != null) {
                var j = i + 1
                var out = con
                if (j < s.length && s[j] == NUKTA) {
                    out = nuktaMap[c] ?: con
                    j++
                }
                sb.append(out)
                val next = if (j < s.length) s[j] else ' '
                val m = matras[next]
                if (m != null) {
                    sb.append(m)
                    i = j + 1
                    continue
                }
                if (next == VIRAMA) {
                    i = j + 1
                    continue
                }
                if (isDev(next)) sb.append('a')
                i = j
                continue
            }
            val v = vowels[c]
            when {
                v != null -> sb.append(v)
                c == 'ं' || c == 'ँ' -> sb.append('n')
                c == 'ः' -> sb.append('h')
                c == '।' || c == '॥' -> sb.append(' ')
                c in '०'..'९' -> sb.append('0' + (c - '०'))
                c == NUKTA || c == VIRAMA -> {}
                else -> sb.append(c)
            }
            i++
        }
        return sb.toString()
    }

    private val cleanRegex = Regex("[^a-z0-9.%+\\-*/×÷:^\\s]")
    private val spaceRegex = Regex("\\s+")

    /** lowercase + Devanagari to Roman + remove punctuation */
    fun normalize(raw: String): String {
        val t = translit(raw.lowercase())
        return t.replace(cleanRegex, " ").replace(spaceRegex, " ").trim()
    }

    private val notChRegex = Regex("c(?!h)")

    /** phonetic key: makes "kholo"/"खोलो", "message"/"मैसेज" etc. comparable */
    fun simplify(s: String): String {
        var t = s.lowercase()
        t = t.replace("chh", "ch").replace("aa", "a").replace("ee", "i").replace("oo", "u")
            .replace("ai", "e").replace("au", "o").replace("ph", "f").replace("sh", "s")
            .replace("kh", "k").replace("gh", "g").replace("th", "t").replace("dh", "d")
            .replace("bh", "b").replace("jh", "j").replace("ck", "k")
            .replace('w', 'v').replace('z', 'j').replace('q', 'k').replace('x', 'k')
        t = t.replace(notChRegex, "k")
        val sb = StringBuilder()
        for (ch in t) {
            if (sb.isNotEmpty() && sb.last() == ch && ch.isLetter()) continue
            sb.append(ch)
        }
        return sb.toString().trim()
    }

    fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(cur[j - 1] + 1, prev[j] + 1, prev[j - 1] + cost)
            }
            val tmp = prev
            prev = cur
            cur = tmp
        }
        return prev[b.length]
    }

    /** token-level fuzzy match. k is already simplified */
    fun tokenMatch(tok: String, k: String): Boolean {
        if (tok == k) return true
        if (k.length >= 4 && tok.startsWith(k)) return true
        if (k.length >= 4 && tok.length >= 3) {
            val allowed = if (k.length >= 7) 2 else 1
            if (kotlin.math.abs(tok.length - k.length) <= allowed && lev(tok, k) <= allowed) return true
        }
        return false
    }

    private val keyCache = HashMap<String, String>()

    private fun key(k: String): String = synchronized(keyCache) {
        keyCache.getOrPut(k) { simplify(normalize(k)) }
    }

    /** does simplified text contain keyword (fuzzy for single words, exact for phrases) */
    fun has(simplified: String, keyword: String): Boolean {
        val k = key(keyword)
        if (k.isBlank()) return false
        if (k.contains(' ')) return " $simplified ".contains(" $k") || simplified.contains(k)
        return simplified.split(' ').any { tokenMatch(it, k) }
    }

    private val dialect: List<Pair<String, String>> = listOf(
        // Haryanvi
        "ke kare se" to "kya kar raha hai", "ke kar rya se" to "kya kar raha hai",
        "ke hoya" to "kya hua", "kit se" to "kahan hai", "kit" to "kahan",
        "manne" to "mujhe", "mhane" to "mujhe", "mhare" to "mere", "mhara" to "mera",
        "mhari" to "meri", "thare" to "tere", "tanne" to "tujhe", "kade" to "kab",
        "ghana" to "bahut", "ghani" to "bahut", "konya" to "nahi", "kona" to "nahi",
        "khol de" to "kholo", "kholde" to "kholo", "khol diye" to "kholo", "khol diyo" to "kholo",
        "bata de" to "batao", "batade" to "batao", "bataiye" to "batao", "batana" to "batao",
        "chala de" to "chalao", "dikha de" to "dikhao", "laga de" to "lagao",
        "kar de" to "karo", "karde" to "karo", "kar diyo" to "karo",
        "ajj" to "aaj", "aj" to "aaj",
        // Bhojpuri
        "ka hal ba" to "kya haal hai", "ka haal ba" to "kya haal hai", "kaisan baa" to "kaise ho",
        "hamra" to "mujhe", "hamke" to "mujhe", "hamar" to "mera", "tohar" to "tera",
        "ketna" to "kitna", "ketne" to "kitne", "aail ba" to "aaya hai", "aail" to "aaya",
        "aayil" to "aaya", "khol da" to "kholo", "batava" to "batao", "bata da" to "batao",
        "kar da" to "karo", "chala da" to "chalao", "dekha da" to "dikhao",
        "sandesa" to "message", "sandesh" to "message"
    ).sortedByDescending { it.first.length }

    fun replacePhrases(text: String, pairs: List<Pair<String, String>>): String {
        var t = " $text "
        for ((k, v) in pairs) {
            if (k.isBlank()) continue
            t = t.replace(Regex("(?<=\\s)" + Regex.escape(k) + "(?=\\s)"), v)
        }
        return t.replace(spaceRegex, " ").trim()
    }

    fun applyDialect(n: String): String = replacePhrases(n, dialect)

    fun applyLearned(n: String, learned: Map<String, String>): String {
        if (learned.isEmpty()) return n
        learned[n]?.let { return it }
        val pairs = learned.entries.map { it.key to it.value }.sortedByDescending { it.first.length }
        return replacePhrases(n, pairs)
    }

    private val hindiMarkers = setOf(
        "hai", "hain", "ho", "kya", "kyaa", "karo", "kar", "kardo", "kholo", "khol", "batao", "bata",
        "mujhe", "mera", "meri", "mere", "aaj", "kal", "kaun", "kon", "kitne", "kitna", "kitni", "baje",
        "ko", "se", "mein", "me", "main", "par", "pe", "bhai", "lagao", "chalao", "dikhao", "yaad", "dilana",
        "aaye", "aaya", "wali", "wala", "nahi", "haan", "ka", "ki", "ke", "aur", "band", "bolo", "bhejo",
        "daal", "do", "de", "sunao", "padho", "kuch", "abhi", "subah", "shaam", "raat", "jaldi", "kaise",
        "karna", "kaam", "ho gaya", "gaya", "tha", "thi"
    )

    /** "hi" = reply in Hinglish, "en" = reply in English */
    fun detectLang(raw: String): String {
        if (hasDevanagari(raw)) return "hi"
        val words = raw.lowercase().split(Regex("[^a-z]+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return "hi"
        val hi = words.count { it in hindiMarkers }
        return if (hi >= 1) "hi" else "en"
    }

    private val camelRegex = Regex("(?<=[a-z])(?=[A-Z])|(?<=[A-Za-z])(?=[0-9])|(?<=[0-9])(?=[A-Za-z])")

    fun splitCamel(s: String): String = s.replace(camelRegex, " ").replace('_', ' ').replace('-', ' ')

    fun short(s: String, n: Int): String = if (s.length <= n) s else s.take(n - 1).trimEnd() + "…"
}
