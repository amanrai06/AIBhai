package com.aibhai.app

import android.Manifest
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import com.aibhai.app.ui.AIBhaiApp
import com.aibhai.app.ui.AIBhaiTheme

open class MainActivity : FragmentActivity() {
    lateinit var controller: AssistantController

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (::controller.isInitialized) controller.onPermissionsResult()
    }

    open fun autoListen(): Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        controller = AssistantController(this, Prefs(this)) { perms -> permLauncher.launch(perms) }
        setContent {
            AIBhaiTheme {
                AIBhaiApp(controller, requestBasics = { requestBasics() })
            }
        }
        handle(intent, first = true)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handle(intent, first = false)
    }

    private fun handle(i: Intent?, first: Boolean) {
        if (i?.action == Intent.ACTION_SEND) {
            val img: android.net.Uri? = if (i.type?.startsWith("image/") == true) sharedImage(i) else null
            controller.handleShared(i.getStringExtra(Intent.EXTRA_TEXT), img)
            setIntent(Intent())
            return
        }
        val wants = autoListen() || i?.getBooleanExtra("listen", false) == true ||
            i?.action == Intent.ACTION_ASSIST || i?.action == "android.intent.action.VOICE_COMMAND"
        if (wants) controller.startListening()
        else if (first && !com.aibhai.app.system.Perms.mic(this)) requestBasics()
    }

    @Suppress("DEPRECATION")
    private fun sharedImage(i: Intent): android.net.Uri? =
        if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, android.net.Uri::class.java)
        else i.getParcelableExtra<android.net.Uri>(Intent.EXTRA_STREAM)

    fun requestBasics() {
        val list = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CALL_PHONE
        )
        if (Build.VERSION.SDK_INT >= 33) list.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(list.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        if (Prefs(this).bubble && com.aibhai.app.system.FloatingBubble.canDraw(this)) com.aibhai.app.system.FloatingBubble.start(this)
        if (::controller.isInitialized) {
            controller.tick++
            controller.onResumeChecks()
        }
    }

    override fun onPause() {
        super.onPause()
        if (::controller.isInitialized && controller.status == Status.LISTENING) controller.cancelAll()
    }

    override fun onDestroy() {
        if (::controller.isInitialized) controller.destroy()
        super.onDestroy()
    }
}

class AssistActivity : MainActivity() {
    override fun autoListen(): Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        // Works on the lock screen: safe commands run directly; personal ones ask for unlock/fingerprint
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        }
        super.onCreate(savedInstanceState)
    }
}
