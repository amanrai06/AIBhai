package com.aibhai.app.skills

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.LinearLayout
import android.widget.TextView
import com.aibhai.app.Prefs
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Subjects
import com.aibhai.app.core.Txt
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Parsed subject attendance from the college portal page. */
data class PortalRow(val subject: String, val percent: Double)

object PortalBridge {
    @Volatile
    var pending: CompletableDeferred<List<PortalRow>>? = null
}

/**
 * College portal attendance (e.g. Okie Dokie student portal).
 * Opens the portal in AIBhai's own browser, auto-fills roll number, waits for you to log in
 * once (session is remembered), finds subject-wise % on the page, and SPEAKS it.
 */
object PortalSkill : Skill {
    override fun matches(c: Cmd, env: Env): Boolean {
        val att = c.has("attendance", "hazri", "haziri", "hajri", "percentage", "percent")
        val portal = c.has("college", "portal", "okie", "okidoki", "oki doki", "okiedokie", "erp", "overall", "total")
        val subjAsk = Subjects.detectAll(c.s).isNotEmpty() && c.has("kitni", "kitna", "kitne", "batao", "how much", "kya hai", "check")
        val manualMark = c.has("attend kiya", "miss kiya", "bunk", "absent", "present", "set", "reset", "me se", "out of")
        if (manualMark) return false
        if (env.prefs.portalUrl.isBlank() && env.prefs.attendance != "{}" && !portal) return false
        return (att && (portal || env.prefs.portalUrl.isNotBlank())) || (subjAsk && att) ||
            (env.prefs.portalUrl.isNotBlank() && subjAsk && c.has("attendance", "percent", "percentage", "hazri"))
    }

    private fun loadCache(env: Env): Pair<Long, List<PortalRow>> = try {
        val o = JSONObject(env.prefs.portalCache)
        val a = o.optJSONArray("rows") ?: JSONArray()
        Pair(o.optLong("t"), (0 until a.length()).map { a.getJSONObject(it) }.map { PortalRow(it.optString("s"), it.optDouble("p")) })
    } catch (e: Exception) {
        Pair(0L, emptyList())
    }

    private fun saveCache(env: Env, rows: List<PortalRow>) {
        val a = JSONArray()
        rows.forEach { a.put(JSONObject().put("s", it.subject).put("p", it.percent)) }
        env.prefs.portalCache = JSONObject().put("t", System.currentTimeMillis()).put("rows", a).toString()
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        if (env.prefs.portalUrl.isBlank()) {
            return c.reply(
                "🎓 College portal ka link chahiye. Settings → 'College portal' mein woh link daalo jahan browser mein attendance dekhte ho (roll no. ${env.prefs.rollNo} pehle se bhara hai).",
                "🎓 I need your college portal link. Add it in Settings → 'College portal'.",
                kind = Kind.WARN, status = "needs_input"
            )
        }
        val online = com.aibhai.app.core.Net.online(env.ctx)
        val rows: List<PortalRow>? = if (online) {
            val d = CompletableDeferred<List<PortalRow>>()
            PortalBridge.pending = d
            env.launch(Intent(env.ctx, PortalActivity::class.java))
            val r = withTimeoutOrNull(180_000) { d.await() }
            PortalBridge.pending = null
            r
        } else null
        val fresh = rows != null && rows.isNotEmpty()
        val (t, cached) = if (fresh) Pair(System.currentTimeMillis(), rows!!) else loadCache(env)
        if (fresh) saveCache(env, rows!!)
        if (cached.isEmpty()) {
            return c.reply(
                "😕 Portal pe attendance ka % nahi mila. Login karke attendance wala page kholo — main khud padh lunga. Ek screenshot bhejoge to main isko aur accurate bana dunga.",
                "😕 Couldn't find attendance % on the portal. Log in and open the attendance page.",
                kind = Kind.WARN, status = "failed",
                actions = listOf(ReplyAction(c.t("🔁 Phir try karo", "🔁 Try again")) { run(c, env) })
            )
        }
        val subjects = Subjects.detectAll(c.s)
        val overall = cached.firstOrNull { Regex("overall|total|aggregate|cumulative|grand", RegexOption.IGNORE_CASE).containsMatchIn(it.subject) }
        val avg = overall?.percent ?: cached.map { it.percent }.average()
        val picked = if (subjects.isEmpty()) cached else cached.filter { row ->
            val rs = Txt.simplify(Txt.normalize(row.subject))
            subjects.any { s -> Subjects.map[s]?.any { Txt.has(rs, it) } == true || Txt.has(rs, s) }
        }
        val when_ = SimpleDateFormat("d MMM, h:mm a", Locale.US).format(Date(t))
        val offlineNote = if (!online) listOf("📴 Offline — ye pichli saved attendance hai") else emptyList()
        val items = offlineNote + cached.map { r ->
            val flag = if (r.percent < 75) "⚠️" else "✅"
            "$flag ${r.subject}: ${fmtNum(r.percent)}%"
        } + listOf("🕐 ${if (fresh) "Abhi" else "Pichli baar"} check: $when_")
        val focus = picked.ifEmpty { cached }
        val sayHi = StringBuilder("${env.name}, ")
        val sayEn = StringBuilder("${env.name}, ")
        if (subjects.isNotEmpty() && picked.isNotEmpty()) {
            picked.forEach {
                sayHi.append("${it.subject} mein ${fmtNum(it.percent)} percent attendance hai. ")
                sayEn.append("${it.subject} is at ${fmtNum(it.percent)} percent. ")
            }
        } else if (subjects.isNotEmpty()) {
            sayHi.append("${subjects.joinToString()} portal pe nahi mila. ")
            sayEn.append("${subjects.joinToString()} not found on the portal. ")
        }
        sayHi.append("Overall attendance ${fmtNum(avg)} percent hai. ")
        sayEn.append("Overall attendance is ${fmtNum(avg)} percent. ")
        val low = cached.filter { it.percent < 75 && it !== overall }
        if (low.isNotEmpty()) {
            sayHi.append("Dhyan do, ${low.joinToString { it.subject }} mein 75 se kam hai.")
            sayEn.append("Careful: below 75 in ${low.joinToString { it.subject }}.")
        } else {
            sayHi.append("Sab subjects safe hain. 👍")
            sayEn.append("All subjects are safe. 👍")
        }
        return c.reply(
            "🎓 College attendance • Overall ${fmtNum(avg)}%" + if (subjects.isNotEmpty() && picked.isNotEmpty()) " • " + focus.joinToString { "${it.subject} ${fmtNum(it.percent)}%" } else "",
            "🎓 College attendance • Overall ${fmtNum(avg)}%",
            speakHi = sayHi.toString(), speakEn = sayEn.toString(),
            kind = if (low.isNotEmpty() || avg < 75) Kind.WARN else Kind.SUCCESS,
            items = items, status = if (fresh) "verified" else "ok"
        )
    }

    /** Find "Subject … 82.5%" style rows anywhere in the page text. */
    fun parse(text: String): List<PortalRow> {
        val out = LinkedHashMap<String, Double>()
        val pct = Regex("(\\d{1,3}(?:\\.\\d{1,2})?)\\s*%")
        val lines = text.split('\n').map { it.trim() }.filter { it.isNotBlank() }
        for ((i, line) in lines.withIndex()) {
            val m = pct.findAll(line).lastOrNull() ?: continue
            val p = m.groupValues[1].toDoubleOrNull() ?: continue
            if (p > 100) continue
            var name = line.substring(0, m.range.first)
                .replace(Regex("[\\t|]+"), " ")
                .replace(Regex("\\b\\d+\\s*/\\s*\\d+\\b"), " ")
                .replace(Regex("\\b\\d+(\\.\\d+)?\\b"), " ")
                .replace(Regex("\\s+"), " ").trim(' ', ':', '-', '|')
            if (name.length < 2 && i > 0) name = lines[i - 1].replace(Regex("\\d+(\\.\\d+)?%?"), " ").trim(' ', ':', '-', '|')
            if (name.length < 2 || name.length > 60) continue
            out[name] = p
        }
        return out.map { PortalRow(it.key, it.value) }
    }
}

class PortalActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private val handler = Handler(Looper.getMainLooper())
    private var done = false
    private var polls = 0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = Prefs(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#0A0A12"))
        }
        status = TextView(this).apply {
            text = "🎓 AIBhai portal khol raha hai… login ho to attendance page kholo, main khud padh lunga"
            setTextColor(Color.WHITE)
            textSize = 13f
            gravity = Gravity.CENTER
            setPadding(24, 28, 24, 20)
            setBackgroundColor(Color.parseColor("#1F1F2D"))
        }
        web = WebView(this)
        root.addView(status, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(web, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(root)

        CookieManager.getInstance().setAcceptCookie(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadWithOverviewMode = true
        web.settings.useWideViewPort = true
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                autofill(prefs)
                scheduleScan(prefs)
            }
        }
        val start = prefs.portalLastPage.ifBlank { prefs.portalUrl }
        web.loadUrl(if (start.startsWith("http")) start else "https://$start")
        scheduleScan(prefs)
    }

    private fun autofill(prefs: Prefs) {
        val roll = prefs.rollNo.replace("'", "")
        if (roll.isBlank()) return
        val js = """
            (function(){
              var ins=document.querySelectorAll('input');
              for(var i=0;i<ins.length;i++){
                var e=ins[i]; var k=((e.name||'')+' '+(e.id||'')+' '+(e.placeholder||'')+' '+(e.getAttribute('aria-label')||'')).toLowerCase();
                if(e.type!='password' && !e.value && /roll|user|enrol|admission|login|student|id|reg/.test(k)){
                  e.value='$roll'; e.dispatchEvent(new Event('input',{bubbles:true})); e.dispatchEvent(new Event('change',{bubbles:true}));
                }
              }
            })();
        """.trimIndent()
        try {
            web.evaluateJavascript(js, null)
        } catch (e: Exception) {
        }
    }

    private fun scheduleScan(prefs: Prefs) {
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({ scan(prefs) }, 1800)
    }

    private fun scan(prefs: Prefs) {
        if (done) return
        polls++
        web.evaluateJavascript("(function(){return document.body ? document.body.innerText : ''})()") { raw ->
            val text = try {
                org.json.JSONTokener(raw).nextValue() as? String ?: ""
            } catch (e: Exception) {
                ""
            }
            val rows = PortalSkill.parse(text)
            val looksAttendance = Regex("attendance|attended|present|absent", RegexOption.IGNORE_CASE).containsMatchIn(text)
            if (rows.isNotEmpty() && looksAttendance) {
                done = true
                prefs.portalLastPage = web.url ?: ""
                CookieManager.getInstance().flush()
                status.text = "✅ Attendance mil gayi (${rows.size} subjects). AIBhai bol raha hai…"
                PortalBridge.pending?.complete(rows)
                handler.postDelayed({ finish() }, 700)
            } else {
                val hasPassword = text.isNotBlank() && Regex("password", RegexOption.IGNORE_CASE).containsMatchIn(text)
                status.text = if (hasPassword) "🔐 Ek baar login karo (roll no. bhar diya hai). Phir attendance page kholo."
                else "🔎 Attendance page dhundh raha hoon… menu se 'Attendance' kholo"
                if (polls < 90) handler.postDelayed({ scan(prefs) }, 2000)
            }
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        if (!done) PortalBridge.pending?.complete(emptyList())
        CookieManager.getInstance().flush()
        super.onDestroy()
    }
}
