package com.aibhai.app.core

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Level-3 agent audit trail: every command, what AIBhai decided, whether it was
 * verified, and whether a human approved it. Stored only on the phone.
 */
object ActionLog {
    data class Entry(
        val time: Long,
        val heard: String,
        val skill: String,
        val result: String,
        val status: String // ok | verified | failed | needs_input | needs_approval | approved | cancelled | unknown
    )

    private val list = ArrayList<Entry>()
    private var loaded = false

    private fun file(ctx: Context) = File(ctx.filesDir, "action_log.json")

    @Synchronized
    private fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = file(ctx)
            if (!f.exists()) return
            val a = JSONArray(f.readText())
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                list.add(Entry(o.optLong("m"), o.optString("h"), o.optString("k"), o.optString("r"), o.optString("s")))
            }
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun add(ctx: Context, heard: String, skill: String, result: String, status: String) {
        load(ctx)
        list.add(Entry(System.currentTimeMillis(), heard, skill, result, status))
        while (list.size > 300) list.removeAt(0)
        try {
            val a = JSONArray()
            list.forEach {
                a.put(JSONObject().put("m", it.time).put("h", it.heard).put("k", it.skill).put("r", it.result).put("s", it.status))
            }
            file(ctx).writeText(a.toString())
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun all(ctx: Context): List<Entry> {
        load(ctx)
        return list.reversed()
    }

    @Synchronized
    fun clear(ctx: Context) {
        load(ctx)
        list.clear()
        file(ctx).delete()
    }

    fun statusFor(r: Reply): String = when {
        r.status.isNotBlank() -> r.status
        r.kind == Kind.ERROR -> "failed"
        r.kind == Kind.WARN -> "needs_input"
        else -> "ok"
    }
}
