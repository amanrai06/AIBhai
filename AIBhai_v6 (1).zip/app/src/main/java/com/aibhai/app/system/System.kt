package com.aibhai.app.system

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.role.RoleManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.service.quicksettings.TileService
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.aibhai.app.AssistActivity
import com.aibhai.app.MainActivity
import com.aibhai.app.R
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class Notif(
    val pkg: String,
    val app: String,
    val title: String,
    val text: String,
    val time: Long
)

/** Keeps the last ~2 days of notifications on the phone only (private, offline). */
object NotificationStore {
    private val list = ArrayList<Notif>()
    private var loaded = false

    private fun file(ctx: Context) = File(ctx.filesDir, "notifs.json")

    @Synchronized
    private fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = file(ctx)
            if (!f.exists()) return
            val arr = JSONArray(f.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                list.add(Notif(o.optString("p"), o.optString("a"), o.optString("t"), o.optString("x"), o.optLong("m")))
            }
        } catch (e: Exception) {
        }
    }

    @Synchronized
    private fun save(ctx: Context) {
        try {
            val arr = JSONArray()
            for (n in list) {
                arr.put(JSONObject().put("p", n.pkg).put("a", n.app).put("t", n.title).put("x", n.text).put("m", n.time))
            }
            file(ctx).writeText(arr.toString())
        } catch (e: Exception) {
        }
    }

    @Synchronized
    fun add(ctx: Context, n: Notif) {
        load(ctx)
        val dup = list.any { it.pkg == n.pkg && it.title == n.title && it.text == n.text && kotlin.math.abs(it.time - n.time) < 10 * 60_000L }
        if (dup) return
        list.add(n)
        val cutoff = System.currentTimeMillis() - 48 * 3600_000L
        list.removeAll { it.time < cutoff }
        while (list.size > 800) list.removeAt(0)
        save(ctx)
    }

    @Synchronized
    fun since(ctx: Context, t: Long): List<Notif> {
        load(ctx)
        return list.filter { it.time >= t }.toList()
    }
}

class AIBhaiNotificationListener : NotificationListenerService() {
    private val skipPkgs = setOf("android", "com.android.systemui", "com.android.providers.downloads")

    override fun onListenerConnected() {
        try {
            activeNotifications?.forEach { handle(it) }
        } catch (e: Exception) {
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null) {
            try {
                handle(sbn)
            } catch (e: Exception) {
            }
        }
    }

    private var tts: android.speech.tts.TextToSpeech? = null
    private var lastCallKey = ""
    private var lastCallAt = 0L

    private fun announce(text: String) {
        val t = tts
        if (t == null) {
            tts = android.speech.tts.TextToSpeech(this) { st ->
                if (st == android.speech.tts.TextToSpeech.SUCCESS) {
                    tts?.setLanguage(java.util.Locale("hi", "IN"))
                    tts?.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "call")
                }
            }
        } else {
            t.speak(text, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "call")
        }
    }

    override fun onDestroy() {
        tts?.shutdown()
        tts = null
        super.onDestroy()
    }

    private fun maybeAnnounceCall(sbn: StatusBarNotification, n: Notification) {
        if (n.category != Notification.CATEGORY_CALL) return
        if (!com.aibhai.app.Prefs(this).announceCalls) return
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = ex.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
        val incoming = n.fullScreenIntent != null || Regex("incoming|calling|आ रही|इनकमिंग", RegexOption.IGNORE_CASE).containsMatchIn(text + " " + title)
        if (!incoming || title.isBlank()) return
        val key = sbn.packageName + title
        if (key == lastCallKey && System.currentTimeMillis() - lastCallAt < 30_000L) return
        lastCallKey = key
        lastCallAt = System.currentTimeMillis()
        announce("$title ka call aa raha hai")
    }

    private fun handle(sbn: StatusBarNotification) {
        if (sbn.packageName == packageName || sbn.packageName in skipPkgs) return
        val n = sbn.notification ?: return
        try {
            maybeAnnounceCall(sbn, n)
        } catch (e: Exception) {
        }
        if ((n.flags and Notification.FLAG_ONGOING_EVENT) != 0) return
        if ((n.flags and Notification.FLAG_GROUP_SUMMARY) != 0) return
        val ex = n.extras ?: return
        val title = ex.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim() ?: ""
        val text = (ex.getCharSequence(Notification.EXTRA_BIG_TEXT) ?: ex.getCharSequence(Notification.EXTRA_TEXT))
            ?.toString()?.trim() ?: ""
        if (title.isBlank() && text.isBlank()) return
        NotificationStore.add(this, Notif(sbn.packageName, appLabel(sbn.packageName), title, text, sbn.postTime))
    }

    private fun appLabel(pkg: String): String = try {
        val pm = packageManager
        pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
    } catch (e: Exception) {
        pkg.substringAfterLast('.')
    }
}

object Notifs {
    private const val CH = "aibhai_reminders"

    private fun ensure(ctx: Context) {
        val nm = ctx.getSystemService(NotificationManager::class.java) ?: return
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(NotificationChannel(CH, "AIBhai Reminders", NotificationManager.IMPORTANCE_HIGH))
        }
    }

    fun show(ctx: Context, title: String, text: String, id: Int) {
        ensure(ctx)
        val open = PendingIntent.getActivity(
            ctx, id,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(ctx, CH)
            .setSmallIcon(R.drawable.ic_stat_aibhai)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try {
            NotificationManagerCompat.from(ctx).notify(id, n)
        } catch (e: SecurityException) {
        }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val msg = intent.getStringExtra("msg") ?: "Reminder"
        Notifs.show(context, "⏰ AIBhai: yaad hai na?", msg, intent.getIntExtra("id", 1))
    }
}

class AIBhaiTile : TileService() {
    override fun onClick() {
        super.onClick()
        val i = Intent(this, AssistActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            .putExtra("listen", true)
        if (Build.VERSION.SDK_INT >= 34) {
            val pi = PendingIntent.getActivity(this, 7, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
            startActivityAndCollapse(pi)
        } else {
            @Suppress("DEPRECATION")
            startActivityAndCollapse(i)
        }
    }
}

object Perms {
    fun granted(ctx: Context, p: String): Boolean =
        ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED

    fun mic(ctx: Context) = granted(ctx, Manifest.permission.RECORD_AUDIO)
    fun contacts(ctx: Context) = granted(ctx, Manifest.permission.READ_CONTACTS)
    fun call(ctx: Context) = granted(ctx, Manifest.permission.CALL_PHONE)
    fun postNotif(ctx: Context) = Build.VERSION.SDK_INT < 33 || granted(ctx, Manifest.permission.POST_NOTIFICATIONS)

    fun files(ctx: Context): Boolean = if (Build.VERSION.SDK_INT >= 30) {
        Environment.isExternalStorageManager()
    } else {
        granted(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE)
    }

    fun notifAccess(ctx: Context): Boolean =
        NotificationManagerCompat.getEnabledListenerPackages(ctx).contains(ctx.packageName)

    fun isAssistant(ctx: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val rm = ctx.getSystemService(RoleManager::class.java)
                if (rm != null && rm.isRoleHeld(RoleManager.ROLE_ASSISTANT)) return true
            } catch (e: Exception) {
            }
        }
        return try {
            val s = Settings.Secure.getString(ctx.contentResolver, "assistant") ?: ""
            s.contains(ctx.packageName)
        } catch (e: Exception) {
            false
        }
    }

    fun battery(ctx: Context): Boolean = try {
        ctx.getSystemService(PowerManager::class.java)?.isIgnoringBatteryOptimizations(ctx.packageName) == true
    } catch (e: Exception) {
        false
    }

    fun missingCount(ctx: Context): Int =
        listOf(mic(ctx), files(ctx), notifAccess(ctx), isAssistant(ctx)).count { !it }

    private fun start(ctx: Context, vararg intents: Intent) {
        for (i in intents) {
            try {
                ctx.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return
            } catch (e: Exception) {
            }
        }
    }

    private fun pkgUri(ctx: Context) = Uri.parse("package:" + ctx.packageName)

    fun openAllFiles(ctx: Context) {
        if (Build.VERSION.SDK_INT >= 30) {
            start(
                ctx,
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, pkgUri(ctx)),
                Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)
            )
        } else {
            openAppDetails(ctx)
        }
    }

    fun openNotifAccess(ctx: Context) = start(
        ctx,
        Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS),
        Intent(Settings.ACTION_SETTINGS)
    )

    fun openAssistant(ctx: Context) = start(
        ctx,
        Intent(Settings.ACTION_VOICE_INPUT_SETTINGS),
        Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS),
        Intent(Settings.ACTION_SETTINGS)
    )

    fun openBattery(ctx: Context) = start(
        ctx,
        Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, pkgUri(ctx)),
        Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)
    )

    fun openDnd(ctx: Context) = start(ctx, Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS))

    fun openAppDetails(ctx: Context) = start(ctx, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgUri(ctx)))
}
