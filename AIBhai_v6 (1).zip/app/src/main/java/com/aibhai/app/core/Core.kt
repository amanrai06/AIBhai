package com.aibhai.app.core

import android.content.Context
import android.content.Intent
import com.aibhai.app.Prefs

enum class Kind { INFO, SUCCESS, WARN, ERROR, MESSAGES, FILES, TASKS }

class ReplyAction(val label: String, val run: suspend () -> Reply?)

data class Reply(
    val text: String,
    val speak: String? = text,
    val kind: Kind = Kind.INFO,
    val items: List<String> = emptyList(),
    val actions: List<ReplyAction> = emptyList(),
    val teachable: Boolean = false,
    val lang: String = "hi",
    val status: String = ""
)

class Env(
    val ctx: Context,
    val prefs: Prefs,
    val requestPerms: (Array<String>) -> Unit,
    val hideUi: () -> Unit = {},
    val authGate: suspend (String) -> Boolean = { true }
) {
    fun launch(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }

    val name: String get() = prefs.userName.ifBlank { "Bhai" }
}

class Cmd(val raw: String, val norm: String) {
    val s: String = Txt.simplify(norm)
    val rawLower: String = raw.lowercase()
    val lang: String = Txt.detectLang(raw)
    val en: Boolean get() = lang == "en"

    fun has(vararg kws: String): Boolean = kws.any { Txt.has(s, it) }

    val numbers: List<Double> by lazy {
        Regex("\\d+(?:\\.\\d+)?").findAll(norm).map { it.value.toDouble() }.toList()
    }

    /** pick Hinglish or English text depending on how the user spoke */
    fun t(hi: String, en: String): String = if (this.en) en else hi

    fun reply(
        hi: String,
        en: String,
        speakHi: String? = hi,
        speakEn: String? = en,
        kind: Kind = Kind.INFO,
        items: List<String> = emptyList(),
        actions: List<ReplyAction> = emptyList(),
        teachable: Boolean = false,
        status: String = ""
    ): Reply = Reply(
        text = t(hi, en),
        speak = if (this.en) speakEn else speakHi,
        kind = kind,
        items = items,
        actions = actions,
        teachable = teachable,
        lang = lang,
        status = status
    )
}

interface Skill {
    fun matches(c: Cmd, env: Env): Boolean
    suspend fun run(c: Cmd, env: Env): Reply
}

object Subjects {
    val map: LinkedHashMap<String, List<String>> = linkedMapOf(
        "Maths" to listOf("maths", "math", "mathematics", "ganit", "calculus", "integration", "differentiation", "matrix", "matrices", "algebra", "m1"),
        "EGD" to listOf("egd", "drawing", "graphics", "projection", "isometric", "orthographic", "autocad", "engineering graphics"),
        "BEEE" to listOf("beee", "bee", "electrical", "electronics", "circuit", "diode", "transistor", "kirchhoff", "transformer"),
        "Physics" to listOf("physics", "optics", "quantum", "laser", "bhautiki"),
        "Chemistry" to listOf("chemistry", "chem", "rasayan"),
        "Communication" to listOf("communication", "english", "grammar", "soft skills", "report writing"),
        "Mechanics" to listOf("mechanics", "thermodynamics", "thermo", "fluid", "bernoulli", "mechanical", "manufacturing", "workshop"),
        "EV" to listOf("ev", "electric vehicle", "bms", "motor controller")
    )

    fun detect(simplified: String): String? = detectAll(simplified).firstOrNull()

    fun detectAll(simplified: String): List<String> =
        map.filter { (_, kws) -> kws.any { Txt.has(simplified, it) } }.keys.toList()
}
