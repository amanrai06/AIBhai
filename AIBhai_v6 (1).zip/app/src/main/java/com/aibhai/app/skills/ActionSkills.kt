package com.aibhai.app.skills

import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.Settings
import com.aibhai.app.BuildConfig
import com.aibhai.app.core.ActionLog
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Txt
import com.aibhai.app.system.Perms
import com.aibhai.app.system.ReminderReceiver
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val timeFmt = SimpleDateFormat("h:mm a", Locale.US)
private val dateFmt = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.US)

// =================================================================== TEACH (learns your words)

object TeachSkill : Skill {
    private val re = Regex("^(?:yaad rakh(?:o|na)?|yad rakh(?:o|na)?|sikho|seekho|sikh lo|seekh lo|learn|remember)\\s+(.+?)\\s+(?:matlab|mtlab|mtlb|ka matlab|means|yaani|mean)\\s+(.+)$")

    override fun matches(c: Cmd, env: Env) = re.containsMatchIn(c.norm)

    override suspend fun run(c: Cmd, env: Env): Reply {
        val m = re.find(c.norm)!!
        val k = m.groupValues[1].trim()
        val v = m.groupValues[2].trim()
        env.prefs.addLearned(k, v)
        return c.reply(
            "🧠 Seekh liya! Ab '$k' bologe to main '$v' samjhunga.",
            "🧠 Learned! From now on '$k' means '$v'.",
            kind = Kind.SUCCESS
        )
    }
}

// =================================================================== GREETINGS / HELP

object GreetSkill : Skill {
    private val greet = arrayOf(
        "hello", "hi", "hey", "namaste", "namaskar", "ram ram", "radhe radhe", "kaise ho", "kya haal", "kya hal",
        "sat sri akal", "jai shri krishna", "how are you", "kaisan", "salam"
    )
    private val thanks = arrayOf("thank", "thanks", "shukriya", "dhanyavad", "dhanyawad", "thnx", "thx")
    private val who = arrayOf("kaun ho", "kon ho", "who are you", "tumhara naam", "your name", "kya ho tum")
    private val help = arrayOf("kya kar sakte", "kya kya kar", "what can you do", "help", "madad", "features")

    override fun matches(c: Cmd, env: Env): Boolean {
        val short = c.norm.split(' ').size <= 5
        return (short && (c.has(*greet) || c.has(*thanks))) || c.has(*who) || c.has(*help)
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val n = env.name
        return when {
            c.has(*help) -> c.reply(
                "Main ye sab kar sakta hoon 💪", "Here's what I can do 💪",
                speakHi = "Main messages bata sakta hoon, files move kar sakta hoon, aaj ke kaam yaad rakh sakta hoon, attendance, alarm, reminder, call, WhatsApp, calculations aur bahut kuch.",
                speakEn = "I can read your important messages, move files, track tasks and attendance, set alarms and reminders, call, WhatsApp, calculate and more.",
                items = listOf(
                    "📬 \"Aaj kaun se important message aaye?\"",
                    "📝 \"Aaj mujhe assignment aur gym karna hai\" → \"Aaj kya karna hai?\"",
                    "🗂️ \"Communication wali PDF ko English folder mein daalo\"",
                    "📥 \"WhatsApp ke notes collect karo\" • \"Downloads organize karo\"",
                    "📊 \"Aaj Maths attend kiya\" • \"Attendance batao\"",
                    "⏰ \"Kal subah 6 baje alarm\" • \"10 minute baad yaad dilana ki chai\"",
                    "📞 \"Papa ko call karo\" • 💬 \"Rahul ko WhatsApp pe bolo main aa raha hoon\"",
                    "🧮 \"500 newton 20 mm rod ka stress\" • \"12 volt 4 ohm current\" • \"3 kwh battery range\"",
                    "🔦 Torch, 🔊 volume, 🔕 class mode, 🔋 battery, 🕐 time",
                    "🧠 \"Yaad rakh mera locker number 42 hai\" → \"Locker number kya tha?\"",
                    "📐 \"Bernoulli formula\" • ❓ \"Maths quiz lo\" • ⏳ \"Mid sem 20 november ko hai\"",
                    "📅 \"Agla lecture kaunsa hai?\" • 🎯 \"Focus mode 25 minute\" • 🎧 \"Lecture record karo\"",
                    "📷 \"Photo se text padho\" • 💸 \"50 rupay chai pe kharch kiye\" • 🌙 \"Good night\"",
                    "🔌 \"3 kwh battery 1 kw charger charging time\" • 🔁 \"10 kw to hp\" • 📊 \"Daily report\"",
                    "🔗 \"Torch on karo phir 10 minute ka timer lagao\" (multi-step)",
                    "📁 \"Sem1 naam ka folder banao aur usme Maths aur BEEE ki PDF daalo\"",
                    "📖 \"Maths padhai shuru\" → \"padhai band\" → \"study report\" (streak 🔥)",
                    "🚗 \"EV roadmap\" • \"BMS seekh liya\" • ⚡ \"Aaj ka EV concept\"",
                    "📄 \"Resume mein add karo: …\" • ❓ \"Doubt note karo: …\" • 🃏 \"Revision karao\"",
                    "🚀 \"EV competitions batao\" • 📝 \"GATE quiz lo\"",
                    "📥 \"Ye gaana download karo audio mein\" (VidMate) • YouTube se link Share → AIBhai",
                    "✍️ \"Is photo pe story mein kya likhu? attitude\" • Gallery se photo Share → AIBhai",
                    "🧠 \"Sikho kholde matlab kholo\" — apne words sikhao"
                )
            )
            c.has(*thanks) -> c.reply("Koi baat nahi $n, hamesha haazir 🙏", "Anytime, $n 🙏")
            c.has(*who) -> c.reply(
                "Main AIBhai hoon — aapka apna desi AI assistant 🤖🇮🇳. Bolo, kya kaam hai?",
                "I'm AIBhai — your personal AI assistant 🤖🇮🇳. What can I do for you?"
            )
            else -> c.reply("Ram Ram $n! 😄 Bolo, kya kaam hai?", "Hey $n! 😄 What can I do for you?")
        }
    }
}

// =================================================================== DAILY BRIEFING (proactive)

object BriefingSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has(
        "good morning", "briefing", "aaj ka plan", "update do", "aaj ka update", "status do", "subah ki report",
        "din kaisa", "daily report", "morning report", "aaj ka hal"
    )

    override suspend fun run(c: Cmd, env: Env): Reply {
        val items = ArrayList<String>()
        val hi = StringBuilder()
        val en = StringBuilder()
        val now = Date()
        hi.append("Good morning ${env.name}! Abhi ${timeFmt.format(now)} hue hain. ")
        en.append("Hi ${env.name}! It's ${timeFmt.format(now)}. ")
        items.add("🗓️ ${dateFmt.format(now)} • ${timeFmt.format(now)}")
        val bat = PhoneSkill.batteryPct(env.ctx)
        if (bat >= 0) {
            items.add("🔋 Battery $bat%")
            if (bat < 30) {
                hi.append("Battery $bat% hai, charge kar lo. ")
                en.append("Battery is at $bat%, please charge. ")
            }
        }
        val (total, imp) = MessagesSkill.counts(env)
        if (total >= 0) {
            items.add("📬 Aaj $total notifications • $imp important")
            hi.append("Aaj $total notifications aaye, $imp important. ")
            en.append("$total notifications today, $imp important. ")
        }
        val tasks = try {
            JSONArray(env.prefs.tasks)
        } catch (e: Exception) {
            JSONArray()
        }
        val pending = (0 until tasks.length()).map { tasks.getJSONObject(it) }.filter { !it.optBoolean("done") }.map { it.optString("t") }
        if (pending.isNotEmpty()) {
            items.add("📝 Kaam: " + pending.joinToString(", "))
            hi.append("Aaj ${pending.size} kaam bache hain: ${pending.joinToString(", ")}. ")
            en.append("You have ${pending.size} tasks: ${pending.joinToString(", ")}. ")
        }
        val low = AttendanceSkill.lowSubjects(env)
        if (low.isNotEmpty()) {
            items.add("⚠️ 75% se kam: " + low.joinToString(", "))
            hi.append("Dhyan do, ${low.joinToString(", ")} ki attendance 75 percent se kam hai. ")
            en.append("Careful, attendance below 75% in ${low.joinToString(", ")}. ")
        }
        val rems = TimeSkill.upcomingToday(env)
        if (rems.isNotEmpty()) {
            items.addAll(rems.map { "⏰ $it" })
            hi.append("Aaj ${rems.size} reminder hain. ")
            en.append("${rems.size} reminders today. ")
        }
        val pledges = MistakeSkill.pledges(env)
        if (pledges.isNotEmpty()) {
            items.addAll(pledges.map { "🤝 Pledge: $it" })
            hi.append("Yaad rakhna, aapne ${pledges.size} galtiyan na dohrane ka pledge liya hai. ")
            en.append("Remember your ${pledges.size} pledges. ")
        }
        NewsSkill.topEvHeadline()?.let { h ->
            items.add("⚡ EV news: $h")
            hi.append("Aaj ki EV khabar: $h. ")
            en.append("Today's EV news: $h. ")
        }
        hi.append("Chalo, aaj ka din dhamakedaar banate hain! 💪")
        en.append("Let's make today awesome! 💪")
        return c.reply("☀️ Aaj ka briefing", "☀️ Today's briefing", speakHi = hi.toString(), speakEn = en.toString(), items = items)
    }
}

// =================================================================== ALARM / TIMER / REMINDER

object TimeSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has(
        "alarm", "alaram", "timer", "taimar", "yaad dila", "yad dila", "remind", "reminder", "yaad dilana", "jaga dena", "utha dena"
    )

    private val numWords = linkedMapOf(
        "gyaarah" to 11, "gyarah" to 11, "baarah" to 12, "barah" to 12, "pandrah" to 15, "pandra" to 15,
        "chaalees" to 40, "chalis" to 40, "pachaas" to 50, "pachas" to 50, "eleven" to 11, "twelve" to 12,
        "fifteen" to 15, "twenty" to 20, "thirty" to 30, "chaar" to 4, "paanch" to 5, "chhah" to 6, "chhe" to 6,
        "saat" to 7, "aath" to 8, "teen" to 3, "bees" to 20, "tees" to 30, "char" to 4, "panch" to 5, "cheh" to 6,
        "che" to 6, "sat" to 7, "ath" to 8, "nau" to 9, "das" to 10, "tin" to 3, "ek" to 1, "do" to 2,
        "one" to 1, "two" to 2, "three" to 3, "four" to 4, "five" to 5, "six" to 6, "seven" to 7, "eight" to 8,
        "nine" to 9, "ten" to 10
    )

    fun wordsToNum(n: String): String {
        var t = " $n "
        t = t.replace(Regex("\\bdedh\\s+baje"), "1:30 baje").replace(Regex("\\b(dhai|dhaai|adhai)\\s+baje"), "2:30 baje")
        val units = "(?=\\s*(?:baje|bje|minute|minutes|min|mins|minat|mint|second|seconds|sec|ghante|ghanta|hour|hours|am|pm|o clock))"
        for ((w, v) in numWords) t = t.replace(Regex("(?<![a-z])$w(?![a-z])$units"), v.toString())
        for ((w, v) in numWords) t = t.replace(Regex("(?<=(?:saade|sade|sava|sawa|paune) )$w(?![a-z])"), v.toString())
        return t.trim()
    }

    fun durationSec(n: String): Long {
        var total = 0L
        Regex("(\\d+(?:\\.\\d+)?)\\s*(seconds|second|secs|sec|sekand|minutes|minute|mins|min|minat|mint|ghanton|ghante|ghanta|hours|hour|hrs|hr)")
            .findAll(n).forEach {
                val v = it.groupValues[1].toDouble()
                val u = it.groupValues[2]
                total += (when {
                    u.startsWith("s") -> v
                    u.startsWith("m") -> v * 60
                    else -> v * 3600
                }).toLong()
            }
        if (Regex("\\bdedh\\s*(ghanta|ghante|hour)").containsMatchIn(n)) total += 5400
        if (Regex("\\b(adha|aadha|half)\\s*(ghanta|ghante|hour)").containsMatchIn(n)) total += 1800
        return total
    }

    fun clockTime(n: String): Calendar? {
        var h = -1
        var m = 0
        Regex("(\\d{1,2})[:.](\\d{2})").find(n)?.let {
            h = it.groupValues[1].toInt()
            m = it.groupValues[2].toInt()
        }
        if (h < 0) Regex("(\\d{1,2})\\s*(?:baje|bje|baj|am|pm|o clock|oclock)").find(n)?.let { h = it.groupValues[1].toInt() }
        if (h < 0) return null
        when {
            Regex("\\b(saade|sade|sadhe)\\s*\\d").containsMatchIn(n) -> m = 30
            Regex("\\b(sava|sawa|savaa)\\s*\\d").containsMatchIn(n) -> m = 15
            Regex("\\b(paune|pone)\\s*\\d").containsMatchIn(n) -> {
                m = 45
                h -= 1
            }
        }
        if (h !in 0..23 || m !in 0..59) return null
        val pm = Regex("\\b(pm|shaam|sham|evening|raat|rat|night|dopahar|dopehar|afternoon)\\b").containsMatchIn(n)
        val am = Regex("\\b(am|subah|subha|savere|sawere|morning)\\b").containsMatchIn(n)
        if (pm && h in 1..11) {
            val earlyNight = Regex("\\b(raat|rat|night)\\b").containsMatchIn(n) && h <= 4
            if (!earlyNight) h += 12
        }
        if (am && h == 12) h = 0
        val now = Calendar.getInstance()
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, h)
            set(Calendar.MINUTE, m)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val tomorrow = Regex("\\b(kal|tomorrow)\\b").containsMatchIn(n)
        if (tomorrow) {
            cal.add(Calendar.DAY_OF_MONTH, 1)
        } else if (!am && !pm && h in 1..11) {
            if (cal.before(now)) {
                cal.add(Calendar.HOUR_OF_DAY, 12)
                if (cal.before(now)) cal.add(Calendar.HOUR_OF_DAY, 12)
            }
        } else if (cal.before(now)) {
            cal.add(Calendar.DAY_OF_MONTH, 1)
        }
        return cal
    }

    private fun fmtDur(sec: Long): String {
        val h = sec / 3600
        val m = (sec % 3600) / 60
        val s = sec % 60
        val parts = ArrayList<String>()
        if (h > 0) parts.add("$h ghanta")
        if (m > 0) parts.add("$m minute")
        if (s > 0) parts.add("$s second")
        return parts.joinToString(" ")
    }

    private fun whenText(cal: Calendar): String {
        val today = Calendar.getInstance()
        val day = when (cal.get(Calendar.DAY_OF_YEAR) - today.get(Calendar.DAY_OF_YEAR)) {
            0 -> "aaj"
            1 -> "kal"
            else -> SimpleDateFormat("d MMM", Locale.US).format(cal.time)
        }
        return "$day ${timeFmt.format(cal.time)}"
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val n = wordsToNum(c.norm)
        return when {
            c.has("timer", "taimar") -> timer(c, n, env)
            c.has("alarm", "alaram", "jaga dena", "utha dena") -> alarm(c, n, env)
            else -> reminder(c, n, env)
        }
    }

    private fun timer(c: Cmd, n: String, env: Env): Reply {
        val sec = durationSec(n)
        if (sec <= 0) return c.reply("Kitne time ka timer? Jaise '10 minute ka timer'.", "How long? e.g. '10 minute timer'.", kind = Kind.WARN)
        val i = Intent(AlarmClock.ACTION_SET_TIMER)
            .putExtra(AlarmClock.EXTRA_LENGTH, sec.coerceAtMost(86400).toInt())
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            .putExtra(AlarmClock.EXTRA_MESSAGE, "AIBhai timer")
        val ok = env.launch(i)
        return if (ok) c.reply("⏱️ ${fmtDur(sec)} ka timer chalu", "⏱️ Timer set for ${fmtDur(sec)}", kind = Kind.SUCCESS, status = "ok")
        else c.reply("Clock app ne timer accept nahi kiya 😕", "The clock app didn't accept the timer 😕", kind = Kind.ERROR)
    }

    private fun alarm(c: Cmd, n: String, env: Env): Reply {
        val cal = clockTime(n) ?: durationSec(n).takeIf { it > 0 }?.let { s ->
            Calendar.getInstance().apply { add(Calendar.SECOND, s.toInt()) }
        } ?: return c.reply("Kitne baje ka alarm? Jaise 'kal subah 6 baje alarm'.", "What time? e.g. 'alarm at 6 am tomorrow'.", kind = Kind.WARN)
        val i = Intent(AlarmClock.ACTION_SET_ALARM)
            .putExtra(AlarmClock.EXTRA_HOUR, cal.get(Calendar.HOUR_OF_DAY))
            .putExtra(AlarmClock.EXTRA_MINUTES, cal.get(Calendar.MINUTE))
            .putExtra(AlarmClock.EXTRA_MESSAGE, "AIBhai")
            .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        val ok = env.launch(i)
        return if (ok) c.reply("⏰ Alarm set: ${whenText(cal)}", "⏰ Alarm set: ${whenText(cal)}", kind = Kind.SUCCESS)
        else c.reply("Clock app ne alarm accept nahi kiya 😕", "The clock app didn't accept the alarm 😕", kind = Kind.ERROR)
    }

    private fun reminder(c: Cmd, n: String, env: Env): Reply {
        val dur = durationSec(n)
        val at = clockTime(n)?.timeInMillis ?: if (dur > 0) System.currentTimeMillis() + dur * 1000 else null
        if (at == null) {
            return c.reply(
                "Kab yaad dilaun? Jaise: '10 minute baad yaad dilana ki chai bana lo' ya 'shaam 5 baje yaad dilana'.",
                "When should I remind you? e.g. 'remind me in 10 minutes to call mom'.",
                kind = Kind.WARN, status = "needs_input"
            )
        }
        var msg = Regex("ya+d\\s*dila\\w*\\s+(?:ki|ke|to|that)?\\s*(.+)").find(n)?.groupValues?.get(1)
            ?: Regex("remind(?:er)?\\s*(?:me)?\\s*(?:to|that|ki|about)?\\s*(.+)").find(n)?.groupValues?.get(1)
            ?: Regex("(.+?)\\s+(?:ka|ki|ke liye)?\\s*ya+d\\s*dila").find(n)?.groupValues?.get(1)
            ?: ""
        msg = msg.replace(Regex("\\d+(?:[:.]\\d+)?\\s*(?:baje|bje|minutes|minute|min|minat|ghante|ghanta|hours|hour|seconds|second|sec|am|pm)?\\s*(?:baad|bad|me|mein|men|pe|par|ko|in|at|after)?"), " ")
            .replace(Regex("\\b(kal|subah|shaam|sham|raat|aaj|mujhe|please|remind me|reminder|yaad dilana|yaad dila|dena|do|tomorrow|today)\\b"), " ")
            .replace(Regex("\\s+"), " ").trim()
        if (msg.isBlank()) msg = c.t("Aapne reminder lagaya tha", "Your reminder")
        if (Build.VERSION.SDK_INT >= 33 && !Perms.postNotif(env.ctx)) env.requestPerms(arrayOf(Manifest.permission.POST_NOTIFICATIONS))
        val id = env.prefs.reminderSeq + 1
        env.prefs.reminderSeq = id
        val am = env.ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            env.ctx, id,
            Intent(env.ctx, ReminderReceiver::class.java).putExtra("msg", msg).putExtra("id", id),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
        saveReminder(env, at, msg)
        val cal = Calendar.getInstance().apply { timeInMillis = at }
        return c.reply(
            "🔔 Reminder: \"$msg\" — ${whenText(cal)}",
            "🔔 Reminder: \"$msg\" — ${whenText(cal)}",
            speakHi = "Theek hai, ${whenText(cal)} yaad dila dunga: $msg",
            speakEn = "Okay, I'll remind you ${whenText(cal)}: $msg",
            kind = Kind.SUCCESS
        )
    }

    private fun saveReminder(env: Env, at: Long, msg: String) {
        val a = try {
            JSONArray(env.prefs.reminders)
        } catch (e: Exception) {
            JSONArray()
        }
        val fresh = JSONArray()
        val now = System.currentTimeMillis()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.optLong("at") > now) fresh.put(o)
        }
        fresh.put(JSONObject().put("at", at).put("msg", msg))
        env.prefs.reminders = fresh.toString()
    }

    fun upcomingToday(env: Env): List<String> {
        val a = try {
            JSONArray(env.prefs.reminders)
        } catch (e: Exception) {
            JSONArray()
        }
        val now = System.currentTimeMillis()
        val end = startOfToday() + 86400_000L
        return (0 until a.length()).map { a.getJSONObject(it) }
            .filter { it.optLong("at") in now..end }
            .sortedBy { it.optLong("at") }
            .map { "${timeFmt.format(Date(it.optLong("at")))} — ${it.optString("msg")}" }
    }
}

// =================================================================== PHONE CONTROLS

object PhoneSkill : Skill {
    private val openWords = arrayOf("kholo", "open", "chalu", "on", "off", "band", "setting", "settings", "dikhao")

    private fun isVoice(c: Cmd) = c.has("nidhi", "adam") ||
        (c.has("awaaz", "awaz", "avaj", "voice", "aawaz") && c.has("badlo", "change", "badal", "switch"))

    private fun isTorch(c: Cmd) = c.has("torch", "tarch", "flash", "flashlight", "flash light", "batti")
    private fun isVolume(c: Cmd) = !isVoice(c) && c.has("volume", "valume", "awaaz", "awaz", "avaj", "sound", "aawaz")
    private fun isRinger(c: Cmd) = c.has("silent", "vibrate", "vibration", "class mode", "dnd", "do not disturb", "normal mode", "ring mode", "general mode")
    private fun isBattery(c: Cmd) = c.has("battery", "betri", "bettery", "charging") && !c.has("kwh")
    private fun isTime(c: Cmd) = (c.has("time", "samay", "tym") || c.norm.contains("kitne baje") || c.norm.contains("kya baja") || c.norm.contains("baj rahe")) &&
        !c.has("timer", "timetable", "alarm", "yaad", "remind")
    private fun isDate(c: Cmd) = c.has("date", "tarikh", "tareekh", "aaj kya din", "kaun sa din", "konsa din", "which day")
    private fun isSettings(c: Cmd) = c.has("wifi", "vifi", "wi fi", "bluetooth", "blutooth", "hotspot", "mobile data", "brightness", "location", "gps") && c.has(*openWords)

    override fun matches(c: Cmd, env: Env) =
        isVoice(c) || isTorch(c) || isVolume(c) || isRinger(c) || isBattery(c) || isTime(c) || isDate(c) || isSettings(c)

    fun batteryPct(ctx: Context): Int = try {
        ctx.getSystemService(BatteryManager::class.java).getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
    } catch (e: Exception) {
        -1
    }

    private fun off(c: Cmd) = c.has("band", "bandh", "off", "bujha", "bujhao", "close", "hatao", "turn off")

    override suspend fun run(c: Cmd, env: Env): Reply {
        val ctx = env.ctx
        when {
            isVoice(c) -> {
                val v = when {
                    c.has("nidhi") -> "nidhi"
                    c.has("adam") -> "adam"
                    else -> if (env.prefs.voice == "adam") "nidhi" else "adam"
                }
                env.prefs.voice = v
                return if (v == "nidhi") c.reply("🎙️ Ab main Nidhi ki awaaz mein bolungi 😊", "🎙️ Switched to Nidhi's voice 😊")
                else c.reply("🎙️ Ab main Adam ki awaaz mein bolunga 😎", "🎙️ Switched to Adam's voice 😎")
            }
            isTorch(c) -> {
                val on = !off(c)
                return try {
                    val cm = ctx.getSystemService(CameraManager::class.java)
                    val id = cm.cameraIdList.firstOrNull {
                        cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                    } ?: return c.reply("Is phone mein flash nahi mila.", "No flash found on this phone.", kind = Kind.WARN)
                    cm.setTorchMode(id, on)
                    c.reply(if (on) "🔦 Torch ON" else "🔦 Torch OFF", if (on) "🔦 Torch on" else "🔦 Torch off", kind = Kind.SUCCESS, speakHi = if (on) "Torch on" else "Torch band", speakEn = if (on) "Torch on" else "Torch off")
                } catch (e: Exception) {
                    c.reply("Torch nahi chal payi (camera busy?).", "Couldn't toggle the torch (camera busy?).", kind = Kind.ERROR)
                }
            }
            isVolume(c) -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val stream = if (c.has("ring", "ringtone", "call")) AudioManager.STREAM_RING else AudioManager.STREAM_MUSIC
                val max = am.getStreamMaxVolume(stream)
                val pct = Regex("(\\d{1,3})\\s*(?:%|percent|pratishat)?").find(c.norm)?.groupValues?.get(1)?.toIntOrNull()
                when {
                    c.has("mute", "chup", "band", "off") -> am.adjustStreamVolume(stream, AudioManager.ADJUST_MUTE, AudioManager.FLAG_SHOW_UI)
                    c.has("full", "max", "poora", "pura") -> am.setStreamVolume(stream, max, AudioManager.FLAG_SHOW_UI)
                    pct != null && pct in 0..100 -> am.setStreamVolume(stream, max * pct / 100, AudioManager.FLAG_SHOW_UI)
                    c.has("kam", "ghata", "ghatao", "down", "decrease", "dheere", "halka", "lower") -> repeat(3) {
                        am.adjustStreamVolume(stream, AudioManager.ADJUST_LOWER, if (it == 0) AudioManager.FLAG_SHOW_UI else 0)
                    }
                    else -> {
                        am.adjustStreamVolume(stream, AudioManager.ADJUST_UNMUTE, 0)
                        repeat(3) { am.adjustStreamVolume(stream, AudioManager.ADJUST_RAISE, if (it == 0) AudioManager.FLAG_SHOW_UI else 0) }
                    }
                }
                val now = am.getStreamVolume(stream) * 100 / max.coerceAtLeast(1)
                return c.reply("🔊 Volume: $now%", "🔊 Volume: $now%", kind = Kind.SUCCESS, speakHi = null, speakEn = null)
            }
            isRinger(c) -> {
                val am = ctx.getSystemService(AudioManager::class.java)
                val mode = when {
                    c.has("normal mode", "ring mode", "general mode", "normal") -> AudioManager.RINGER_MODE_NORMAL
                    c.has("silent") && !c.has("class mode") -> AudioManager.RINGER_MODE_SILENT
                    else -> AudioManager.RINGER_MODE_VIBRATE
                }
                return try {
                    am.ringerMode = mode
                    val label = when (mode) {
                        AudioManager.RINGER_MODE_NORMAL -> c.t("🔔 Normal mode", "🔔 Normal mode")
                        AudioManager.RINGER_MODE_SILENT -> c.t("🔕 Silent mode", "🔕 Silent mode")
                        else -> c.t("📳 Class mode (vibrate)", "📳 Vibrate mode")
                    }
                    c.reply(label, label, kind = Kind.SUCCESS)
                } catch (e: SecurityException) {
                    c.reply(
                        "Silent karne ke liye 'Do Not Disturb access' chahiye.", "I need 'Do Not Disturb access' for silent mode.",
                        kind = Kind.WARN,
                        actions = listOf(ReplyAction(c.t("Access do", "Give access")) {
                            Perms.openDnd(ctx)
                            null
                        })
                    )
                }
            }
            isBattery(c) -> {
                val pct = batteryPct(ctx)
                val charging = try {
                    ctx.getSystemService(BatteryManager::class.java).isCharging
                } catch (e: Exception) {
                    false
                }
                val tipHi = if (pct in 0..20) " Jaldi charge karo! ⚡" else ""
                val tipEn = if (pct in 0..20) " Charge soon! ⚡" else ""
                return c.reply(
                    "🔋 Battery $pct%${if (charging) " (charging)" else ""}.$tipHi",
                    "🔋 Battery $pct%${if (charging) " (charging)" else ""}.$tipEn",
                    kind = if (pct in 0..20) Kind.WARN else Kind.INFO
                )
            }
            isDate(c) -> {
                val d = dateFmt.format(Date())
                return c.reply("🗓️ Aaj $d hai", "🗓️ Today is $d")
            }
            isTime(c) -> {
                val t = timeFmt.format(Date())
                return c.reply("🕐 Abhi $t hue hain", "🕐 It's $t")
            }
            else -> {
                val i = when {
                    c.has("wifi", "vifi", "wi fi") -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_WIFI) else Intent(Settings.ACTION_WIFI_SETTINGS)
                    c.has("bluetooth", "blutooth") -> Intent(Settings.ACTION_BLUETOOTH_SETTINGS)
                    c.has("mobile data", "internet") -> if (Build.VERSION.SDK_INT >= 29) Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    c.has("hotspot") -> Intent(Settings.ACTION_WIRELESS_SETTINGS)
                    c.has("brightness") -> Intent(Settings.ACTION_DISPLAY_SETTINGS)
                    else -> Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                }
                env.launch(i)
                return c.reply(
                    "⚙️ Setting khol di — wahan se on/off kar lo (Android apps ko seedha on/off karne nahi deta).",
                    "⚙️ Opened the setting — toggle it there (Android doesn't let apps switch it directly).",
                    speakHi = "Setting khol di.", speakEn = "Opened the setting."
                )
            }
        }
    }
}

// =================================================================== CONTACTS / CALL / WHATSAPP

object Contacts {
    data class C(val name: String, val number: String, val score: Double)

    private val aliasGroups = listOf(
        listOf("mummy", "mumma", "maa", "mom", "mother", "mammi", "mata ji", "mataji"),
        listOf("papa", "pappa", "dad", "daddy", "father", "pitaji", "pita ji"),
        listOf("bhaiya", "bhai", "brother"),
        listOf("didi", "sister", "behen")
    )

    private fun all(ctx: Context): List<Pair<String, String>> {
        val out = ArrayList<Pair<String, String>>()
        try {
            ctx.contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER),
                null, null, null
            )?.use { cur ->
                val ni = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val pi = cur.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (cur.moveToNext()) {
                    val n = if (ni >= 0) cur.getString(ni) else null
                    val p = if (pi >= 0) cur.getString(pi) else null
                    if (n != null && p != null) out.add(Pair(n, p))
                }
            }
        } catch (e: Exception) {
        }
        return out.distinctBy { it.first + it.second.filter { ch -> ch.isDigit() }.takeLast(10) }
    }

    fun find(ctx: Context, query: String): C? {
        val q = Txt.simplify(Txt.normalize(query)).trim()
        if (q.isBlank()) return null
        val queries = ArrayList<String>()
        queries.add(q)
        aliasGroups.firstOrNull { g -> g.any { Txt.has(q, it) } }?.let { g -> queries.addAll(g.map { Txt.simplify(it) }) }
        var best: C? = null
        val contacts = all(ctx)
        for (qq in queries) {
            val qt = qq.split(' ').filter { it.isNotBlank() }
            for ((name, num) in contacts) {
                val cn = Txt.simplify(Txt.normalize(name))
                val ct = cn.split(' ').filter { it.isNotBlank() }
                val s = if (cn == qq) {
                    10.0
                } else {
                    val matched = qt.count { t -> ct.any { Txt.tokenMatch(it, t) || (t.length >= 3 && it.startsWith(t)) } }
                    matched.toDouble() / qt.size * 5 + (if (ct.isNotEmpty() && qt.isNotEmpty() && Txt.tokenMatch(ct[0], qt[0])) 1.0 else 0.0)
                }
                if (s > (best?.score ?: 0.0)) best = C(name, num, s)
            }
        }
        return best?.takeIf { it.score >= 3.5 }
    }
}

private fun needContacts(c: Cmd, env: Env): Reply? {
    if (Perms.contacts(env.ctx)) return null
    env.requestPerms(arrayOf(Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE))
    return c.reply("Contacts permission do (popup aaya hoga), phir dobara bolo 🙂", "Please allow contacts permission, then ask again 🙂", kind = Kind.WARN, status = "needs_input")
}

object CallSkill : Skill {
    private val strip = setOf(
        "call", "kol", "kal", "karo", "kar", "kardo", "lagao", "laga", "milao", "phone", "fone", "fon", "ko", "se", "pe", "par",
        "bhai", "please", "zara", "jara", "ek", "do", "de", "to", "abhi", "jaldi", "na", "mera", "meri", "mere", "my"
    )

    override fun matches(c: Cmd, env: Env): Boolean =
        (c.rawLower.contains("call") && !c.rawLower.contains("missed call")) || c.raw.contains("कॉल") ||
            (c.has("phone", "fon") && c.has("karo", "lagao", "milao", "kar do"))

    private fun dial(env: Env, number: String) {
        val uri = Uri.parse("tel:" + Uri.encode(number))
        val ok = Perms.call(env.ctx) && env.launch(Intent(Intent.ACTION_CALL, uri))
        if (!ok) env.launch(Intent(Intent.ACTION_DIAL, uri))
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val digits = c.norm.filter { it.isDigit() }
        if (digits.length >= 10) {
            dial(env, digits)
            return c.reply("📞 $digits ko call kar raha hoon", "📞 Calling $digits", kind = Kind.SUCCESS)
        }
        needContacts(c, env)?.let { return it }
        val name = c.norm.split(' ').filter { it.isNotBlank() && it !in strip }.joinToString(" ")
        if (name.isBlank()) return c.reply("Kisko call karun?", "Whom should I call?", kind = Kind.WARN, status = "needs_input")
        val ct = Contacts.find(env.ctx, name)
            ?: return c.reply("'$name' contacts mein nahi mila 😕", "Couldn't find '$name' in contacts 😕", kind = Kind.WARN, teachable = true)
        if (ct.score >= 6.0) {
            dial(env, ct.number)
            return c.reply("📞 ${ct.name} ko call kar raha hoon…", "📞 Calling ${ct.name}…", kind = Kind.SUCCESS, items = listOf(ct.number))
        }
        // Level-3: not 100% sure → ask human before calling
        return c.reply(
            "📞 ${ct.name} (${ct.number}) ko call karun?", "📞 Call ${ct.name} (${ct.number})?",
            speakHi = "${ct.name} ko call karun? Haan dabao.", speakEn = "Should I call ${ct.name}?",
            kind = Kind.INFO, status = "needs_approval",
            actions = listOf(
                ReplyAction(c.t("✅ Haan, call karo", "✅ Yes, call")) {
                    dial(env, ct.number)
                    ActionLog.add(env.ctx, c.raw, "Call", "Approved call to ${ct.name}", "approved")
                    null
                },
                ReplyAction(c.t("❌ Nahi", "❌ No")) {
                    ActionLog.add(env.ctx, c.raw, "Call", "Call cancelled", "cancelled")
                    null
                }
            )
        )
    }
}

object WhatsAppSkill : Skill {
    override fun matches(c: Cmd, env: Env) =
        c.has("whatsapp", "vatsap", "watsapp") && c.has("bolo", "bhejo", "bhej", "message", "likho", "msg", "bol", "keh", "kaho", "send", "tell")

    private val leadMsg = Regex(
        "^\\s*(?:(?:on |pe |par |पे |पर )?(?:whatsapp|whats app|व्हाट्सएप|व्हाट्सऐप)\\s*(?:pe|par|on|पे|पर)?\\s*)?" +
            "(?:(?:message|msg|मैसेज)\\s*(?:karo|kar do|करो|कर दो)?\\s*)?" +
            "(?:bolo|bol do|bhejo|bhej do|likho|keh do|kaho|send|tell|बोलो|बोल दो|भेजो|लिखो|कहो)?\\s*(?:ki|kiya|that|की|कि)?\\s*",
        RegexOption.IGNORE_CASE
    )
    private val waWords = Regex("(?:whatsapp|whats app|व्हाट्सएप|व्हाट्सऐप)\\s*(?:pe|par|on|पे|पर)?", RegexOption.IGNORE_CASE)

    override suspend fun run(c: Cmd, env: Env): Reply {
        needContacts(c, env)?.let { return it }
        val raw = c.raw.trim()
        val low = raw.lowercase()
        val idx = listOf(" ko ", " को ", " to ").map { low.indexOf(it) }.filter { it >= 0 }.minOrNull()
            ?: return c.reply(
                "Kisko bhejna hai? Jaise: 'Rahul ko WhatsApp pe bolo main aa raha hoon'",
                "Whom? e.g. 'WhatsApp Rahul that I'm coming'",
                kind = Kind.WARN, status = "needs_input"
            )
        val namePart = raw.substring(0, idx).replace(waWords, " ").replace(Regex("(?i)\\b(send|message|tell|bhai)\\b"), " ").trim()
        val msg = raw.substring(idx + 4).replace(leadMsg, "").trim()
        val ct = Contacts.find(env.ctx, namePart)
            ?: return c.reply("'$namePart' contacts mein nahi mila 😕", "Couldn't find '$namePart' in contacts 😕", kind = Kind.WARN)
        var num = ct.number.filter { it.isDigit() }
        if (num.startsWith("0")) num = num.trimStart('0')
        if (num.length == 10) num = "91$num"
        val uri = Uri.parse("https://api.whatsapp.com/send?phone=$num&text=" + Uri.encode(msg))
        if (PhoneControl.enabled && msg.isNotBlank()) {
            // Level-3: show exactly what will be sent, send only after approval, then verify
            return c.reply(
                "💬 ${ct.name} ko bhejun?", "💬 Send to ${ct.name}?",
                speakHi = "${ct.name} ko ye message bhejun? Haan dabao.", speakEn = "Send this to ${ct.name}?",
                kind = Kind.INFO, items = listOf("“$msg”"), status = "needs_approval",
                actions = listOf(
                    ReplyAction(c.t("✅ Haan, bhej do", "✅ Yes, send")) {
                        env.launch(Intent(Intent.ACTION_VIEW, uri))
                        var sent = false
                        for (i in 0 until 8) {
                            kotlinx.coroutines.delay(700)
                            if (PhoneControl.clickById("com.whatsapp:id/send", "com.whatsapp.w4b:id/send") || PhoneControl.click("Send") != null) {
                                sent = true
                                break
                            }
                        }
                        ActionLog.add(env.ctx, c.raw, "WhatsApp", if (sent) "Sent to ${ct.name}" else "Send button not found", if (sent) "verified" else "failed")
                        if (sent) c.reply("✅ ${ct.name} ko message chala gaya", "✅ Sent to ${ct.name}", kind = Kind.SUCCESS, status = "verified")
                        else c.reply("WhatsApp khul gaya, Send khud dabao.", "WhatsApp is open, tap Send.", kind = Kind.WARN, status = "failed")
                    },
                    ReplyAction(c.t("✏️ Sirf kholo", "✏️ Just open")) {
                        env.launch(Intent(Intent.ACTION_VIEW, uri))
                        null
                    }
                )
            )
        }
        env.launch(Intent(Intent.ACTION_VIEW, uri))
        return c.reply(
            "💬 ${ct.name} ke liye message ready — WhatsApp mein bas Send dabao",
            "💬 Message ready for ${ct.name} — just tap Send in WhatsApp",
            speakHi = "WhatsApp khol diya, bas send dabao.", speakEn = "WhatsApp is open, just tap send.",
            kind = Kind.SUCCESS, items = if (msg.isNotBlank()) listOf("“$msg”") else emptyList(), status = "needs_approval"
        )
    }
}

// =================================================================== WEB / YOUTUBE

object WebSkill : Skill {
    private val play = arrayOf("chalao", "lagao", "play", "search", "dhundo", "dikhao", "sunao", "bajao", "khojo")

    override fun matches(c: Cmd, env: Env) =
        (c.has("youtube", "yt") && c.has(*play)) || c.has("google pe", "google par", "google karo", "search karo", "search for") ||
            (c.has("google") && c.has(*play))

    private val stripWords = Regex(
        "\\b(youtube|yt|google|pe|par|me|mein|on|chalao|lagao|play|search|karo|kar|do|dhundo|dikhao|sunao|bajao|khojo|for|bhai|please|zara)\\b"
    )

    fun google(env: Env, q: String) {
        val i = Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, q)
        if (!env.launch(i)) env.launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val q = c.norm.replace(stripWords, " ").replace(Regex("\\s+"), " ").trim()
        if (c.has("youtube", "yt")) {
            val i = Intent(Intent.ACTION_SEARCH).setPackage("com.google.android.youtube").putExtra("query", q)
            if (!env.launch(i)) env.launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q))))
            return c.reply("▶️ YouTube pe: $q", "▶️ On YouTube: $q", kind = Kind.SUCCESS)
        }
        google(env, q)
        return c.reply("🔎 Google pe dhundh raha hoon: $q", "🔎 Searching Google: $q", kind = Kind.SUCCESS)
    }
}

// =================================================================== OPEN ANY APP

object AppSkill : Skill {
    private val openWords = arrayOf("kholo", "kholna", "khol", "open", "chalao", "start", "launch", "kholiye", "kholdo")
    private val filler = setOf(
        "app", "application", "ko", "zara", "jara", "please", "plz", "bhai", "mera", "meri", "mere", "de", "do", "na", "ek",
        "wala", "wali", "the", "my", "karo", "kar", "ab", "jaldi", "kholo", "kholna", "khol", "open", "chalao", "start",
        "launch", "kholiye", "kholdo", "provided", "company", "by", "phone", "ka", "ki", "ke", "wale"
    )
    private val aliases: Map<String, List<String>> = linkedMapOf(
        "notes" to listOf("notes", "note", "notepad", "notebook", "diary", "nots"),
        "calculator" to listOf("calculator", "calci", "calc", "calculater"),
        "camera" to listOf("camera", "kamra", "kemra"),
        "gallery" to listOf("gallery", "galeri", "photos", "photo", "album", "tasveer"),
        "settings" to listOf("settings", "setting", "setings"),
        "file manager" to listOf("file manager", "files", "file", "filemanager", "my files"),
        "clock" to listOf("clock", "ghadi", "ghari"),
        "chrome" to listOf("chrome", "browser", "krome"),
        "play store" to listOf("play store", "playstore"),
        "youtube" to listOf("youtube", "yt"),
        "instagram" to listOf("instagram", "insta"),
        "facebook" to listOf("facebook", "fb"),
        "whatsapp" to listOf("whatsapp", "watsapp", "vatsap"),
        "maps" to listOf("maps", "map", "naksha"),
        "music" to listOf("music", "gaane", "gane", "songs")
    )
    private val targets: Map<String, List<String>> = mapOf(
        "notes" to listOf("notes", "note", "notepad"),
        "file manager" to listOf("file manager", "files", "my files", "file"),
        "gallery" to listOf("gallery", "album", "photos"),
        "music" to listOf("music", "i music")
    )

    override fun matches(c: Cmd, env: Env) = c.has(*openWords)

    private fun apps(ctx: Context): List<Pair<String, String>> {
        val pm = ctx.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        @Suppress("DEPRECATION")
        return pm.queryIntentActivities(i, 0)
            .map { Pair(it.loadLabel(pm).toString(), it.activityInfo.packageName) }
            .filter { it.second != ctx.packageName }
            .distinctBy { it.second }
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val name = c.norm.split(' ').filter { it.isNotBlank() && it !in filler }.joinToString(" ").trim()
        if (name.isBlank()) return c.reply("Kaunsa app kholun?", "Which app should I open?", kind = Kind.WARN, status = "needs_input")
        val sn = Txt.simplify(name)
        val canonical = aliases.entries.firstOrNull { e -> e.value.any { Txt.has(sn, it) } }?.key
        val wanted = if (canonical != null) (targets[canonical] ?: listOf(canonical)) else listOf(name)
        var best: Pair<String, String>? = null
        var bestScore = 0.0
        for (app in apps(env.ctx)) {
            val ls = Txt.simplify(Txt.normalize(app.first))
            val lt = ls.split(' ')
            for (w in wanted) {
                val ws = Txt.simplify(Txt.normalize(w))
                var s = when {
                    ls == ws -> 10.0
                    ls.replace(" ", "") == ws.replace(" ", "") -> 9.0
                    ls.contains(ws) && ws.length >= 3 -> 7.0 - (ls.length - ws.length) * 0.05
                    ws.split(' ').all { t -> lt.any { Txt.tokenMatch(it, t) } } -> 5.0
                    else -> 0.0
                }
                if (s > 0 && canonical == "notes" && (app.second.contains("note") || app.second.contains("vivo"))) s += 1.5
                if (s > bestScore) {
                    bestScore = s
                    best = app
                }
            }
        }
        val target = best
            ?: return c.reply("'$name' naam ka app nahi mila 😕", "Couldn't find an app called '$name' 😕", kind = Kind.WARN, teachable = true)
        val li = env.ctx.packageManager.getLaunchIntentForPackage(target.second)
            ?: return c.reply("${target.first} khul nahi paya.", "Couldn't open ${target.first}.", kind = Kind.ERROR)
        env.launch(li)
        return c.reply("🚀 ${target.first} khol diya", "🚀 Opened ${target.first}", kind = Kind.SUCCESS, speakHi = "${target.first} khol diya", speakEn = "Opening ${target.first}")
    }
}

object AppInfo {
    val repo: String get() = BuildConfig.REPO_URL
}
