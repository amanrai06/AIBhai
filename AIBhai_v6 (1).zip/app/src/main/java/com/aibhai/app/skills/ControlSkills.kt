package com.aibhai.app.skills

import android.accessibilityservice.AccessibilityService
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.content.FileProvider
import com.aibhai.app.BuildConfig
import com.aibhai.app.Prefs
import com.aibhai.app.core.ActionLog
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Txt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

// =================================================================== ACCESSIBILITY (full phone control)

class AIBhaiAccessibility : AccessibilityService() {
    companion object {
        @Volatile
        var instance: AIBhaiAccessibility? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    private var lastBlock = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (FocusMode.active(this) && FocusMode.isDistracting(pkg) && System.currentTimeMillis() - lastBlock > 1500) {
            lastBlock = System.currentTimeMillis()
            performGlobalAction(GLOBAL_ACTION_HOME)
            val left = ((Prefs(this).focusUntil - System.currentTimeMillis()) / 60_000L).coerceAtLeast(1)
            android.widget.Toast.makeText(this, "📚 Focus mode chal raha hai — $left min baaki. Padhai karo bhai! 💪", android.widget.Toast.LENGTH_LONG).show()
        }
    }
    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }
}

object PhoneControl {
    /** Safety: never auto-tap inside money apps */
    private val blocked = listOf(
        "phonepe", "paytm", "nbu.paisa", "npci", "bhim", "sbi", "hdfc", "icici", "axis", "kotak", "pnb", "bank",
        "upi", "mobikwik", "cred", "groww", "zerodha", "upstox", "angelone", "amazon.pay"
    )

    val enabled: Boolean get() = AIBhaiAccessibility.instance != null

    fun openSettings(ctx: Context) {
        try {
            ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: Exception) {
        }
    }

    private fun root(): AccessibilityNodeInfo? = try {
        AIBhaiAccessibility.instance?.rootInActiveWindow
    } catch (e: Exception) {
        null
    }

    fun currentPackage(): String = root()?.packageName?.toString() ?: ""

    fun isBlocked(pkg: String): Boolean = blocked.any { pkg.lowercase().contains(it) }

    private fun walk(n: AccessibilityNodeInfo?, out: MutableList<AccessibilityNodeInfo>, depth: Int = 0) {
        if (n == null || depth > 40 || out.size > 1500) return
        out.add(n)
        for (i in 0 until n.childCount) walk(n.getChild(i), out, depth + 1)
    }

    fun screenText(): List<String> {
        val nodes = ArrayList<AccessibilityNodeInfo>()
        walk(root(), nodes)
        val seen = LinkedHashSet<String>()
        for (n in nodes) {
            val t = (n.text ?: n.contentDescription)?.toString()?.trim() ?: continue
            if (t.length >= 2) seen.add(t)
        }
        return seen.toList()
    }

    fun click(target: String): String? {
        val key = Txt.simplify(Txt.normalize(target))
        if (key.isBlank()) return null
        val nodes = ArrayList<AccessibilityNodeInfo>()
        walk(root(), nodes)
        var best: AccessibilityNodeInfo? = null
        var bestScore = 0
        for (n in nodes) {
            val label = (n.text ?: n.contentDescription)?.toString() ?: continue
            val ls = Txt.simplify(Txt.normalize(label))
            val s = when {
                ls == key -> 3
                ls.contains(key) && key.length >= 3 -> 2
                key.split(' ').all { k -> ls.split(' ').any { Txt.tokenMatch(it, k) } } -> 1
                else -> 0
            }
            if (s > bestScore) {
                bestScore = s
                best = n
            }
        }
        var n = best ?: return null
        var hops = 0
        while (!n.isClickable && n.parent != null && hops < 6) {
            n = n.parent
            hops++
        }
        return if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) ((best?.text ?: best?.contentDescription)?.toString() ?: target) else null
    }

    fun clickById(vararg ids: String): Boolean {
        val r = root() ?: return false
        for (id in ids) {
            val found = try {
                r.findAccessibilityNodeInfosByViewId(id)
            } catch (e: Exception) {
                null
            }
            val n = found?.firstOrNull() ?: continue
            if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    fun type(text: String): Boolean {
        val nodes = ArrayList<AccessibilityNodeInfo>()
        walk(root(), nodes)
        val field = nodes.firstOrNull { it.isFocused && it.isEditable } ?: nodes.firstOrNull { it.isEditable } ?: return false
        val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    fun scroll(forward: Boolean): Boolean {
        val nodes = ArrayList<AccessibilityNodeInfo>()
        walk(root(), nodes)
        val s = nodes.firstOrNull { it.isScrollable } ?: return false
        return s.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)
    }

    fun global(action: Int): Boolean = AIBhaiAccessibility.instance?.performGlobalAction(action) == true
}

object ScreenSkill : Skill {
    private val readCue = arrayOf("screen pe kya", "screen par kya", "screen padho", "ye kya likha", "kya likha hai", "padh ke sunao", "read screen", "what's on screen", "whats on screen")
    private val clickCue = Regex("^(?:(.+?)\\s+(?:pe|par|ko|on)\\s+)?(?:click|tap|dabao|daba do|press|kilik)\\s*(?:karo|kar do|kardo)?\\s*(.*)$")
    private val typeCue = Regex("^(?:type karo|type kar do|likho|likh do|type)\\s+(.+)$")

    override fun matches(c: Cmd, env: Env): Boolean =
        c.has(*readCue) || clickCue.containsMatchIn(c.norm) && c.has("click", "tap", "dabao", "press") ||
            typeCue.containsMatchIn(c.norm) && c.has("type", "likho") && !c.has("whatsapp", "note", "notes") ||
            c.has("scroll", "neeche karo", "upar karo", "niche karo", "back jao", "peeche jao", "go back", "home jao", "home screen",
                "recent apps", "notification kholo", "notifications kholo", "screenshot", "screen lock", "phone lock", "lock karo", "quick settings")

    override suspend fun run(c: Cmd, env: Env): Reply {
        if (!PhoneControl.enabled) {
            return c.reply(
                "🤖 Phone control ke liye 'AIBhai' ko Accessibility mein ON karo. (Toggle grey ho to: App info → ⋮ → Allow restricted settings)",
                "🤖 Turn on AIBhai in Accessibility settings to let me control your phone.",
                kind = Kind.WARN, status = "needs_input",
                actions = listOf(ReplyAction(c.t("Accessibility kholo", "Open Accessibility")) {
                    PhoneControl.openSettings(env.ctx)
                    null
                })
            )
        }
        // global actions don't need the screen behind us
        val g: Pair<Int, String>? = when {
            c.has("screenshot") && Build.VERSION.SDK_INT >= 28 -> Pair(AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT, c.t("📸 Screenshot le liya", "📸 Screenshot taken"))
            c.has("screen lock", "phone lock", "lock karo") && Build.VERSION.SDK_INT >= 28 -> Pair(AccessibilityService.GLOBAL_ACTION_LOCK_SCREEN, c.t("🔒 Phone lock", "🔒 Locked"))
            c.has("recent apps") -> Pair(AccessibilityService.GLOBAL_ACTION_RECENTS, c.t("🗂️ Recent apps", "🗂️ Recent apps"))
            c.has("notification kholo", "notifications kholo") -> Pair(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS, c.t("🔔 Notifications khol di", "🔔 Notifications opened"))
            c.has("quick settings") -> Pair(AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS, c.t("⚙️ Quick settings", "⚙️ Quick settings"))
            c.has("home jao", "home screen") -> Pair(AccessibilityService.GLOBAL_ACTION_HOME, c.t("🏠 Home", "🏠 Home"))
            else -> null
        }
        env.hideUi()
        delay(if (g?.first == AccessibilityService.GLOBAL_ACTION_TAKE_SCREENSHOT) 1200 else 700)
        if (g != null) {
            val ok = PhoneControl.global(g.first)
            return c.reply(g.second, g.second, kind = if (ok) Kind.SUCCESS else Kind.ERROR, status = if (ok) "ok" else "failed")
        }
        val pkg = PhoneControl.currentPackage()
        if (c.has("back jao", "peeche jao", "go back")) {
            val ok = PhoneControl.global(AccessibilityService.GLOBAL_ACTION_BACK)
            return c.reply("↩️ Back", "↩️ Back", kind = if (ok) Kind.SUCCESS else Kind.ERROR)
        }
        if (c.has(*readCue)) {
            val lines = PhoneControl.screenText().take(15)
            if (lines.isEmpty()) return c.reply("Screen pe padhne layak kuch nahi mila.", "Nothing readable on screen.", kind = Kind.WARN)
            return c.reply(
                "👀 Screen pe ye hai:", "👀 On screen:",
                speakHi = "Screen pe likha hai: " + lines.take(6).joinToString(". "),
                speakEn = "On screen: " + lines.take(6).joinToString(". "),
                items = lines.map { "• " + Txt.short(it, 80) }
            )
        }
        if (PhoneControl.isBlocked(pkg)) {
            ActionLog.add(env.ctx, c.raw, "Screen", "Blocked in money app $pkg", "cancelled")
            return c.reply(
                "🛡️ Ye paise/bank wala app hai — safety ke liye main yahan khud tap/type nahi karta. Ye aap khud karo.",
                "🛡️ This is a payments/bank app — for your safety I won't tap or type here.",
                kind = Kind.WARN, status = "cancelled"
            )
        }
        if (c.has("scroll", "neeche karo", "niche karo", "upar karo")) {
            val up = c.has("upar", "up")
            val ok = PhoneControl.scroll(!up)
            return c.reply(if (up) "⬆️ Upar" else "⬇️ Neeche", if (up) "⬆️ Up" else "⬇️ Down", kind = if (ok) Kind.SUCCESS else Kind.WARN, speakHi = null, speakEn = null)
        }
        typeCue.find(c.norm)?.let { m ->
            if (c.has("type", "likho")) {
                val text = c.raw.substringAfter(" ", m.groupValues[1]).let { r ->
                    Regex("^(?:type karo|type kar do|likho|likh do|type|टाइप करो|लिखो)\\s+", RegexOption.IGNORE_CASE).replace(c.raw.trim(), "").ifBlank { r }
                }
                val ok = PhoneControl.type(text)
                return c.reply(
                    if (ok) "⌨️ Likh diya: $text" else "Koi typing box nahi mila.",
                    if (ok) "⌨️ Typed: $text" else "No text box found.",
                    kind = if (ok) Kind.SUCCESS else Kind.WARN, status = if (ok) "verified" else "failed"
                )
            }
        }
        val m = clickCue.find(c.norm)
        val target = listOf(m?.groupValues?.getOrNull(1), m?.groupValues?.getOrNull(2)).firstOrNull { !it.isNullOrBlank() }?.trim() ?: ""
        if (target.isBlank()) return c.reply("Kis cheez pe tap karun? Button ka naam bolo.", "What should I tap? Say the button name.", kind = Kind.WARN, status = "needs_input")
        val hit = PhoneControl.click(target)
        return if (hit != null) c.reply("👆 '$hit' pe tap kar diya", "👆 Tapped '$hit'", kind = Kind.SUCCESS, status = "ok")
        else c.reply("'$target' screen pe nahi mila 😕", "Couldn't find '$target' on screen 😕", kind = Kind.WARN, status = "failed")
    }
}

// =================================================================== ANY SETTINGS PAGE

object SettingsSkill : Skill {
    private val pages: List<Pair<List<String>, String>> = listOf(
        listOf("display", "brightness", "screen setting") to Settings.ACTION_DISPLAY_SETTINGS,
        listOf("sound", "ringtone", "awaaz setting") to Settings.ACTION_SOUND_SETTINGS,
        listOf("battery") to Intent.ACTION_POWER_USAGE_SUMMARY,
        listOf("storage", "memory") to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        listOf("apps", "app setting", "applications") to Settings.ACTION_APPLICATION_SETTINGS,
        listOf("notification") to "android.settings.NOTIFICATION_SETTINGS",
        listOf("privacy") to Settings.ACTION_PRIVACY_SETTINGS,
        listOf("security", "lock screen", "fingerprint", "password") to Settings.ACTION_SECURITY_SETTINGS,
        listOf("location", "gps") to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        listOf("developer", "developer options") to Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS,
        listOf("about phone", "phone info", "about") to Settings.ACTION_DEVICE_INFO_SETTINGS,
        listOf("date", "time setting") to Settings.ACTION_DATE_SETTINGS,
        listOf("language", "bhasha", "keyboard") to Settings.ACTION_LOCALE_SETTINGS,
        listOf("accessibility") to Settings.ACTION_ACCESSIBILITY_SETTINGS,
        listOf("data usage", "mobile data", "sim") to Settings.ACTION_DATA_ROAMING_SETTINGS,
        listOf("hotspot", "tethering") to Settings.ACTION_WIRELESS_SETTINGS,
        listOf("nfc") to Settings.ACTION_NFC_SETTINGS,
        listOf("airplane", "flight mode", "aeroplane") to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        listOf("wifi", "wi fi") to Settings.ACTION_WIFI_SETTINGS,
        listOf("bluetooth") to Settings.ACTION_BLUETOOTH_SETTINGS,
        listOf("default apps", "default app") to Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS
    )

    override fun matches(c: Cmd, env: Env) = c.has("setting", "settings", "seting") &&
        c.has("kholo", "open", "dikhao", "jao", "chalo") && pages.any { (k, _) -> k.any { c.has(it) } }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val page = pages.first { (k, _) -> k.any { c.has(it) } }
        val ok = env.launch(Intent(page.second)) || env.launch(Intent(Settings.ACTION_SETTINGS))
        val name = page.first.first().replaceFirstChar { it.uppercase() }
        return c.reply("⚙️ $name settings khol di", "⚙️ Opened $name settings", kind = if (ok) Kind.SUCCESS else Kind.ERROR)
    }
}

// =================================================================== NEW APPS + SELF UPDATE

object AppWatcher {
    /** Returns names of apps installed since last check (first run just remembers). */
    fun newApps(ctx: Context): List<String> {
        val pm = ctx.packageManager
        @Suppress("DEPRECATION")
        val now = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .associate { it.activityInfo.packageName to it.loadLabel(pm).toString() }
        val sp = ctx.getSharedPreferences("aibhai", 0)
        val known = sp.getStringSet("known_apps", null)
        sp.edit().putStringSet("known_apps", now.keys.toSet()).apply()
        if (known == null) return emptyList()
        return now.filterKeys { it !in known && it != ctx.packageName }.values.toList()
    }
}

object NewAppsSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has("naye apps", "naya app", "new apps", "kaunse apps install", "recent install")

    override suspend fun run(c: Cmd, env: Env): Reply {
        val fresh = AppWatcher.newApps(env.ctx)
        return if (fresh.isEmpty()) c.reply("📲 Pichli baar se koi naya app install nahi hua.", "📲 No new apps since last check.")
        else c.reply("📲 Naye apps: ${fresh.joinToString()}. Bolo \"${fresh.first()} kholo\"", "📲 New apps: ${fresh.joinToString()}", kind = Kind.SUCCESS, items = fresh.map { "✨ $it" })
    }
}

object UpdateSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has("update check", "update karo", "naya version", "new version", "app update", "aibhai update", "check update")

    data class Release(val version: Int, val name: String, val apkUrl: String, val notes: String)

    private fun repo(): String = BuildConfig.REPO_URL.ifBlank { "amanrai06/AIBhai" }

    suspend fun latest(): Release? = withContext(Dispatchers.IO) {
        try {
            val con = URL("https://api.github.com/repos/${repo()}/releases/latest").openConnection() as HttpURLConnection
            con.connectTimeout = 7000
            con.readTimeout = 9000
            con.setRequestProperty("Accept", "application/vnd.github+json")
            if (con.responseCode != 200) return@withContext null
            val o = JSONObject(con.inputStream.bufferedReader().use { it.readText() })
            val tag = o.optString("tag_name")
            val ver = tag.substringAfterLast('.').toIntOrNull() ?: return@withContext null
            val assets = o.optJSONArray("assets") ?: JSONArray()
            var url = ""
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.optString("name").endsWith(".apk")) url = a.optString("browser_download_url")
            }
            if (url.isBlank()) null else Release(ver, o.optString("name", tag), url, o.optString("body"))
        } catch (e: Exception) {
            null
        }
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val r = latest() ?: return c.reply("📡 Update check nahi ho paya (internet?).", "📡 Couldn't check for updates.", kind = Kind.WARN)
        if (r.version <= BuildConfig.VERSION_CODE) {
            return c.reply("✅ AIBhai latest hai (v${BuildConfig.VERSION_NAME})", "✅ AIBhai is up to date (v${BuildConfig.VERSION_NAME})", kind = Kind.SUCCESS)
        }
        return offer(c, env, r)
    }

    fun offer(c: Cmd, env: Env, r: Release): Reply = c.reply(
        "🆕 Naya AIBhai aaya hai: ${r.name}. Abhi update karun?",
        "🆕 New AIBhai available: ${r.name}. Update now?",
        speakHi = "Naya AIBhai update aaya hai. Update karun?", speakEn = "A new update is available.",
        kind = Kind.INFO, status = "needs_approval",
        actions = listOf(ReplyAction(c.t("⬇️ Update karo", "⬇️ Update")) { download(env, r, c) })
    )

    private suspend fun download(env: Env, r: Release, c: Cmd): Reply {
        val ctx = env.ctx
        if (Build.VERSION.SDK_INT >= 26 && !ctx.packageManager.canRequestPackageInstalls()) {
            env.launch(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)))
            return c.reply(
                "🔐 Pehle 'Install unknown apps' mein AIBhai ko Allow karo, phir dobara 'Update karo' dabao.",
                "🔐 Allow AIBhai to install apps, then tap Update again.",
                kind = Kind.WARN, status = "needs_input",
                actions = listOf(ReplyAction(c.t("⬇️ Update karo", "⬇️ Update")) { download(env, r, c) })
            )
        }
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
        val file = File(dir, "AIBhai-${r.version}.apk")
        file.delete()
        val dm = ctx.getSystemService(DownloadManager::class.java)
        val id = dm.enqueue(
            DownloadManager.Request(Uri.parse(r.apkUrl))
                .setTitle("AIBhai update")
                .setDestinationUri(Uri.fromFile(file))
                .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE)
        )
        var ok = false
        for (i in 0 until 240) {
            delay(1000)
            dm.query(DownloadManager.Query().setFilterById(id))?.use { cur ->
                if (cur.moveToFirst()) {
                    val st = cur.getInt(cur.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS))
                    if (st == DownloadManager.STATUS_SUCCESSFUL) ok = true
                    if (st == DownloadManager.STATUS_FAILED) return c.reply("❌ Download fail hua.", "❌ Download failed.", kind = Kind.ERROR, status = "failed")
                }
            }
            if (ok) break
        }
        if (!ok || !file.exists()) return c.reply("⏳ Download time pe poora nahi hua.", "⏳ Download timed out.", kind = Kind.ERROR, status = "failed")
        val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".files", file)
        env.launch(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
        ActionLog.add(ctx, "update", "Update", "Downloaded v${r.version}, installer opened", "verified")
        return c.reply("📦 Update download ho gaya — 'Update/Install' dabao.", "📦 Downloaded — tap Install.", kind = Kind.SUCCESS, status = "verified")
    }

    /** Silent daily check, used at app start. */
    suspend fun autoCheck(ctx: Context): Release? {
        if (com.aibhai.app.core.Eco.active(ctx)) return null
        val sp = ctx.getSharedPreferences("aibhai", 0)
        val last = sp.getLong("upd_check", 0)
        if (System.currentTimeMillis() - last < 12 * 3600_000L) return null
        sp.edit().putLong("upd_check", System.currentTimeMillis()).apply()
        val r = latest() ?: return null
        return if (r.version > BuildConfig.VERSION_CODE) r else null
    }

    @Suppress("unused")
    private fun prefs(ctx: Context) = Prefs(ctx)
}
