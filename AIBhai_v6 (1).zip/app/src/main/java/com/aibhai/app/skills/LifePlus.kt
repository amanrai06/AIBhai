package com.aibhai.app.skills

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.os.BatteryManager
import android.provider.Settings
import com.aibhai.app.Prefs
import com.aibhai.app.core.ActionLog
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Txt
import com.aibhai.app.system.Notifs
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.math.PI

private val num = "(\\d+(?:\\.\\d+)?)"
private fun find(re: String, s: String): Double? = Regex(re).find(s)?.groupValues?.get(1)?.toDoubleOrNull()

// =================================================================== EV PRO + UNIT CONVERTER

object EngSkill : Skill {
    private data class U(val dim: String, val factor: Double)

    private val units: Map<String, U> = linkedMapOf(
        "kn" to U("force", 1000.0), "n" to U("force", 1.0), "newton" to U("force", 1.0), "kgf" to U("force", 9.80665), "lbf" to U("force", 4.44822),
        "nm" to U("torque", 1.0), "kgfm" to U("torque", 9.80665),
        "kw" to U("power", 1000.0), "w" to U("power", 1.0), "watt" to U("power", 1.0), "hp" to U("power", 745.7), "bhp" to U("power", 745.7), "ps" to U("power", 735.5),
        "mpa" to U("pressure", 1e6), "kpa" to U("pressure", 1000.0), "pa" to U("pressure", 1.0), "bar" to U("pressure", 1e5), "psi" to U("pressure", 6894.76), "atm" to U("pressure", 101325.0),
        "km" to U("length", 1000.0), "m" to U("length", 1.0), "meter" to U("length", 1.0), "cm" to U("length", 0.01), "mm" to U("length", 0.001),
        "inch" to U("length", 0.0254), "in" to U("length", 0.0254), "ft" to U("length", 0.3048), "feet" to U("length", 0.3048), "mile" to U("length", 1609.34),
        "kg" to U("mass", 1.0), "g" to U("mass", 0.001), "gram" to U("mass", 0.001), "lb" to U("mass", 0.453592), "ton" to U("mass", 1000.0),
        "kmph" to U("speed", 1 / 3.6), "kmh" to U("speed", 1 / 3.6), "mps" to U("speed", 1.0), "mph" to U("speed", 0.44704),
        "kwh" to U("energy", 3.6e6), "wh" to U("energy", 3600.0), "j" to U("energy", 1.0), "kj" to U("energy", 1000.0), "mj" to U("energy", 1e6),
        "kcal" to U("energy", 4184.0), "cal" to U("energy", 4.184),
        "l" to U("volume", 0.001), "litre" to U("volume", 0.001), "liter" to U("volume", 0.001), "ml" to U("volume", 1e-6), "gallon" to U("volume", 0.00378541),
        "c" to U("temp", 0.0), "celsius" to U("temp", 0.0), "f" to U("temp", 0.0), "fahrenheit" to U("temp", 0.0), "k" to U("temp", 0.0), "kelvin" to U("temp", 0.0)
    )
    private val convRe = Regex("$num\\s*([a-z]+)\\s+(?:to|se|in|mein|me|ko|into)\\s+([a-z]+)")

    private fun conv(c: Cmd): Triple<Double, String, String>? {
        val m = convRe.find(c.norm) ?: return null
        val a = m.groupValues[2]
        val b = m.groupValues[3]
        val ua = units[a] ?: return null
        val ub = units[b] ?: return null
        if (ua.dim != ub.dim) return null
        return Triple(m.groupValues[1].toDouble(), a, b)
    }

    override fun matches(c: Cmd, env: Env): Boolean {
        if (conv(c) != null) return true
        if (!c.norm.any { it.isDigit() }) return false
        return c.has("charging time", "charge hone", "charge time", "kitni der mein charge") ||
            (c.has("cost", "kharcha", "per km", "running cost", "paisa") && c.has("kwh", "wh/km", "wh per km", "unit", "ev")) ||
            (c.has("torque") && c.has("rpm"))
    }

    private fun toC(v: Double, u: String) = when (u.first()) {
        'f' -> (v - 32) * 5 / 9
        'k' -> v - 273.15
        else -> v
    }

    private fun fromC(v: Double, u: String) = when (u.first()) {
        'f' -> v * 9 / 5 + 32
        'k' -> v + 273.15
        else -> v
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val n = c.norm
        conv(c)?.let { (v, a, b) ->
            val ua = units.getValue(a)
            val out = if (ua.dim == "temp") fromC(toC(v, a), b) else v * ua.factor / units.getValue(b).factor
            return c.reply("🔁 ${fmtNum(v)} $a = ${fmtNum(out)} $b", "🔁 ${fmtNum(v)} $a = ${fmtNum(out)} $b", kind = Kind.SUCCESS)
        }
        if (c.has("torque")) {
            val pkw = find("$num\\s*kw\\b", n) ?: find("$num\\s*hp\\b", n)?.times(0.7457)
            val rpm = find("$num\\s*rpm", n)
            if (pkw != null && rpm != null && rpm > 0) {
                val t = pkw * 1000 * 60 / (2 * PI * rpm)
                return c.reply(
                    "⚙️ Torque = ${fmtNum(t)} N·m", "⚙️ Torque = ${fmtNum(t)} N·m",
                    kind = Kind.SUCCESS, items = listOf("T = P×60 / (2πN)", "= ${fmtNum(pkw * 1000)} × 60 / (2π × ${fmtNum(rpm)})", "= ${fmtNum(t)} N·m")
                )
            }
        }
        if (c.has("charging time", "charge hone", "charge time", "kitni der mein charge")) {
            val kwh = find("$num\\s*kwh", n)
            val kw = find("$num\\s*kw\\b(?!h)", n) ?: 3.3
            if (kwh != null) {
                val h = kwh / kw * 1.1
                val hh = h.toInt()
                val mm = ((h - hh) * 60).toInt()
                return c.reply(
                    "🔌 Charging time ≈ ${hh}h ${mm}m", "🔌 Charging time ≈ ${hh}h ${mm}m",
                    kind = Kind.SUCCESS,
                    items = listOf("t = kWh / kW × 1.1 (losses)", "= ${fmtNum(kwh)} / ${fmtNum(kw)} × 1.1 = ${fmtNum(h)} h", if (find("$num\\s*kw\\b(?!h)", n) == null) "💡 3.3 kW charger maana" else "")
                        .filter { it.isNotBlank() }
                )
            }
        }
        // running cost per km
        val kwhIn = find("$num\\s*kwh", n)
        val kmIn = find("$num\\s*km\\b", n)
        val derived = if (kwhIn != null && kmIn != null && kmIn > 0) kwhIn * 1000 / kmIn else null
        val whkm = find("$num\\s*(?:wh ?/ ?km|wh per km)", n) ?: derived ?: 35.0
        val rate = find("$num\\s*(?:rupay|rupaye|rupees|rs|unit)", n) ?: 8.0
        val perKm = whkm / 1000 * rate
        return c.reply(
            "💰 Running cost ≈ ₹${fmtNum(perKm)}/km", "💰 Running cost ≈ ₹${fmtNum(perKm)}/km",
            kind = Kind.SUCCESS,
            items = listOf(
                "Cost/km = (Wh/km ÷ 1000) × ₹/unit",
                "= (${fmtNum(whkm)} ÷ 1000) × ₹${fmtNum(rate)}",
                "100 km ≈ ₹${fmtNum(perKm * 100)} • Petrol bike (45 km/l, ₹100/l) ≈ ₹${fmtNum(100.0 / 45 * 100)}"
            )
        )
    }
}

// =================================================================== EXPENSE TRACKER

object ExpenseSkill : Skill {
    private val spendCue = arrayOf("kharch", "kharcha", "kharche", "spent", "spend", "diye", "lage", "lag gaye", "pay kiya", "paid")
    private val reportCue = arrayOf("kitna kharcha", "kharcha batao", "kharcha kitna", "hisab", "hisaab", "expense", "expenses", "kitne paise", "spending")

    override fun matches(c: Cmd, env: Env): Boolean {
        if (c.has(*reportCue)) return true
        val hasMoney = c.has("rupay", "rupaye", "rupees", "rs", "rupee", "rupaiye") || c.raw.contains("₹") || c.has("paise")
        return hasMoney && c.has(*spendCue) && c.norm.any { it.isDigit() }
    }

    private fun load(env: Env) = try {
        JSONArray(env.prefs.expenses)
    } catch (e: Exception) {
        JSONArray()
    }

    fun total(env: Env, since: Long): Double {
        val a = load(env)
        return (0 until a.length()).map { a.getJSONObject(it) }.filter { it.optLong("t") >= since }.sumOf { it.optDouble("a") }
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val a = load(env)
        val amt = Regex("(\\d+(?:\\.\\d+)?)").find(c.norm)?.groupValues?.get(1)?.toDoubleOrNull()
        if (!c.has(*reportCue) && amt != null) {
            val cat = c.norm.replace(Regex("\\d+(?:\\.\\d+)?"), " ")
                .replace(Regex("\\b(rupay|rupaye|rupees|rs|rupee|rupaiye|paise|kharch|kharcha|kharche|kiye|kiya|ke|ki|ka|pe|par|me|mein|spent|on|for|diye|lage|lag|gaye|aaj|maine|mere|bhai|pay|paid|liye|liya)\\b"), " ")
                .replace(Regex("\\s+"), " ").trim().ifBlank { "general" }
            a.put(JSONObject().put("a", amt).put("c", cat).put("t", System.currentTimeMillis()))
            env.prefs.expenses = a.toString()
            val today = total(env, startOfToday())
            return c.reply(
                "💸 ₹${fmtNum(amt)} • $cat — note kar liya. Aaj ka total ₹${fmtNum(today)}",
                "💸 ₹${fmtNum(amt)} • $cat — saved. Today's total ₹${fmtNum(today)}",
                kind = Kind.SUCCESS, status = "verified"
            )
        }
        val cal = Calendar.getInstance()
        val (since, label) = when {
            c.has("mahine", "month", "mahina") -> Pair(startOfToday() - (cal.get(Calendar.DAY_OF_MONTH) - 1) * 86400_000L, c.t("is mahine", "this month"))
            c.has("hafte", "week", "hafta") -> Pair(startOfToday() - 6 * 86400_000L, c.t("pichle 7 din", "last 7 days"))
            else -> Pair(startOfToday(), c.t("aaj", "today"))
        }
        val list = (0 until a.length()).map { a.getJSONObject(it) }.filter { it.optLong("t") >= since }
        val sum = list.sumOf { it.optDouble("a") }
        val byCat = list.groupBy { it.optString("c") }.mapValues { e -> e.value.sumOf { it.optDouble("a") } }.entries.sortedByDescending { it.value }
        return c.reply(
            "💰 $label ka kharcha: ₹${fmtNum(sum)}", "💰 Spent $label: ₹${fmtNum(sum)}",
            kind = Kind.INFO, items = byCat.take(8).map { "• ${it.key}: ₹${fmtNum(it.value)}" }
        )
    }
}

// =================================================================== GOOD NIGHT ROUTINE

object NightSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has("good night", "gud night", "goodnight", "shubh ratri", "sone ja raha", "so raha hoon", "night mode", "sleep mode", "sone ja rahi")

    override suspend fun run(c: Cmd, env: Env): Reply {
        val items = ArrayList<String>()
        val ctx = env.ctx
        try {
            ctx.getSystemService(AudioManager::class.java)?.ringerMode = AudioManager.RINGER_MODE_VIBRATE
            items.add("📳 Phone vibrate pe")
        } catch (e: Exception) {
        }
        if (Settings.System.canWrite(ctx)) {
            try {
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                Settings.System.putInt(ctx.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 20)
                items.add("🔅 Brightness kam")
            } catch (e: Exception) {
            }
        }
        val next = ctx.getSystemService(AlarmManager::class.java)?.nextAlarmClock
        val alarmTxt = next?.let { SimpleDateFormat("EEE h:mm a", Locale.US).format(Date(it.triggerTime)) }
        items.add(if (alarmTxt != null) "⏰ Agla alarm: $alarmTxt" else "⚠️ Koi alarm set nahi hai!")
        val tomorrowDay = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, 1) }.get(Calendar.DAY_OF_WEEK)
        val firstClass = TimetableSkill.slotsFor(env, tomorrowDay).firstOrNull()
        if (firstClass != null) items.add("📚 Kal pehli class: ${firstClass.subject} ${firstClass.start / 60}:${(firstClass.start % 60).toString().padStart(2, '0')}")
        val pledges = MistakeSkill.pledges(env)
        if (pledges.isNotEmpty()) items.add("🤝 Yaad rakhna: ${pledges.first()}")
        val spent = ExpenseSkill.total(env, startOfToday())
        if (spent > 0) items.add("💸 Aaj ka kharcha: ₹${fmtNum(spent)}")
        val hi = "Good night ${env.name}! " + (if (alarmTxt != null) "Agla alarm $alarmTxt ka hai. " else "Dhyan do, koi alarm set nahi hai. ") +
            (firstClass?.let { "Kal pehli class ${it.subject} ki hai. " } ?: "") + "Aaram se so jao, kal dhamaal karenge. 🌙"
        return c.reply(
            "🌙 Good night ${env.name}!", "🌙 Good night ${env.name}!",
            speakHi = hi, speakEn = "Good night! " + (if (alarmTxt != null) "Your next alarm is $alarmTxt." else "No alarm is set."),
            kind = Kind.INFO, items = items,
            actions = if (alarmTxt == null) listOf(ReplyAction(c.t("⏰ 6:30 ka alarm", "⏰ 6:30 alarm")) {
                env.launch(
                    Intent(android.provider.AlarmClock.ACTION_SET_ALARM).putExtra(android.provider.AlarmClock.EXTRA_HOUR, 6)
                        .putExtra(android.provider.AlarmClock.EXTRA_MINUTES, 30).putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, true)
                        .putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "AIBhai")
                )
                c.reply("⏰ Kal 6:30 AM ka alarm set", "⏰ Alarm set for 6:30 AM", kind = Kind.SUCCESS)
            }) else emptyList()
        )
    }
}

// =================================================================== DAILY REPORT

object DailyReportSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has("daily report", "aaj kya kya kiya", "aaj ka report", "din ka report", "what did i do today", "activity report", "aaj maine kya kiya")

    override suspend fun run(c: Cmd, env: Env): Reply {
        val today = startOfToday()
        val log = ActionLog.all(env.ctx).filter { it.time >= today }
        val bySkill = log.groupBy { it.skill }.mapValues { it.value.size }.entries.sortedByDescending { it.value }
        val tasks = try {
            JSONArray(env.prefs.tasks)
        } catch (e: Exception) {
            JSONArray()
        }
        val all = (0 until tasks.length()).map { tasks.getJSONObject(it) }
        val done = all.count { it.optBoolean("done") }
        val spent = ExpenseSkill.total(env, today)
        val mistakes = MistakeSkill.all(env).count { it.optLong("last") >= today }
        val items = ArrayList<String>()
        items.add("🤖 AIBhai se ${log.size} kaam karwaye (${log.count { it.status == "verified" }} verified)")
        if (all.isNotEmpty()) items.add("📝 Kaam: $done/${all.size} poore")
        if (spent > 0) items.add("💸 Kharcha: ₹${fmtNum(spent)}")
        if (mistakes > 0) items.add("📕 Galti diary: $mistakes entry")
        bySkill.take(5).forEach { items.add("• ${it.key}: ${it.value}") }
        val score = (done * 20 + log.count { it.status == "verified" } * 5 - mistakes * 10).coerceIn(0, 100)
        return c.reply(
            "📊 Aaj ka report • Productivity $score/100", "📊 Today's report • Productivity $score/100",
            speakHi = "Aaj aapne ${all.size} mein se $done kaam poore kiye, aur AIBhai se ${log.size} kaam karwaye. Productivity score $score." +
                if (spent > 0) " Aaj ka kharcha ${fmtNum(spent)} rupay." else "",
            speakEn = "You finished $done of ${all.size} tasks. Productivity score $score.",
            kind = Kind.TASKS, items = items
        )
    }
}

// =================================================================== HANDS-FREE + LECTURE MODE (handled by controller via status)

object ModeSkill : Skill {
    override fun matches(c: Cmd, env: Env) =
        c.has("hands free", "handsfree", "baat karte raho", "conversation mode", "continuous mode") ||
            c.has("lecture") && c.has("record", "start", "shuru", "likho", "band", "stop", "khatam", "mode")

    override suspend fun run(c: Cmd, env: Env): Reply {
        if (c.has("lecture")) {
            val stop = c.has("band", "stop", "khatam", "end")
            return if (stop) Reply(c.t("🛑 Lecture mode band", "🛑 Lecture mode stopped"), kind = Kind.INFO, status = "lecture_stop", lang = c.lang)
            else Reply(
                c.t("🎧 Lecture mode ON — main sun ke likh raha hoon. Rokne ke liye orb dabao ya bolo 'lecture band'.", "🎧 Lecture mode on — transcribing. Tap the orb or say 'stop lecture'."),
                speak = c.t("Lecture mode shuru", "Lecture mode started"), kind = Kind.INFO, status = "lecture_start", lang = c.lang
            )
        }
        val on = !c.has("band", "off", "stop")
        env.prefs.handsFree = on
        return c.reply(
            if (on) "🎙️ Hands-free ON — jawab ke baad main khud sununga. 'Bas' bolo to ruk jaunga." else "🎙️ Hands-free OFF",
            if (on) "🎙️ Hands-free on — I'll keep listening after each reply. Say 'stop' to end." else "🎙️ Hands-free off",
            kind = Kind.SUCCESS
        )
    }

    /** Make simple notes from a lecture transcript */
    fun summarize(transcript: String): List<String> {
        val sentences = transcript.split(Regex("(?<=[.?!।])\\s+|\\n")).map { it.trim() }.filter { it.length > 8 }
        val key = listOf("important", "imp", "exam", "definition", "formula", "means", "is called", "yaad rakhna", "note karo", "kehte hain",
            "matlab", "zaroori", "question", "law", "principle", "therefore", "isliye", "conclusion")
        val keyLines = sentences.filter { s -> key.any { s.lowercase().contains(it) } }.take(8)
        val stop = setOf("hai", "hain", "ki", "ka", "ke", "ko", "se", "me", "mein", "the", "is", "and", "aur", "to", "a", "of", "in", "ye", "yeh", "wo", "jo",
            "tha", "thi", "par", "pe", "bhi", "nahi", "kya", "this", "that", "are", "for", "it", "hum", "aap", "we", "you", "toh", "so", "ek")
        val words = transcript.lowercase().split(Regex("[^a-z\\u0900-\\u097F]+")).filter { it.length > 3 && it !in stop }
        val topics = words.groupingBy { it }.eachCount().entries.sortedByDescending { it.value }.take(6).map { it.key }
        return listOf("🏷️ Topics: " + topics.joinToString(", ")) + keyLines.map { "⭐ $it" }
    }
}

// =================================================================== SECRET NOTES (PIN)

object SecretSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has("secret note", "secret notes", "private note", "private notes", "gupt", "secret diary")

    private fun file(env: Env) = java.io.File(env.ctx.filesDir, "secret_notes.json")

    fun load(env: Env): JSONArray = try {
        JSONArray(file(env).readText())
    } catch (e: Exception) {
        JSONArray()
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        if (env.prefs.secretPin.isBlank()) {
            return c.reply("🔒 Pehle Settings → 'Secret notes PIN' set karo.", "🔒 Set a 'Secret notes PIN' in Settings first.", kind = Kind.WARN, status = "needs_input")
        }
        val body = Regex("(?:secret note|private note|secret diary|gupt)s?\\s*(?:mein|me|likho|likh lo|save|:|-)?\\s*(.+)").find(c.norm)?.groupValues?.get(1)?.trim()
        val wantsShow = c.has("dikhao", "kholo", "show", "padho", "open", "batao") || body.isNullOrBlank()
        if (!wantsShow && body != null) {
            val text = if (Txt.hasDevanagari(c.raw)) c.raw else body
            val a = load(env)
            a.put(JSONObject().put("t", text).put("m", System.currentTimeMillis()))
            file(env).writeText(a.toString())
            return c.reply("🔒 Secret note save ho gaya (sirf PIN se khulega).", "🔒 Secret note saved (PIN protected).", speakHi = "Secret note save ho gaya.", speakEn = "Saved.", kind = Kind.SUCCESS, status = "verified")
        }
        return Reply(c.t("🔒 Secret notes ke liye PIN daalo", "🔒 Enter your PIN"), speak = null, kind = Kind.INFO, status = "pin_required", lang = c.lang)
    }

    fun unlocked(env: Env): Reply {
        val a = load(env)
        val fmt = SimpleDateFormat("d MMM", Locale.US)
        val items = (0 until a.length()).map { a.getJSONObject(it) }.reversed().map { "🔐 ${fmt.format(Date(it.optLong("m")))} — ${it.optString("t")}" }
        return Reply("🔓 Secret notes (${items.size})", speak = null, kind = Kind.INFO, items = items.ifEmpty { listOf("Abhi koi note nahi") })
    }
}

// =================================================================== BATTERY GUARD (20% / 100% alerts)

object BatteryGuard {
    fun schedule(ctx: Context) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = PendingIntent.getBroadcast(ctx, 6600, Intent(ctx, BatteryReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        if (!Prefs(ctx).batteryAlerts) {
            am.cancel(pi)
            return
        }
        am.setInexactRepeating(AlarmManager.RTC, System.currentTimeMillis() + 60_000L, AlarmManager.INTERVAL_FIFTEEN_MINUTES, pi)
    }
}

class BatteryReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val bm = context.getSystemService(BatteryManager::class.java) ?: return
        val pct = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        if (pct < 0) return
        val plugged = bm.isCharging || bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_STATUS) == BatteryManager.BATTERY_STATUS_FULL
        val sp = context.getSharedPreferences("aibhai", 0)
        val last = sp.getString("bat_alert", "") ?: ""
        when {
            !plugged && pct <= 20 && last != "low" -> {
                Notifs.show(context, "🔋 Battery $pct% bachi hai", "Charger laga lo bhai ⚡", 6601)
                sp.edit().putString("bat_alert", "low").apply()
            }
            plugged && pct >= 100 && last != "full" -> {
                Notifs.show(context, "⚡ Battery 100% full", "Charger hata do — battery ki life badhegi 🔋", 6602)
                sp.edit().putString("bat_alert", "full").apply()
            }
            pct in 25..95 && last.isNotEmpty() -> sp.edit().putString("bat_alert", "").apply()
        }
    }
}
