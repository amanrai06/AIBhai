package com.aibhai.app.skills

import android.Manifest
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Environment
import android.webkit.MimeTypeMap
import androidx.core.content.FileProvider
import com.aibhai.app.core.ActionLog
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Subjects
import com.aibhai.app.core.Txt
import com.aibhai.app.system.Perms
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

object FileSkill : Skill {
    private val fileWords = arrayOf("pdf", "file", "files", "document", "documents", "doc", "docx", "ppt", "pptx")
    private val moveWords = arrayOf(
        "move", "daal", "dal", "daalo", "dalo", "bhej", "bhejo", "shift", "rakh", "rakho", "transfer", "copy", "kopi", "put"
    )
    private val findWords = arrayOf("dhundo", "dhoondo", "dhund", "find", "search", "kholo", "open", "dikhao", "kahan", "kaha", "kidhar", "where")
    private val organizeWords = arrayOf("organize", "organise", "arrange", "sort", "saaf", "jamao", "set karo", "theek karo", "sajao", "clean")
    private val collectWords = arrayOf("collect", "ikattha", "ikatha", "jama", "nikalo", "save", "copy", "laao", "le aao")
    private val docExt = setOf("pdf", "doc", "docx", "ppt", "pptx", "xls", "xlsx", "txt", "odt")
    private val appRegex = Regex("\\bapp\\b")

    data class Op(val from: String, val to: String, val copy: Boolean)

    private val createWords = arrayOf("banao", "bana do", "bnao", "bana", "create", "make", "naya folder", "new folder", "banado")

    private fun isCreateFolder(c: Cmd) = c.has("folder") && c.has(*createWords)

    override fun matches(c: Cmd, env: Env): Boolean {
        if (isCreateFolder(c)) return true
        if (c.has("undo") || c.has("wapas karo", "pehle jaisa", "wapas kar do")) return true
        if (c.has(*organizeWords) && c.has("download", "downloads")) return true
        if (c.has("whatsapp") && c.has(*fileWords) && c.has(*collectWords)) return true
        if (appRegex.containsMatchIn(c.norm) || c.has("manager")) return false
        return c.has(*fileWords) && (c.has(*moveWords) || c.has(*findWords))
    }

    fun hasStorage(ctx: Context): Boolean = Perms.files(ctx)

    override suspend fun run(c: Cmd, env: Env): Reply {
        if (!hasStorage(env.ctx)) {
            return c.reply(
                "Files move karne ke liye 'All files access' chahiye. Button dabao → AIBhai ko Allow karo, phir dobara bolo.",
                "I need 'All files access' to manage files. Tap the button, allow AIBhai, then ask again.",
                kind = Kind.WARN,
                actions = listOf(ReplyAction(c.t("Allow karo", "Allow")) {
                    if (Build.VERSION.SDK_INT >= 30) Perms.openAllFiles(env.ctx)
                    else env.requestPerms(arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE))
                    null
                })
            )
        }
        return withContext(Dispatchers.IO) {
            when {
                isCreateFolder(c) -> createFolder(c, env)
                c.has("undo") || c.has("wapas karo", "pehle jaisa", "wapas kar do") -> undo(env, c.en)
                c.has(*organizeWords) && c.has("download", "downloads") -> organize(env, c)
                c.has("whatsapp") && c.has(*collectWords) -> collectWhatsApp(env, c)
                c.has(*moveWords) -> move(c, env)
                else -> find(c, env)
            }
        }
    }

    // ---------------------------------------------------------------- helpers

    private val root: File get() = Environment.getExternalStorageDirectory()

    private fun skipDir(f: File): Boolean {
        val p = f.absolutePath
        return p.endsWith("/Android") || p.contains("/Android/") || f.name.startsWith(".")
    }

    private fun walkFiles(start: File, maxDepth: Int, filter: (File) -> Boolean): List<File> {
        val out = ArrayList<File>()
        val stack = ArrayDeque<Pair<File, Int>>()
        stack.addLast(Pair(start, 0))
        var visited = 0
        while (stack.isNotEmpty() && visited < 40000) {
            val (dir, d) = stack.removeLast()
            val kids = dir.listFiles() ?: continue
            for (k in kids) {
                visited++
                if (k.name.startsWith(".")) continue
                if (k.isDirectory) {
                    if (d < maxDepth && !skipDir(k)) stack.addLast(Pair(k, d + 1))
                } else if (filter(k)) out.add(k)
            }
        }
        return out
    }

    private fun walkDirs(start: File, maxDepth: Int): List<File> {
        val out = ArrayList<File>()
        val stack = ArrayDeque<Pair<File, Int>>()
        stack.addLast(Pair(start, 0))
        while (stack.isNotEmpty() && out.size < 5000) {
            val (dir, d) = stack.removeLast()
            val kids = dir.listFiles() ?: continue
            for (k in kids) {
                if (k.isDirectory && !skipDir(k)) {
                    out.add(k)
                    if (d < maxDepth) stack.addLast(Pair(k, d + 1))
                }
            }
        }
        return out
    }

    private fun nameKey(name: String): String = Txt.simplify(Txt.normalize(Txt.splitCamel(name)))

    private val stopFile = setOf(
        "wali", "vali", "wala", "vala", "waali", "wale", "file", "files", "pdf", "document", "documents", "doc", "docx", "ppt",
        "ki", "ka", "ke", "ko", "meri", "mera", "mere", "the", "my", "a", "move", "copy", "transfer", "shift", "wo", "vo", "woh",
        "voh", "jo", "hai", "se", "bhai", "please", "ek", "sabse", "nayi", "new", "latest", "last", "dhundo", "dhoondo", "find",
        "search", "kholo", "open", "dikhao", "kahan", "kaha", "kidhar", "where", "is", "karo", "kar", "do", "de", "put", "daal",
        "dal", "daalo", "dalo", "bhej", "bhejo", "rakh", "rakho", "zara", "jara", "plz", "notes", "note", "download", "downloads",
        "folder", "me", "mein", "men", "main", "in", "of", "and", "aur", "us", "usko", "isko", "ye", "yeh"
    )

    private fun queryTokens(q: String): List<String> =
        q.split(' ').map { it.trim() }.filter { it.isNotBlank() && it !in stopFile }.map { Txt.simplify(it) }.filter { it.length >= 2 }

    private fun bestFile(tokens: List<String>, onlyPdf: Boolean): File? {
        val cands = walkFiles(root, 7) { f ->
            val ext = f.extension.lowercase()
            if (onlyPdf) ext == "pdf" else ext in docExt
        }
        var best: File? = null
        var bestScore = 0.0
        for (f in cands) {
            val key = nameKey(f.nameWithoutExtension)
            val ft = key.split(' ')
            val joined = key.replace(" ", "")
            val hits = tokens.count { q -> ft.any { Txt.tokenMatch(it, q) } || (q.length >= 3 && joined.contains(q)) }
            if (hits == 0) continue
            val ratio = hits.toDouble() / tokens.size
            if (tokens.size == 1 && ratio < 1.0) continue
            if (ratio < 0.5) continue
            val score = ratio * 10 + (f.lastModified() / 1e13)
            if (score > bestScore) {
                bestScore = score
                best = f
            }
        }
        return best
    }

    private val stopDest = setOf(
        "folder", "men", "me", "mein", "main", "mai", "mei", "daal", "dal", "daalo", "dalo", "do", "de", "dena", "karo", "kar",
        "kardo", "move", "copy", "bhej", "bhejo", "rakh", "rakho", "shift", "transfer", "to", "in", "into", "the", "wale", "wala",
        "wali", "vala", "vali", "andar", "ke", "ki", "ka", "dijiye", "please", "plz", "bhai", "jara", "zara", "na", "my", "mera",
        "meri", "put", "it", "dear", "di", "diya"
    )

    private fun cleanDest(q: String): String = q.split(' ').filter { it.isNotBlank() && it !in stopDest }.joinToString(" ").trim()

    private fun titleCase(s: String) = s.split(' ').filter { it.isNotBlank() }.joinToString(" ") { w -> w.replaceFirstChar { it.uppercase() } }

    private fun findOrCreateDir(q: String): File {
        val name = cleanDest(q)
        val low = name.lowercase()
        if (low.startsWith("download")) return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (low.startsWith("document")) return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        val key = Txt.simplify(name).replace(" ", "")
        if (key.length >= 2) {
            val dirs = walkDirs(root, 4)
            var best: File? = null
            var bestScore = 0
            for (d in dirs) {
                val dk = nameKey(d.name).replace(" ", "")
                val s = when {
                    dk == key -> 3
                    key.length >= 4 && Txt.lev(dk, key) <= (if (key.length >= 7) 2 else 1) -> 2
                    key.length >= 4 && dk.startsWith(key) -> 1
                    else -> 0
                }
                if (s > bestScore || (s == bestScore && s > 0 && best != null && d.absolutePath.length < best.absolutePath.length)) {
                    bestScore = s
                    best = d
                }
            }
            if (best != null && bestScore > 0) return best
        }
        val created = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), titleCase(name.ifBlank { "AIBhai" }))
        created.mkdirs()
        return created
    }

    fun moveFile(src: File, dir: File, copy: Boolean): File {
        dir.mkdirs()
        var dst = File(dir, src.name)
        var n = 1
        while (dst.exists()) {
            val ext = if (src.extension.isNotEmpty()) "." + src.extension else ""
            dst = File(dir, "${src.nameWithoutExtension} ($n)$ext")
            n++
        }
        if (!copy && src.renameTo(dst)) return dst
        src.copyTo(dst)
        if (!copy) src.delete()
        return dst
    }

    /** Level-3: confirm the action really happened on disk */
    fun verify(op: Op): Boolean {
        val to = File(op.to)
        val from = File(op.from)
        return to.exists() && to.length() > 0 && (op.copy || !from.exists())
    }

    private fun saveUndo(env: Env, ops: List<Op>) {
        val a = JSONArray()
        ops.forEach { a.put(JSONObject().put("f", it.from).put("t", it.to).put("c", it.copy)) }
        env.prefs.undo = a.toString()
    }

    fun undo(env: Env, en: Boolean): Reply {
        val a = try {
            JSONArray(env.prefs.undo)
        } catch (e: Exception) {
            JSONArray()
        }
        if (a.length() == 0) {
            return Reply(if (en) "Nothing to undo." else "Undo karne ke liye kuch nahi hai.", kind = Kind.INFO, lang = if (en) "en" else "hi")
        }
        var ok = 0
        for (i in a.length() - 1 downTo 0) {
            val o = a.getJSONObject(i)
            val to = File(o.optString("t"))
            val from = File(o.optString("f"))
            try {
                if (o.optBoolean("c")) {
                    if (to.delete()) ok++
                } else if (to.exists()) {
                    from.parentFile?.mkdirs()
                    if (!to.renameTo(from)) {
                        to.copyTo(from, overwrite = false)
                        to.delete()
                    }
                    ok++
                }
            } catch (e: Exception) {
            }
        }
        env.prefs.undo = "[]"
        return Reply(
            if (en) "↩️ Undone — $ok files restored." else "↩️ Undo ho gaya — $ok file wapas apni jagah.",
            kind = Kind.FILES, lang = if (en) "en" else "hi"
        )
    }

    fun openFile(env: Env, f: File) {
        try {
            val uri = FileProvider.getUriForFile(env.ctx, env.ctx.packageName + ".files", f)
            val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(f.extension.lowercase()) ?: "*/*"
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            env.launch(i)
        } catch (e: Exception) {
        }
    }

    private fun shortPath(p: String?): String =
        (p ?: "").removePrefix(root.absolutePath).ifBlank { "/" }

    private fun splitMove(n: String): Pair<String, String> {
        Regex("\\b(?:move|copy|transfer|shift|put)\\s+(.+?)\\s+(?:to|into|in)\\s+(.+)").find(n)?.let {
            return Pair(it.groupValues[1], it.groupValues[2])
        }
        val t = " $n "
        val idx = t.indexOf(" ko ")
        if (idx >= 0) return Pair(t.substring(0, idx), t.substring(idx + 4))
        Regex("(.+)\\s+(\\S+)\\s+(?:folder|me|mein|men)\\b").find(n)?.let {
            return Pair(it.groupValues[1], it.groupValues[2])
        }
        return Pair(n, "")
    }

    // ---------------------------------------------------------------- actions

    private fun move(c: Cmd, env: Env): Reply {
        val copy = c.has("copy", "kopi")
        val (fileQ, destQ) = splitMove(c.norm)
        val tokens = queryTokens(fileQ)
        if (tokens.isEmpty()) {
            return c.reply(
                "Kaunsi file? Jaise bolo: 'Communication wali PDF ko English folder mein daalo'",
                "Which file? Say: 'move the communication PDF to English folder'",
                kind = Kind.WARN
            )
        }
        if (cleanDest(destQ).isBlank()) {
            return c.reply("Kis folder mein daalun? Folder ka naam bhi bolo 🙂", "Which folder? Please say the folder name 🙂", kind = Kind.WARN)
        }
        val file = bestFile(tokens, c.has("pdf"))
            ?: return c.reply(
                "'${fileQ.trim()}' naam ki file nahi mili 😕 File ke naam ka koi word bolo.",
                "Couldn't find a file like '${fileQ.trim()}' 😕",
                kind = Kind.WARN, teachable = true
            )
        val dir = findOrCreateDir(destQ)
        val dst = moveFile(file, dir, copy)
        val op = Op(file.absolutePath, dst.absolutePath, copy)
        saveUndo(env, listOf(op))
        if (!verify(op)) {
            return c.reply(
                "⚠️ Move try kiya par verify fail hua — file shayad nayi jagah nahi pahunchi. Permission check karo.",
                "⚠️ Tried to move, but verification failed — please check storage permission.",
                kind = Kind.ERROR, status = "failed"
            )
        }
        return c.reply(
            "✅ ${file.name} → ${dir.name} (${if (copy) "copy" else "move"} ho gayi)",
            "✅ ${file.name} → ${dir.name} (${if (copy) "copied" else "moved"})",
            speakHi = "Ho gaya ${env.name}! File ${dir.name} folder mein ${if (copy) "copy" else "move"} kar di.",
            speakEn = "Done! The file is now in the ${dir.name} folder.",
            kind = Kind.FILES,
            items = listOf("From: ${shortPath(file.parent)}", "To: ${shortPath(dst.parent)}", c.t("✓ Verified: file nayi jagah pe hai", "✓ Verified: file is in the new folder")),
            status = "verified",
            actions = listOf(
                ReplyAction(c.t("Kholo", "Open")) {
                    openFile(env, dst)
                    null
                },
                ReplyAction("Undo") { withContext(Dispatchers.IO) { undo(env, c.en) } }
            )
        )
    }

    private fun find(c: Cmd, env: Env): Reply {
        val tokens = queryTokens(c.norm)
        if (tokens.isEmpty()) return c.reply("Kaunsi file dhundu? Naam ka koi word bolo.", "Which file? Say a word from its name.", kind = Kind.WARN)
        val f = bestFile(tokens, c.has("pdf"))
            ?: return c.reply("Aisi koi file nahi mili 😕", "No matching file found 😕", kind = Kind.WARN, teachable = true)
        val autoOpen = c.has("kholo", "open", "dikhao")
        if (autoOpen) openFile(env, f)
        return c.reply(
            "📄 Mil gayi: ${f.name}", "📄 Found: ${f.name}",
            speakHi = if (autoOpen) "Mil gayi, khol raha hoon." else "Mil gayi! ${shortPath(f.parent)} folder mein hai.",
            speakEn = if (autoOpen) "Found it, opening now." else "Found it in ${shortPath(f.parent)}.",
            kind = Kind.FILES,
            items = listOf("📁 ${shortPath(f.parent)}"),
            actions = listOf(ReplyAction(c.t("Kholo", "Open")) {
                openFile(env, f)
                null
            })
        )
    }

    // ---------------------------------------------------------------- "X naam ka folder banao aur usme A, B aur C daalo"

    private val folderNameRes = listOf(
        Regex("(?:folder|directory)\\s+(?:banao|bana do|bnao|create karo|create|make|banado)?\\s*(?:jiska naam|uska naam|naam|named|called|name)\\s+(?:ho\\s+)?([a-z0-9 _-]+?)(?:\\s+(?:aur|and|usme|usmein|ismein|isme|mein|me|with|hai|ho)\\b|$)"),
        Regex("([a-z0-9_-]+(?:\\s+[a-z0-9_-]+)?)\\s+naam\\s+(?:ka|se|wala)\\s+(?:ek\\s+)?(?:naya\\s+)?folder"),
        Regex("(?:create|make)\\s+(?:a\\s+)?(?:new\\s+)?folder\\s+(?:named\\s+|called\\s+)?([a-z0-9_-]+(?:\\s+[a-z0-9_-]+)?)"),
        Regex("(?:ek\\s+)?(?:naya\\s+)?([a-z0-9_-]+(?:\\s+[a-z0-9_-]+)?)\\s+folder\\s+(?:banao|bana do|bnao|create|banado)")
    )
    private val putSplit = Regex("\\b(?:usme|usmein|usmen|ismein|isme|ismen|is mein|us mein|aur usme|and put|put|with|jisme)\\b")

    private fun createFolder(c: Cmd, env: Env): Reply {
        val n = c.norm
        val raw = folderNameRes.firstNotNullOfOrNull { it.find(n)?.groupValues?.get(1) }?.trim().orEmpty()
        val name = raw.split(' ').filter { it.isNotBlank() && it !in setOf("ek", "naya", "new", "ka", "ki", "ke", "a", "the", "my", "mera", "folder") }
            .joinToString(" ").let { titleCase(it) }
        if (name.isBlank()) {
            return c.reply("📁 Folder ka naam kya rakhun? Jaise: 'Sem1 naam ka folder banao'", "📁 What should I name the folder?", kind = Kind.WARN, status = "needs_input")
        }
        val base = if (c.has("download", "downloads")) Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        else Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        val dir = File(base, name)
        val existed = dir.exists()
        dir.mkdirs()
        if (!dir.exists()) return c.reply("❌ Folder nahi ban paya (permission?).", "❌ Couldn't create the folder.", kind = Kind.ERROR, status = "failed")
        // files to put inside
        val after = putSplit.split(n, 2).getOrNull(1)?.trim().orEmpty()
        val copy = c.has("copy", "kopi")
        val onlyPdf = c.has("pdf")
        val queries = after.split(Regex("\\s*(?:,|\\baur\\b|\\band\\b|\\bphir\\b)\\s*")).map { it.trim() }.filter { it.isNotBlank() }
        val plan = ArrayList<Triple<File, File, Boolean>>()
        val missing = ArrayList<String>()
        for (q in queries) {
            val tokens = queryTokens(q.replace(Regex("\\b(daalo|dalo|daal do|rakho|rakh do|move|copy|karo|kar do|files?|pdfs?|saari|sab|all)\\b"), " "))
            if (tokens.isEmpty()) continue
            val all = c.has("saari", "sab", "all") || q.contains("saari") || q.contains("all")
            val found = if (all) allFiles(tokens, onlyPdf) else listOfNotNull(bestFile(tokens, onlyPdf))
            if (found.isEmpty()) missing.add(q) else found.forEach { f -> if (plan.none { it.first == f }) plan.add(Triple(f, dir, copy)) }
        }
        val head = if (existed) "📁 '$name' folder pehle se hai" else "📁 '$name' folder ban gaya ✓"
        if (plan.isEmpty()) {
            return c.reply(
                head + (if (queries.isNotEmpty()) " — par ye files nahi mili: ${missing.joinToString()}" else ""),
                "📁 Folder '$name' ready" + (if (queries.isNotEmpty()) " — files not found: ${missing.joinToString()}" else ""),
                kind = if (missing.isEmpty()) Kind.SUCCESS else Kind.WARN, status = if (missing.isEmpty()) "verified" else "needs_input",
                items = listOf("📍 ${shortPath(dir.absolutePath)}"),
                actions = listOf(ReplyAction(c.t("📂 Kholo", "📂 Open")) { openFolder(env, dir); null })
            )
        }
        return c.reply(
            "$head\n🗂️ Plan: ${plan.size} files ${if (copy) "copy" else "move"} karun?",
            "📁 Folder '$name' ready. Plan: ${if (copy) "copy" else "move"} ${plan.size} files?",
            speakHi = "$name folder ready. ${plan.size} files daalne ka plan hai, haan dabao.",
            speakEn = "Folder ready. Tap yes to move ${plan.size} files.",
            kind = Kind.FILES, status = "needs_approval",
            items = plan.map { "• ${Txt.short(it.first.name, 44)}" } + missing.map { "⚠️ Nahi mili: $it" } + listOf("📍 ${shortPath(dir.absolutePath)}"),
            actions = listOf(
                ReplyAction(c.t("✅ Haan, karo", "✅ Yes")) { withContext(Dispatchers.IO) { executePlan(env, c, plan) } },
                ReplyAction(c.t("❌ Rehne do", "❌ Cancel")) { c.reply("Theek hai, sirf folder bana hai.", "Okay, only the folder was created.") }
            )
        )
    }

    private fun allFiles(tokens: List<String>, onlyPdf: Boolean): List<File> =
        walkFiles(root, 7) { f -> val e = f.extension.lowercase(); if (onlyPdf) e == "pdf" else e in docExt }
            .filter { f ->
                val key = nameKey(f.nameWithoutExtension)
                val ft = key.split(' ')
                val hits = tokens.count { q -> ft.any { Txt.tokenMatch(it, q) } || (q.length >= 3 && key.replace(" ", "").contains(q)) }
                hits.toDouble() / tokens.size >= 0.5
            }.take(40)

    private fun openFolder(env: Env, dir: File) {
        try {
            val i = Intent(Intent.ACTION_VIEW).setDataAndType(
                android.provider.DocumentsContract.buildDocumentUri(
                    "com.android.externalstorage.documents",
                    "primary:" + dir.absolutePath.removePrefix(root.absolutePath).trimStart('/')
                ), android.provider.DocumentsContract.Document.MIME_TYPE_DIR
            )
            if (!env.launch(i)) env.launch(Intent(Intent.ACTION_VIEW).setType("resource/folder"))
        } catch (e: Exception) {
        }
    }

    private fun collegeDir(): File =
        File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS), "College")

    private fun organize(env: Env, c: Cmd): Reply {
        val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val files = dl.listFiles()?.filter { it.isFile && it.extension.lowercase() in docExt } ?: emptyList()
        if (files.isEmpty()) return c.reply("Downloads mein koi PDF/notes nahi mili — sab saaf hai ✨", "No PDFs/notes in Downloads — all clean ✨", kind = Kind.FILES)
        val plan = files.mapNotNull { f -> Subjects.detect(nameKey(f.nameWithoutExtension))?.let { Pair(f, it) } }
        if (plan.isEmpty()) {
            return c.reply(
                "${files.size} files mili, par naam se subject pata nahi chala. Naam mein subject (Maths, EGD, BEEE…) ho to sort kar dunga.",
                "Found ${files.size} files but couldn't tell their subjects from the names.",
                kind = Kind.WARN
            )
        }
        // Level-3: show the plan first, act only after human approval
        val preview = plan.take(8).map { "• ${Txt.short(it.first.name, 40)} → ${it.second}" } +
            (if (plan.size > 8) listOf("… +${plan.size - 8} aur") else emptyList())
        return c.reply(
            "🗂️ Plan: ${plan.size} files ko subject folders (Documents/College) mein move karun?",
            "🗂️ Plan: move ${plan.size} files into subject folders (Documents/College)?",
            speakHi = "${plan.size} files ka plan ready hai. Haan dabao to move kar dunga.",
            speakEn = "I have a plan for ${plan.size} files. Tap yes to move them.",
            kind = Kind.FILES,
            items = preview,
            status = "needs_approval",
            actions = listOf(
                ReplyAction(c.t("✅ Haan, karo", "✅ Yes, do it")) {
                    withContext(Dispatchers.IO) { executePlan(env, c, plan.map { Triple(it.first, File(collegeDir(), it.second), false) }) }
                },
                ReplyAction(c.t("❌ Rehne do", "❌ Cancel")) {
                    ActionLog.add(env.ctx, c.raw, "File", "Organize cancelled by user", "cancelled")
                    c.reply("Theek hai, kuch nahi chheda.", "Okay, nothing changed.", kind = Kind.INFO)
                }
            )
        )
    }

    private fun executePlan(env: Env, c: Cmd, plan: List<Triple<File, File, Boolean>>): Reply {
        val ops = ArrayList<Op>()
        val counts = LinkedHashMap<String, Int>()
        var failed = 0
        for ((f, dir, copy) in plan) {
            try {
                val dst = moveFile(f, dir, copy)
                val op = Op(f.absolutePath, dst.absolutePath, copy)
                if (verify(op)) {
                    ops.add(op)
                    counts[dir.name] = (counts[dir.name] ?: 0) + 1
                } else failed++
            } catch (e: Exception) {
                failed++
            }
        }
        saveUndo(env, ops)
        val status = if (failed == 0) "verified" else "failed"
        val r = c.reply(
            "✅ ${ops.size} files done & verified" + if (failed > 0) " • ⚠️ $failed fail" else "",
            "✅ ${ops.size} files done & verified" + if (failed > 0) " • ⚠️ $failed failed" else "",
            speakHi = "Ho gaya! ${ops.size} files sahi jagah pahunch gayi, maine check bhi kar liya." + if (failed > 0) " $failed files mein dikkat aayi." else "",
            speakEn = "Done! ${ops.size} files moved and verified." + if (failed > 0) " $failed failed." else "",
            kind = if (failed == 0) Kind.FILES else Kind.WARN,
            items = counts.map { "📁 ${it.key}: ${it.value}" },
            status = status,
            actions = listOf(ReplyAction("Undo") { withContext(Dispatchers.IO) { undo(env, c.en) } })
        )
        ActionLog.add(env.ctx, c.raw, "File", "Approved → ${ops.size} ok, $failed failed", if (failed == 0) "approved" else "failed")
        return r
    }

    private fun collectWhatsApp(env: Env, c: Cmd): Reply {
        val r = root.absolutePath
        val dirs = listOf(
            "$r/Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Documents",
            "$r/Android/media/com.whatsapp.w4b/WhatsApp Business/Media/WhatsApp Business Documents",
            "$r/WhatsApp/Media/WhatsApp Documents"
        ).map { File(it) }.filter { it.exists() }
        if (dirs.isEmpty()) return c.reply("WhatsApp Documents folder nahi mila.", "WhatsApp Documents folder not found.", kind = Kind.WARN)
        val since = if (c.has("aaj", "today")) startOfToday() else System.currentTimeMillis() - 7L * 86400_000L
        val plan = ArrayList<Triple<File, File, Boolean>>()
        for (d in dirs) {
            val files = d.walkTopDown().maxDepth(2).filter { it.isFile && it.extension.lowercase() in docExt && it.lastModified() >= since }.toList()
            for (f in files) {
                val subj = Subjects.detect(nameKey(f.nameWithoutExtension)) ?: "WhatsApp Notes"
                val target = File(collegeDir(), subj)
                if (File(target, f.name).let { it.exists() && it.length() == f.length() }) continue
                plan.add(Triple(f, target, true))
            }
        }
        if (plan.isEmpty()) return c.reply("WhatsApp pe koi naye notes/PDF nahi mile.", "No new notes/PDFs from WhatsApp.", kind = Kind.FILES)
        val preview = plan.take(8).map { "• ${Txt.short(it.first.name, 40)} → ${it.second.name}" } +
            (if (plan.size > 8) listOf("… +${plan.size - 8} aur") else emptyList())
        return c.reply(
            "📥 WhatsApp se ${plan.size} notes mile. College folder mein copy karun?",
            "📥 Found ${plan.size} notes on WhatsApp. Copy them to College folder?",
            kind = Kind.FILES,
            items = preview,
            status = "needs_approval",
            actions = listOf(
                ReplyAction(c.t("✅ Haan, copy karo", "✅ Yes, copy")) { withContext(Dispatchers.IO) { executePlan(env, c, plan) } },
                ReplyAction(c.t("❌ Rehne do", "❌ Cancel")) {
                    ActionLog.add(env.ctx, c.raw, "File", "WhatsApp collect cancelled", "cancelled")
                    c.reply("Theek hai.", "Okay.", kind = Kind.INFO)
                }
            )
        )
    }
}
