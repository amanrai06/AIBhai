package com.aibhai.app.skills

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.util.Xml
import com.aibhai.app.Prefs
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Txt
import com.aibhai.app.system.Notifs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.xmlpull.v1.XmlPullParser
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar

/**
 * Free news (Google News RSS, no API key, no limit).
 * EV + Mechanical Engineering updates always come FIRST, then top India news and tech.
 */
object NewsSkill : Skill {
    data class Item(val title: String, val source: String, val link: String, val topic: String)

    private const val EN = "&hl=en-IN&gl=IN&ceid=IN:en"
    private const val HI = "&hl=hi&gl=IN&ceid=IN:hi"
    private val evUrl = "https://news.google.com/rss/search?q=" +
        Uri.encode("(\"electric vehicle\" OR EV OR \"EV battery\" OR \"electric car\" OR \"electric scooter\") when:2d") + EN
    private val meUrl = "https://news.google.com/rss/search?q=" +
        Uri.encode("(\"mechanical engineering\" OR automobile technology OR manufacturing OR \"battery technology\" OR robotics) when:3d") + EN
    private const val TECH = "https://news.google.com/rss/headlines/section/topic/TECHNOLOGY?x=1$EN"
    private const val TOP_EN = "https://news.google.com/rss?x=1$EN"
    private const val TOP_HI = "https://news.google.com/rss?x=1$HI"

    private val cache = HashMap<String, Pair<Long, List<Item>>>()

    override fun matches(c: Cmd, env: Env): Boolean {
        if (c.has("news", "khabar", "khabre", "khabrein", "samachar", "headlines", "headline", "kya naya", "naya kya", "new kya",
                "whats new", "what's new", "trending", "duniya mein kya", "taaza", "taza")) return true
        val topic = c.has("ev", "electric vehicle", "electric car", "mechanical", "automobile", "technology", "tech", "battery technology")
        return topic && c.has("update", "updates", "new", "naya", "nayi", "latest", "kya hua", "kya chal", "batao")
    }

    private fun fetch(url: String, topic: String, max: Int): List<Item> {
        synchronized(cache) {
            cache[url]?.let { (t, l) -> if (System.currentTimeMillis() - t < 20 * 60_000L) return l }
        }
        val out = ArrayList<Item>()
        try {
            val con = URL(url).openConnection() as HttpURLConnection
            con.connectTimeout = 7000
            con.readTimeout = 9000
            con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AIBhai/1.0")
            con.inputStream.use { inp ->
                val p = Xml.newPullParser()
                p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
                p.setInput(inp, null)
                var inItem = false
                var title = ""
                var link = ""
                var source = ""
                var ev = p.eventType
                while (ev != XmlPullParser.END_DOCUMENT && out.size < max) {
                    if (ev == XmlPullParser.START_TAG) {
                        when (p.name) {
                            "item" -> {
                                inItem = true; title = ""; link = ""; source = ""
                            }
                            "title" -> if (inItem) title = p.nextText()
                            "link" -> if (inItem) link = p.nextText()
                            "source" -> if (inItem) source = p.nextText()
                        }
                    } else if (ev == XmlPullParser.END_TAG && p.name == "item") {
                        inItem = false
                        var t = title.trim()
                        if (source.isBlank() && t.contains(" - ")) source = t.substringAfterLast(" - ")
                        if (source.isNotBlank() && t.endsWith(" - $source")) t = t.removeSuffix(" - $source")
                        if (t.isNotBlank()) out.add(Item(t, source.trim(), link.trim(), topic))
                    }
                    ev = p.next()
                }
            }
        } catch (e: Exception) {
        }
        if (out.isNotEmpty()) synchronized(cache) { cache[url] = Pair(System.currentTimeMillis(), out) }
        return out
    }

    /** EV/ME first, then general. Runs on IO. */
    suspend fun headlines(hindiTop: Boolean, evOnly: Boolean = false): List<Item> = withContext(Dispatchers.IO) {
        coroutineScope {
            val ev = async { fetch(evUrl, "EV", 6) }
            val me = async { fetch(meUrl, "ME", 5) }
            val top = async { if (evOnly) emptyList() else fetch(if (hindiTop) TOP_HI else TOP_EN, "TOP", 6) }
            val tech = async { if (evOnly) emptyList() else fetch(TECH, "TECH", 4) }
            val seen = HashSet<String>()
            val all = ArrayList<Item>()
            fun addSome(list: List<Item>, n: Int) {
                var k = 0
                for (i in list) {
                    val key = Txt.simplify(Txt.normalize(i.title)).take(40)
                    if (k < n && seen.add(key)) {
                        all.add(i); k++
                    }
                }
            }
            addSome(ev.await(), if (evOnly) 5 else 3)
            addSome(me.await(), if (evOnly) 3 else 2)
            addSome(top.await(), 3)
            addSome(tech.await(), 2)
            all
        }
    }

    private fun icon(t: String) = when (t) {
        "EV" -> "⚡ EV"
        "ME" -> "⚙️ Mech"
        "TECH" -> "💻 Tech"
        else -> "📰 India"
    }

    private fun saveCache(env: Env, list: List<Item>) {
        val a = org.json.JSONArray()
        list.forEach { a.put(org.json.JSONObject().put("t", it.title).put("s", it.source).put("l", it.link).put("p", it.topic)) }
        env.ctx.getSharedPreferences("aibhai", 0).edit()
            .putString("news_cache", org.json.JSONObject().put("time", System.currentTimeMillis()).put("items", a).toString()).apply()
    }

    private fun loadCache(env: Env): Pair<Long, List<Item>> = try {
        val o = org.json.JSONObject(env.ctx.getSharedPreferences("aibhai", 0).getString("news_cache", "{}") ?: "{}")
        val a = o.optJSONArray("items") ?: org.json.JSONArray()
        Pair(o.optLong("time"), (0 until a.length()).map { a.getJSONObject(it) }.map { Item(it.optString("t"), it.optString("s"), it.optString("l"), it.optString("p")) })
    } catch (e: Exception) {
        Pair(0L, emptyList())
    }

    /** Offline: show the last saved headlines (if any). */
    fun offlineReply(c: Cmd, env: Env): Reply? {
        val (t, list) = loadCache(env)
        if (list.isEmpty()) return null
        val whenTxt = java.text.SimpleDateFormat("d MMM, h:mm a", java.util.Locale.US).format(java.util.Date(t))
        return c.reply(
            "📴 Offline — pichli saved news ($whenTxt). Internet aate hi taaza news bataunga.",
            "📴 Offline — last saved news ($whenTxt). I'll fetch fresh news when online.",
            speakHi = "Abhi internet nahi hai, pichli saved khabar: " + list.take(3).joinToString(". ") { it.title },
            speakEn = "You're offline. Last saved headlines: " + list.take(3).joinToString(". ") { it.title },
            items = list.mapIndexed { i, it -> "${i + 1}. ${icon(it.topic)} · ${it.title}" }
        )
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val evOnly = c.has("ev", "electric", "mechanical", "automobile") && !c.has("news", "khabar", "samachar", "headlines")
        val list = headlines(hindiTop = !c.en, evOnly = evOnly)
        if (list.isNotEmpty()) saveCache(env, list)
        if (list.isEmpty()) {
            offlineReply(c, env)?.let { return it }
            return c.reply(
                "📡 News laane ke liye internet chahiye. Data/Wi-Fi on karke phir bolo.",
                "📡 I need internet for news. Turn on data/Wi-Fi and ask again.",
                kind = Kind.WARN, status = "failed"
            )
        }
        val evMe = list.filter { it.topic == "EV" || it.topic == "ME" }
        val rest = list.filter { it.topic != "EV" && it.topic != "ME" }
        val hi = StringBuilder("${env.name}, sabse pehle EV aur Mechanical ki taaza khabar. ")
        val en = StringBuilder("${env.name}, first the latest in EV and mechanical engineering. ")
        evMe.take(3).forEachIndexed { i, it ->
            hi.append("${i + 1}. ${it.title}. ")
            en.append("${i + 1}. ${it.title}. ")
        }
        if (rest.isNotEmpty()) {
            hi.append("Ab baaki duniya ki badi khabrein. ")
            en.append("Now the top headlines. ")
            rest.take(3).forEachIndexed { i, it ->
                hi.append("${i + 1}. ${it.title}. ")
                en.append("${i + 1}. ${it.title}. ")
            }
        }
        val items = list.mapIndexed { i, it -> "${i + 1}. ${icon(it.topic)} · ${it.title}${if (it.source.isNotBlank()) " (${it.source})" else ""}" }
        val actions = list.take(4).mapIndexed { i, it ->
            ReplyAction("🔗 ${i + 1}. ${Txt.short(it.title, 22)}") {
                env.launch(Intent(Intent.ACTION_VIEW, Uri.parse(it.link)))
                null
            }
        }
        return c.reply(
            "📰 Aaj ki taaza khabar — EV & Mechanical pehle",
            "📰 Today's news — EV & Mechanical first",
            speakHi = hi.toString(), speakEn = en.toString(),
            kind = Kind.INFO, items = items, actions = actions, status = "ok"
        )
    }

    /** One EV headline for the morning briefing (fast, with timeout). */
    suspend fun topEvHeadline(): String? = withTimeoutOrNull(6000) {
        withContext(Dispatchers.IO) { fetch(evUrl, "EV", 3).firstOrNull()?.title }
    }

    // ---------------------------------------------------------- daily 8 AM news alert

    fun scheduleDaily(ctx: Context) {
        try {
            val am = ctx.getSystemService(AlarmManager::class.java) ?: return
            val pi = PendingIntent.getBroadcast(
                ctx, 4242, Intent(ctx, NewsReceiver::class.java),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            if (!Prefs(ctx).newsAlerts) {
                am.cancel(pi)
                return
            }
            val cal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 8); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
                if (before(Calendar.getInstance())) add(Calendar.DAY_OF_MONTH, 1)
            }
            am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
        } catch (e: Exception) {
        }
    }
}

class NewsReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (com.aibhai.app.core.Eco.active(context)) return
        val pending = goAsync()
        Thread {
            try {
                val list = runBlocking { NewsSkill.headlines(hindiTop = true, evOnly = true) }
                if (list.isNotEmpty()) {
                    val text = list.take(4).joinToString("\n") { "• " + it.title }
                    Notifs.show(context, "⚡ Aaj ki EV & Mechanical news", text, 4243)
                }
            } catch (e: Exception) {
            } finally {
                pending.finish()
            }
        }.start()
    }
}
