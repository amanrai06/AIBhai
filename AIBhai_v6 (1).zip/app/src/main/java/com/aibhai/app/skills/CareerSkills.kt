package com.aibhai.app.skills

import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Subjects
import com.aibhai.app.core.Txt
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

/** Small JSON store helpers (app-private SharedPreferences) */
private fun arr(env: Env, key: String): JSONArray = try {
    JSONArray(env.ctx.getSharedPreferences("aibhai", 0).getString(key, "[]") ?: "[]")
} catch (e: Exception) {
    JSONArray()
}

private fun obj(env: Env, key: String): JSONObject = try {
    JSONObject(env.ctx.getSharedPreferences("aibhai", 0).getString(key, "{}") ?: "{}")
} catch (e: Exception) {
    JSONObject()
}

private fun save(env: Env, key: String, v: Any) {
    env.ctx.getSharedPreferences("aibhai", 0).edit().putString(key, v.toString()).apply()
}

private fun list(a: JSONArray): List<JSONObject> = (0 until a.length()).map { a.getJSONObject(it) }

// =================================================================== STUDY TIMER LOG + STREAK

object StudyLogSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has(
        "padhai shuru", "study start", "padhna shuru", "padhai band", "study stop", "padhai khatam", "padhai ho gayi",
        "kitni padhai", "study report", "padhai report", "study hours", "padhai ka hisab", "streak"
    )

    private fun fmtMin(m: Long) = if (m >= 60) "${m / 60}h ${m % 60}m" else "${m}m"

    override suspend fun run(c: Cmd, env: Env): Reply {
        val cur = obj(env, "study_cur")
        val log = arr(env, "study_log")
        if (c.has("padhai shuru", "study start", "padhna shuru")) {
            val subj = Subjects.detect(c.s) ?: "General"
            save(env, "study_cur", JSONObject().put("s", subj).put("t", System.currentTimeMillis()))
            return c.reply("📖 $subj ki padhai shuru — timer chalu ⏱️. Khatam hone pe bolo 'padhai band'.", "📖 $subj study started ⏱️", kind = Kind.SUCCESS)
        }
        if (c.has("padhai band", "study stop", "padhai khatam", "padhai ho gayi")) {
            val t = cur.optLong("t")
            if (t == 0L) return c.reply("Koi padhai timer chal hi nahi raha tha. Bolo 'Maths padhai shuru'.", "No study timer running.", kind = Kind.WARN)
            val mins = ((System.currentTimeMillis() - t) / 60_000L).coerceAtLeast(1)
            log.put(JSONObject().put("s", cur.optString("s")).put("m", mins).put("d", startOfToday()))
            save(env, "study_log", log)
            save(env, "study_cur", JSONObject())
            val today = list(log).filter { it.optLong("d") == startOfToday() }.sumOf { it.optLong("m") }
            return c.reply(
                "✅ ${cur.optString("s")}: ${fmtMin(mins)} padhai. Aaj total ${fmtMin(today)} 💪",
                "✅ ${cur.optString("s")}: ${fmtMin(mins)}. Today ${fmtMin(today)} 💪",
                kind = Kind.SUCCESS, status = "verified"
            )
        }
        // report + streak
        val days = list(log).map { it.optLong("d") }.toSet()
        var streak = 0
        var d = startOfToday()
        if (d !in days) d -= 86400_000L
        while (d in days) {
            streak++; d -= 86400_000L
        }
        val weekStart = startOfToday() - 6 * 86400_000L
        val week = list(log).filter { it.optLong("d") >= weekStart }
        val bySub = week.groupBy { it.optString("s") }.mapValues { e -> e.value.sumOf { it.optLong("m") } }.entries.sortedByDescending { it.value }
        val total = week.sumOf { it.optLong("m") }
        val today = list(log).filter { it.optLong("d") == startOfToday() }.sumOf { it.optLong("m") }
        return c.reply(
            "📊 Padhai: aaj ${fmtMin(today)} • 7 din ${fmtMin(total)} • 🔥 $streak din streak",
            "📊 Study: today ${fmtMin(today)} • week ${fmtMin(total)} • 🔥 $streak-day streak",
            speakHi = "Aaj ${fmtMin(today)} padhai hui, is hafte ${fmtMin(total)}. Aapki streak $streak din ki hai.",
            speakEn = "Today ${fmtMin(today)}, this week ${fmtMin(total)}. Streak $streak days.",
            kind = Kind.TASKS, items = bySub.map { "📘 ${it.key}: ${fmtMin(it.value)}" }
        )
    }
}

// =================================================================== EV CAREER ROADMAP TRACKER

object RoadmapSkill : Skill {
    private val steps = listOf(
        "EV basics" to listOf("ev basics", "basics", "ev fundamentals"),
        "Li-ion battery & cell chemistry (NMC, LFP)" to listOf("battery", "cell", "lithium", "chemistry", "lfp"),
        "BMS (SOC, SOH, balancing, protection)" to listOf("bms", "battery management"),
        "Electric motors (BLDC, PMSM, induction)" to listOf("motor", "bldc", "pmsm"),
        "Motor controller & power electronics" to listOf("controller", "power electronics", "inverter"),
        "Vehicle dynamics & range calculation" to listOf("vehicle dynamics", "dynamics", "range"),
        "CAD (SolidWorks / CATIA / Fusion)" to listOf("cad", "solidworks", "catia", "fusion"),
        "MATLAB / Simulink EV model" to listOf("matlab", "simulink"),
        "Python for engineers" to listOf("python"),
        "Thermal management & cooling" to listOf("thermal", "cooling"),
        "Charging (AC/DC, CCS, Bharat standards)" to listOf("charging", "charger", "ccs"),
        "Project: e-bike / EV kit / BMS on ESP32" to listOf("project", "esp32", "ebike", "e bike"),
        "Competition (SAE e-BAJA / Formula Bharat / ESVC)" to listOf("competition", "baja", "formula bharat", "esvc"),
        "Internship at EV company" to listOf("internship", "intern")
    )

    override fun matches(c: Cmd, env: Env) = c.has("roadmap", "ev career", "career plan", "ev skills", "skill progress") ||
        (c.has("seekh liya", "sikh liya", "complete ho gaya", "complete kiya", "done ho gaya", "learned") && steps.any { (_, k) -> k.any { c.has(it) } })

    override suspend fun run(c: Cmd, env: Env): Reply {
        val done = obj(env, "roadmap")
        if (c.has("seekh liya", "sikh liya", "complete ho gaya", "complete kiya", "done ho gaya", "learned")) {
            val st = steps.firstOrNull { (_, k) -> k.any { c.has(it) } }
            if (st != null) {
                done.put(st.first, System.currentTimeMillis())
                save(env, "roadmap", done)
            }
        }
        val n = steps.count { done.has(it.first) }
        val pct = n * 100 / steps.size
        val next = steps.firstOrNull { !done.has(it.first) }?.first
        return c.reply(
            "🚗⚡ EV Career Roadmap: $pct% ($n/${steps.size})" + (next?.let { "\n👉 Agla step: $it" } ?: "\n🏆 Roadmap complete!"),
            "🚗⚡ EV Career Roadmap: $pct% ($n/${steps.size})" + (next?.let { "\n👉 Next: $it" } ?: ""),
            speakHi = "EV roadmap $pct percent complete. " + (next?.let { "Agla step: $it." } ?: "Shabash, poora ho gaya!"),
            speakEn = "EV roadmap $pct percent done. " + (next?.let { "Next: $it." } ?: ""),
            kind = Kind.TASKS,
            items = steps.mapIndexed { i, (s, _) -> "${if (done.has(s)) "✅" else "⬜"} ${i + 1}. $s" } +
                listOf("💡 Kuch seekh liya? Bolo: \"BMS seekh liya\"")
        )
    }
}

// =================================================================== RESUME BUILDER LOG

object ResumeSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has("resume", "cv", "achievement", "portfolio")

    private fun category(s: String): String {
        val t = s.lowercase()
        return when {
            listOf("hackathon", "competition", "baja", "won", "jeeta", "winner", "rank", "prize", "ideathon").any { t.contains(it) } -> "🏆 Competitions"
            listOf("intern", "internship", "training").any { t.contains(it) } -> "💼 Internships"
            listOf("certificate", "certification", "course", "nptel", "coursera", "udemy").any { t.contains(it) } -> "📜 Certifications"
            listOf("project", "bana", "built", "made", "app", "model", "prototype", "esp32").any { t.contains(it) } -> "🛠️ Projects"
            listOf("lead", "head", "coordinator", "volunteer", "club", "team").any { t.contains(it) } -> "🤝 Leadership"
            else -> "⭐ Skills & Others"
        }
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val a = arr(env, "resume")
        val add = Regex("(?:resume|cv|portfolio)\\s*(?:mein|me|main|in)?\\s*(?:add karo|add kar do|daalo|likho|add)\\s*[:\\-]?\\s*(.+)").find(c.norm)?.groupValues?.get(1)
            ?: Regex("^(?:add|likho)\\s+(?:to\\s+)?(?:resume|cv)\\s*[:\\-]?\\s*(.+)").find(c.norm)?.groupValues?.get(1)
        if (add != null && add.isNotBlank()) {
            val text = (if (Txt.hasDevanagari(c.raw)) c.raw else add).trim().replaceFirstChar { it.uppercase() }
            a.put(JSONObject().put("t", text).put("c", category(text)).put("m", System.currentTimeMillis()))
            save(env, "resume", a)
            return c.reply("📄 Resume mein add: ${category(text)} → $text", "📄 Added to resume: ${category(text)} → $text", kind = Kind.SUCCESS, status = "verified")
        }
        if (a.length() == 0) {
            return c.reply(
                "📄 Resume log khaali hai. Har achievement turant bolo: \"Resume mein add karo: AWS Ideathon mein CATTLEΨIC pitch kiya\"",
                "📄 Resume log is empty. Say: \"Add to resume: …\"",
                kind = Kind.INFO
            )
        }
        val fmt = SimpleDateFormat("MMM yyyy", Locale.US)
        val grouped = list(a).groupBy { it.optString("c") }
        val lines = ArrayList<String>()
        grouped.forEach { (cat, items) ->
            lines.add(cat)
            items.forEach { lines.add("   • ${it.optString("t")} (${fmt.format(Date(it.optLong("m")))})") }
        }
        return c.reply(
            "📄 Resume points • ${a.length()} entries", "📄 Resume points • ${a.length()} entries",
            kind = Kind.FILES, items = lines,
            actions = listOf(ReplyAction(c.t("📄 PDF banao", "📄 Make PDF")) {
                val f = withContext(Dispatchers.IO) { OcrSkill.makePdf(env, listOf("RESUME POINTS — ${env.name}", "") + lines) }
                if (f != null) {
                    FileSkill.openFile(env, f)
                    c.reply("📄 Resume PDF: ${f.name}", "📄 Resume PDF: ${f.name}", kind = Kind.FILES, status = "verified")
                } else c.reply("PDF nahi bani", "PDF failed", kind = Kind.ERROR)
            })
        )
    }
}

// =================================================================== EV CONCEPT OF THE DAY

object ConceptSkill : Skill {
    private val concepts = listOf(
        "SOC vs SOH" to "SOC (State of Charge) = abhi battery kitni bhari hai (%). SOH (State of Health) = battery ki capacity naye ke mukable kitni bachi hai. 80% SOH ke neeche EV battery 'end of life' maani jaati hai.",
        "C-rate" to "C-rate = current / capacity. 50 Ah battery 50 A pe = 1C (1 ghante mein khaali), 25 A = 0.5C. Zyada C-rate = zyada garmi, kam life.",
        "LFP vs NMC" to "LFP: safe, sasti, lambi life (3000+ cycles), kam energy density. NMC: zyada energy density (zyada range), mehngi, thermal risk zyada. India ke 2-wheelers mein dono use hote hain.",
        "Regenerative braking" to "Brake lagane pe motor generator ban jaati hai aur gaadi ki kinetic energy ko battery mein wapas bhejti hai. City driving mein range 10-20% tak badh sakti hai.",
        "BLDC vs PMSM" to "Dono permanent magnet motors hain. BLDC: trapezoidal back-EMF, simple control, sasta (e-scooters). PMSM: sinusoidal, FOC control, smooth aur efficient (cars).",
        "Thermal runaway" to "Cell ka temperature badhne se chemical reaction aur garmi paida karti hai — chain reaction, aag. Isse bachane ke liye BMS, cooling aur cell spacing zaroori hai.",
        "Cell balancing" to "Pack ke cells ka voltage barabar rakhna. Passive: zyada voltage wale cell se resistor mein energy jalana. Active: energy ek cell se doosre mein shift karna (efficient, mehnga).",
        "Wh/km" to "EV ki 'mileage'. Energy (Wh) per km. 2-wheeler ~25-40 Wh/km, car ~120-180 Wh/km. Range = Battery Wh / (Wh/km).",
        "Torque-speed curve" to "EV motor zero speed pe hi poora torque deti hai (isliye fast pickup). Base speed ke baad power constant aur torque kam hota jaata hai.",
        "Kirchhoff in battery packs" to "Series mein cells → voltage judta hai (13S = 13×3.7 ≈ 48V). Parallel mein → capacity (Ah) judti hai. Pack ka naam jaise 13S4P.",
        "Charging levels" to "AC slow charging (onboard charger, 3.3-7 kW) vs DC fast charging (charger bahar, 25-150+ kW, seedha battery mein). Fast charging se battery zyada garam hoti hai.",
        "Vehicle dynamics forces" to "EV ko 3 resistance haraani padti hai: rolling resistance (tyre), aerodynamic drag (speed² ke saath badhta hai) aur gradient (chadhai). Inse motor power nikalte hain.",
        "Motor efficiency map" to "Motor har speed-torque point pe alag efficiency deti hai (efficiency map). Achha design gaadi ko zyada time high-efficiency zone mein chalata hai.",
        "Second-life batteries" to "70-80% SOH wali EV batteries ko solar storage / inverter mein dobara use karna. Kam cost, kam e-waste — research aur startup ka bada area."
    )

    override fun matches(c: Cmd, env: Env) = c.has("concept of the day", "aaj ka concept", "ev concept", "ev sikhao", "kuch naya sikhao", "ev fact", "daily concept")

    fun show(c: Cmd, idx: Int): Reply {
        val (title, body) = concepts[((idx % concepts.size) + concepts.size) % concepts.size]
        return c.reply(
            "⚡ EV Concept: $title\n\n$body", "⚡ EV Concept: $title\n\n$body",
            speakHi = "Aaj ka EV concept: $title. $body", speakEn = "EV concept: $title. $body",
            kind = Kind.INFO,
            actions = listOf(ReplyAction(c.t("➡️ Aur ek", "➡️ Another")) { show(c, idx + 1) })
        )
    }

    override suspend fun run(c: Cmd, env: Env): Reply = show(c, Calendar.getInstance().get(Calendar.DAY_OF_YEAR))
}

// =================================================================== DOUBT NOTEBOOK

object DoubtSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has("doubt", "doubts", "shanka", "sawal note")

    override suspend fun run(c: Cmd, env: Env): Reply {
        val a = arr(env, "doubts")
        val add = Regex("(?:doubt|doubts|shanka|sawal)\\s*(?:note karo|note kar lo|likho|add karo|hai|:|-)\\s*[:\\-]?\\s*(.+)").find(c.norm)?.groupValues?.get(1)
        if (c.has("clear", "solve", "samajh aa gaya", "ho gaya")) {
            val open = list(a).lastOrNull { !it.optBoolean("ok") }
            open?.put("ok", true)
            save(env, "doubts", a)
            return c.reply("✅ Doubt clear: ${open?.optString("t") ?: "-"}", "✅ Doubt cleared", kind = Kind.SUCCESS)
        }
        if (add != null && add.length > 3 && !c.has("dikhao", "batao", "list", "show")) {
            val subj = Subjects.detect(c.s) ?: "General"
            val text = if (Txt.hasDevanagari(c.raw)) c.raw else add
            a.put(JSONObject().put("t", text).put("s", subj).put("m", System.currentTimeMillis()).put("ok", false))
            save(env, "doubts", a)
            return c.reply("❓ Doubt note ($subj): $text — teacher se poochna mat bhoolna!", "❓ Doubt saved ($subj): $text", kind = Kind.SUCCESS, status = "verified")
        }
        val open = list(a).filter { !it.optBoolean("ok") }
        if (open.isEmpty()) return c.reply("🎉 Koi pending doubt nahi! Naya: \"Doubt note karo: Bernoulli ka derivation\"", "🎉 No pending doubts!", kind = Kind.INFO)
        return c.reply(
            "❓ ${open.size} doubts pending — kal class mein poochna", "❓ ${open.size} pending doubts",
            kind = Kind.TASKS, items = open.map { "• [${it.optString("s")}] ${it.optString("t")}" },
            actions = listOf(ReplyAction(c.t("✅ Last wala clear", "✅ Clear last")) {
                val l = list(a).lastOrNull { !it.optBoolean("ok") }
                l?.put("ok", true)
                save(env, "doubts", a)
                c.reply("✅ Clear: ${l?.optString("t") ?: "-"}", "✅ Cleared", kind = Kind.SUCCESS)
            })
        )
    }
}

// =================================================================== SPACED REPETITION FLASHCARDS (Leitner boxes)

object RevisionSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has("revision", "revise", "flashcard", "flashcards", "yaad karao", "ratta")

    private val gaps = longArrayOf(0, 1, 3, 7, 16, 35) // days per box

    fun next(c: Cmd, env: Env): Reply {
        val boxes = obj(env, "srs")
        val now = System.currentTimeMillis()
        val bank = FormulaSkill.bank
        val subj = Subjects.detect(c.s)
        val pool = bank.filter { f -> subj == null || f.keys.any { Subjects.map[subj]?.contains(it) == true } || subj == "EV" && f.name.contains("EV") }.ifEmpty { bank }
        val due = pool.filter { f ->
            val o = boxes.optJSONObject(f.name)
            o == null || o.optLong("due") <= now
        }
        val card = (due.ifEmpty { pool }).minByOrNull { boxes.optJSONObject(it.name)?.optInt("box") ?: 0 } ?: return c.reply("Koi card nahi", "No cards")
        val dueCount = due.size
        return c.reply(
            "🃏 Revision ($dueCount due): ${card.name} ka formula kya hai?",
            "🃏 Revision ($dueCount due): What is the formula for ${card.name}?",
            speakHi = "${card.name} ka formula batao, phir answer dekho.", speakEn = "Recall the formula for ${card.name}.",
            kind = Kind.INFO,
            actions = listOf(
                ReplyAction(c.t("👀 Answer dikhao", "👀 Show answer")) {
                    c.reply(
                        "📐 ${card.name}: ${card.formula}" + if (card.note.isNotBlank()) "\n💡 ${card.note}" else "",
                        "📐 ${card.name}: ${card.formula}",
                        kind = Kind.INFO,
                        actions = listOf(
                            ReplyAction(c.t("✅ Yaad tha", "✅ Knew it")) { grade(c, env, card.name, true) },
                            ReplyAction(c.t("❌ Bhool gaya", "❌ Forgot")) { grade(c, env, card.name, false) }
                        )
                    )
                }
            )
        )
    }

    private fun grade(c: Cmd, env: Env, name: String, ok: Boolean): Reply {
        val boxes = obj(env, "srs")
        val o = boxes.optJSONObject(name) ?: JSONObject()
        val box = if (ok) (o.optInt("box") + 1).coerceAtMost(gaps.size - 1) else 0
        o.put("box", box).put("due", System.currentTimeMillis() + gaps[box] * 86400_000L)
        boxes.put(name, o)
        save(env, "srs", boxes)
        val r = next(c, env)
        return r.copy(text = (if (ok) "👍 Agli revision ${gaps[box]} din baad.\n\n" else "🔁 Koi baat nahi, aaj phir aayega.\n\n") + r.text)
    }

    override suspend fun run(c: Cmd, env: Env): Reply = next(c, env)
}

// =================================================================== EV COMPETITIONS & OPPORTUNITIES

object OpportunitySkill : Skill {
    private val list = listOf(
        "🏎️ SAE India e-BAJA — off-road electric vehicle design, build & race (team event)",
        "🏁 Formula Bharat (EV class) — Formula-style student race car",
        "☀️ ISIE India ESVC — Electric Solar Vehicle Championship",
        "⛽ Shell Eco-marathon — ultra energy-efficient vehicle challenge",
        "💡 Smart India Hackathon — govt problem statements (hardware + software)",
        "🧪 NPTEL courses — EV, power electronics, batteries (certificate for resume)",
        "🏭 Internships — EV OEMs & battery startups (LinkedIn / Internshala pe search)",
        "📝 GATE ME — PSU + M.Tech; 1st year se basics strong rakho"
    )

    override fun matches(c: Cmd, env: Env) = c.has("competition", "competitions", "opportunity", "opportunities", "hackathon list", "internship kahan", "ev events")

    override suspend fun run(c: Cmd, env: Env): Reply = c.reply(
        "🚀 EV student ke liye top opportunities", "🚀 Top opportunities for an EV student",
        speakHi = "EV student ke liye sabse achhe mauke: SAE e-BAJA, Formula Bharat, Electric Solar Vehicle Championship, Shell Eco-marathon aur Smart India Hackathon. Deadline yaad dilane ke liye reminder bol dena.",
        speakEn = "Top opportunities: SAE e-BAJA, Formula Bharat, ESVC, Shell Eco-marathon and Smart India Hackathon.",
        kind = Kind.INFO,
        items = list + listOf("⏰ Deadline pata chale to bolo: \"15 november ko yaad dilana e-BAJA registration\"", "🔎 Exact dates official websites pe check karna")
    )
}
