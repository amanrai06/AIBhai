package com.aibhai.app.skills

import android.content.Intent
import android.net.Uri
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.PcBrain
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Txt
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 📕 Galti Diary — record today's mistake, get how top performers avoid it,
 * add your own solution + pledge, track repeats and "clean streak" days.
 */
object MistakeSkill : Skill {
    private val recordCue = Regex(
        "\\b(galti|galtiyan|galati|mistake|mistakes|bhool|bhul|chuk|chook)\\b"
    )
    private val solutionCue = Regex("^(?:iska |is galti ka |meri galti ka )?(?:solution|solusan|hal|upay|fix|ilaaj|ilaj)\\b\\s*(?:hai|ye hai|yeh hai|:|-)?\\s*(.+)$")
    private val listCue = arrayOf("galti diary", "meri galtiyan", "galtiyan batao", "mistakes batao", "my mistakes", "mistake list", "galti list", "galti report")
    private val repeatCue = arrayOf("phir se", "fir se", "dobara", "again", "repeat", "phir ho gayi", "fir ho gayi", "phir kar di")

    private val dateFmt = SimpleDateFormat("d MMM yyyy", Locale.US)

    data class Tip(val keys: List<String>, val icon: String, val title: String, val advice: List<String>, val habit: String)

    /** Offline "what top performers do" library — principles, not invented quotes. */
    private val library = listOf(
        Tip(listOf("late uth", "der se uth", "jaldi nahi uth", "neend", "overslept", "late utha", "subah late", "alarm band", "snooze", "der se utha"), "⏰", "Late uthna",
            listOf("Top performers raat ka 'shutdown time' fix rakhte hain — sone se 1 ghanta pehle screen off.",
                "Alarm phone ko bistar se door rakho, taaki uthna hi pade (snooze ka option khatam).",
                "Uthte hi 2 minute ka fixed kaam (paani + khidki kholna) — din ka pehla jeet."),
            "Kal raat 11 baje phone charging pe doosre kamre mein"),
        Tip(listOf("phone", "mobile", "reels", "instagram", "youtube", "scroll", "social media", "screen time", "shorts"), "📱", "Phone / reels mein time waste",
            listOf("High performers distraction ko 'mushkil' bana dete hain: apps ko home screen se hata do, notifications off.",
                "Deep Work rule (Cal Newport): padhai ke time phone doosre kamre mein.",
                "Reels ke liye fixed 'reward slot' rakho — kaam ke BAAD 15 min, pehle nahi."),
            "Padhai ke 2 ghante phone doosre kamre mein"),
        Tip(listOf("padhai nahi", "padha nahi", "study nahi", "procrast", "taal", "baad mein", "kal karunga", "lazy", "aalas", "aalsi", "assignment late", "time pe nahi"), "📚", "Kaam taalna (procrastination)",
            listOf("2-minute rule (Atomic Habits, James Clear): kaam ko itna chhota karo ki shuru karna 2 minute ka lage.",
                "Pomodoro: 25 min focus + 5 min break. Toppers bade kaam ko tukdon mein todte hain.",
                "Kal ka sabse mushkil kaam aaj raat hi likh lo — subah decide karne mein energy waste nahi hoti."),
            "Roz pehla Pomodoro sabse mushkil subject ka"),
        Tip(listOf("gussa", "anger", "chillaya", "ladai", "jhagda", "bura bola", "rude"), "😤", "Gussa / bura bolna",
            listOf("Emotionally strong log 'pause rule' follow karte hain: react karne se pehle 10 saans.",
                "Gussa aaye to jagah badlo — paani piyo, 5 minute walk.",
                "Baad mein seedha sorry — galti maanna strength hai, weakness nahi."),
            "Gussa aaye to 10 saans, phir jawab"),
        Tip(listOf("paise", "kharcha", "spend", "udhar", "faltu kharch", "shopping", "money"), "💸", "Faltu kharcha",
            listOf("Smart log '24-ghante rule' rakhte hain: koi bhi non-zaroori cheez kal tak ruk ke kharido.",
                "Kharcha likho — jo naapa jaata hai wahi control hota hai.",
                "Pehle bachao, phir kharcho: paisa aate hi ek fixed hissa alag."),
            "Har kharcha AIBhai ko bolke note"),
        Tip(listOf("class miss", "bunk", "lecture miss", "absent", "college nahi"), "🎓", "Class miss karna",
            listOf("Toppers attendance ko 'non-negotiable' maante hain — decision subah nahi, pehle se fixed.",
                "Bag aur kapde raat ko ready — subah ka friction khatam.",
                "Attendance track karo (AIBhai: 'attendance batao') — number dekh ke motivation milta hai."),
            "Raat ko bag ready, subah sirf nikalna"),
        Tip(listOf("junk", "fast food", "maggi", "cold drink", "zyada khaya", "khana", "diet", "meetha", "sugar"), "🍔", "Junk food / bura khana",
            listOf("Fit log ghar mein junk rakhte hi nahi — jo dikhta hai wahi khaya jaata hai.",
                "Bhookh lagne se pehle healthy option ready (fal, chana, dahi).",
                "80/20 rule: perfect nahi, consistent bano."),
            "Kamre mein ek healthy snack ready"),
        Tip(listOf("jhooth", "jhoot", "lie", "lied"), "🤥", "Jhooth bolna",
            listOf("Bharosemand log 'chhota sach, bada respect' follow karte hain — sach turant bolo, baad mein nahi.",
                "Jhooth se bachne ka sabse aasaan tareeka: kam promise karo, zyada deliver karo."),
            "Aaj ek mushkil sach seedha bolunga"),
        Tip(listOf("overthink", "tension", "stress", "darr", "chinta", "nervous"), "🧠", "Overthinking / tension",
            listOf("Calm log 'likh ke nikaalo' karte hain: 5 minute jo dimag mein hai sab kaagaz pe.",
                "Control vs no-control list: sirf control wali cheezon pe action.",
                "Chhota physical action (walk, paani, saans) dimag ko reset karta hai."),
            "Raat ko 5 min 'brain dump' likhna"),
        Tip(listOf("paani", "water", "exercise", "gym", "workout", "walk nahi"), "💪", "Health routine miss",
            listOf("Fit log habit ko existing routine se jodte hain (habit stacking): brush ke baad 10 pushups.",
                "Kam se shuru karo: 1 din bhi miss ho to 'do din lagatar miss nahi' rule."),
            "Brush ke baad 10 pushups"),
        Tip(listOf("bhool gaya", "bhul gaya", "yaad nahi", "forgot", "bhoola"), "📝", "Cheezein bhoolna",
            listOf("Organized log dimag pe bharosa nahi karte — sab likhte hain.",
                "Turant AIBhai ko bolo: 'yaad dilana…' ya 'aaj mujhe … karna hai'.",
                "Raat ko 2 minute: kal ki list."),
            "Har kaam turant AIBhai mein note"),
        Tip(listOf("sorry nahi", "maafi", "dost", "friend", "parents", "mummy", "papa", "family"), "❤️", "Rishton mein galti",
            listOf("Samajhdaar log jaldi maafi maangte hain aur behavior badal ke dikhate hain.",
                "Pehle suno, phir bolo — dusre ki baat repeat karke confirm karo."),
            "Aaj hi ek sachchi sorry")
    )

    private val generic = Tip(emptyList(), "🌱", "Galti se seekhna",
        listOf("Top performers galti ko 'data' maante hain, shame nahi: kya hua → kyun hua → agli baar kya alag.",
            "Ek galti = ek chhota system badlav (environment change > willpower).",
            "Roz shaam 2 minute review — yahi compounding hai."),
        "Roz raat 2 min review")

    private fun load(env: Env): JSONArray = try {
        JSONArray(env.ctx.getSharedPreferences("aibhai", 0).getString("mistakes", "[]"))
    } catch (e: Exception) {
        JSONArray()
    }

    private fun save(env: Env, a: JSONArray) {
        env.ctx.getSharedPreferences("aibhai", 0).edit().putString("mistakes", a.toString()).apply()
    }

    fun all(env: Env): List<JSONObject> {
        val a = load(env)
        return (0 until a.length()).map { a.getJSONObject(it) }
    }

    override fun matches(c: Cmd, env: Env): Boolean {
        if (c.has(*listCue)) return true
        if (solutionCue.containsMatchIn(c.norm) && load(env).length() > 0) return true
        return recordCue.containsMatchIn(c.norm)
    }

    private fun tipFor(text: String): Tip {
        val s = Txt.simplify(Txt.normalize(text))
        return library.maxByOrNull { t -> t.keys.count { Txt.has(s, it) } }?.takeIf { t -> t.keys.any { Txt.has(s, it) } } ?: generic
    }

    private fun cleanMistake(n: String): String {
        var t = " $n "
        listOf(
            "aaj ki galti", "aaj meri galti", "meri aaj ki galti", "aaj maine galti ki", "maine galti ki", "meri galti", "aaj galti",
            "galti ye hai", "galti hai", "galti thi", "galti", "mistake", "my mistake today", "today i made a mistake", "i made a mistake",
            "ki ki", "record karo", "note karo", "likh lo", "bhai", "aaj", "ye hai", "yeh hai"
        ).forEach { t = t.replace(" $it ", " ") }
        return t.replace(Regex("^[\\s:,-]+|[\\s:,-]+$"), "").replace(Regex("\\s+"), " ").trim()
    }

    private fun daysSince(ts: Long): Int = ((System.currentTimeMillis() - ts) / 86400_000L).toInt()

    override suspend fun run(c: Cmd, env: Env): Reply {
        val a = load(env)

        // ---- list / report
        if (c.has(*listCue)) {
            if (a.length() == 0) {
                return c.reply(
                    "📕 Galti Diary abhi khaali hai. Bolo: \"Aaj ki galti: der se utha\"",
                    "📕 Your mistake diary is empty. Say: \"Today's mistake: woke up late\"",
                    kind = Kind.INFO
                )
            }
            val items = (0 until a.length()).map { a.getJSONObject(it) }.reversed().take(10).map { o ->
                val rep = o.optInt("count", 1)
                val last = o.optLong("last", o.optLong("time"))
                val clean = daysSince(last)
                "${o.optString("icon", "📌")} ${o.optString("text")}" +
                    (if (rep > 1) "  • 🔁 ${rep}x" else "") +
                    "  • ✨ $clean din clean" +
                    (if (o.optString("solution").isNotBlank()) "\n     ✅ ${o.optString("solution")}" else "\n     ⚠️ Solution abhi baaki")
            }
            val best = (0 until a.length()).map { a.getJSONObject(it) }.maxByOrNull { daysSince(it.optLong("last", it.optLong("time"))) }
            return c.reply(
                "📕 Galti Diary • ${a.length()} entries",
                "📕 Mistake Diary • ${a.length()} entries",
                speakHi = "Aapki diary mein ${a.length()} galtiyan hain." + (best?.let { " Sabse lamba clean streak: ${daysSince(it.optLong("last", it.optLong("time")))} din, ${it.optString("text")}." } ?: ""),
                speakEn = "You have ${a.length()} entries in your diary.",
                kind = Kind.TASKS, items = items
            )
        }

        // ---- add solution to the latest mistake
        val sol = solutionCue.find(c.norm)?.groupValues?.get(1)?.trim()
        if (sol != null && sol.isNotBlank() && a.length() > 0 && !c.has("aaj ki galti", "maine galti")) {
            val o = a.getJSONObject(a.length() - 1)
            val nice = sol.replaceFirstChar { it.uppercase() }
            o.put("solution", nice)
            save(env, a)
            return c.reply(
                "✅ Solution save ho gaya!\n\n📌 ${o.optString("text")}\n🛠️ $nice\n\n🤝 Pledge: Aaj ke baad ye galti nahi! Main roz subah yaad dilaunga 💪",
                "✅ Solution saved!\n\n📌 ${o.optString("text")}\n🛠️ $nice\n\n🤝 Pledge: Never again! I'll remind you every morning 💪",
                speakHi = "Solution save ho gaya. Pledge le liya: aaj ke baad ye galti nahi. Main roz subah yaad dilaunga.",
                speakEn = "Solution saved. Pledge taken. I'll remind you every morning.",
                kind = Kind.SUCCESS, status = "verified"
            )
        }

        // ---- record (or repeat) a mistake
        val text = cleanMistake(c.norm)
        if (text.length < 3) {
            return c.reply(
                "📕 Kaunsi galti hui? Poora bolo, jaise: \"Aaj ki galti: 2 ghante reels dekhi\"",
                "📕 What was the mistake? e.g. \"Today's mistake: watched reels for 2 hours\"",
                kind = Kind.WARN, status = "needs_input"
            )
        }
        val pretty = text.replaceFirstChar { it.uppercase() }
        val tip = tipFor(text)
        // repeat detection: same category or similar words
        val key = Txt.simplify(text)
        var existing: JSONObject? = null
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val sameCat = tip !== generic && o.optString("cat") == tip.title
            val ok = Txt.simplify(o.optString("text"))
            val words = key.split(' ').filter { it.length >= 4 }
            val overlap = words.count { w -> ok.split(' ').any { Txt.tokenMatch(it, w) } }
            if (sameCat || (words.isNotEmpty() && overlap.toDouble() / words.size >= 0.6)) existing = o
        }
        val now = System.currentTimeMillis()
        val isRepeat = existing != null
        val entry = existing ?: JSONObject().put("text", pretty).put("time", now).put("count", 0).put("cat", tip.title).put("icon", tip.icon)
        val prevClean = if (isRepeat) daysSince(entry.optLong("last", entry.optLong("time"))) else 0
        entry.put("count", entry.optInt("count", 0) + 1).put("last", now)
        if (!isRepeat) a.put(entry)
        save(env, a)

        val head = StringBuilder()
        head.append("📕 Galti Diary • ${dateFmt.format(Date())}\n\n")
        head.append("${tip.icon} Galti: $pretty\n")
        if (isRepeat) head.append("🔁 Ye ${entry.optInt("count")} baar ho chuki hai (pichli baar $prevClean din pehle)\n")
        head.append("\n💡 Top performers kya karte hain:\n")
        val items = ArrayList<String>()
        tip.advice.forEachIndexed { i, s -> items.add("${i + 1}️⃣ $s") }
        items.add("🎯 Aaj ka chhota step: ${tip.habit}")
        val existingSol = entry.optString("solution")
        if (existingSol.isNotBlank()) items.add("🛠️ Aapka solution: $existingSol")

        // Optional: smarter personalised advice from PC brain (free, local)
        val ai = PcBrain.ask(
            env.prefs,
            "Meri galti: '$pretty'. Duniya ke top performers is galti se kaise bachte hain? 3 chhote practical steps do, Hinglish mein, emojis ke saath.",
            "hi"
        )
        if (ai != null) items.add("🤖 PC Brain: ${Txt.short(ai, 400)}")

        val askSol = existingSol.isBlank()
        val tail = if (askSol) "\n✍️ Ab aap apna solution bolo: \"Solution: …\"" else "\n💪 Apna solution yaad rakho — aaj se pakka!"
        return c.reply(
            head.toString().trimEnd() + tail,
            "📕 Mistake Diary • ${dateFmt.format(Date())}\n\n${tip.icon} Mistake: $pretty" +
                (if (isRepeat) "\n🔁 Happened ${entry.optInt("count")} times" else "") +
                (if (askSol) "\n✍️ Now say your fix: \"Solution: …\"" else ""),
            speakHi = (if (isRepeat) "Arre, ye galti phir ho gayi, ${entry.optInt("count")} baar. Koi baat nahi, seekhte hain. " else "Galti diary mein likh li. ") +
                "Top performers ka tareeka: ${tip.advice.first()} " + (if (askSol) "Ab aap apna solution bolo." else "Apna solution yaad rakho."),
            speakEn = "Noted in your mistake diary. Tip: ${tip.advice.first()} " + (if (askSol) "Now tell me your solution." else ""),
            kind = if (isRepeat) Kind.WARN else Kind.TASKS,
            items = items,
            status = if (askSol) "needs_input" else "ok",
            actions = listOf(
                ReplyAction(c.t("🔎 Aur research", "🔎 Research more")) {
                    val q = "how successful people avoid $text habit"
                    env.launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
                    null
                },
                ReplyAction(c.t("📕 Diary dekho", "📕 Open diary")) { run(Cmd("galti diary", "galti diary"), env) }
            )
        )
    }

    /** For morning briefing: active pledges */
    fun pledges(env: Env): List<String> = all(env).filter { it.optString("solution").isNotBlank() }
        .takeLast(3).map { "${it.optString("icon", "📌")} ${it.optString("text")} → ${it.optString("solution")}" }
}
