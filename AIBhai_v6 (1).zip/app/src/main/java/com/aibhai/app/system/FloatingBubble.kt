package com.aibhai.app.system

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.app.NotificationCompat
import com.aibhai.app.AssistActivity
import com.aibhai.app.Prefs
import com.aibhai.app.R
import kotlin.math.abs

/**
 * XRecorder-style draggable floating ball. Tap = open AIBhai & listen.
 * Drag = move anywhere. Toggle on/off from Settings. Foreground service so
 * Vivo doesn't kill it; survives reboots via BootReceiver.
 */
class FloatingBubble : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private lateinit var lp: WindowManager.LayoutParams

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(42, notif())
        if (!canDraw(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            Prefs(this).bubble = false
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    private fun addBubble() {
        if (bubble != null) return
        val size = (56 * resources.displayMetrics.density).toInt()
        val iv = ImageView(this).apply {
            setImageResource(R.mipmap.ic_launcher)
            val pad = (4 * resources.displayMetrics.density).toInt()
            setPadding(pad, pad, pad, pad)
        }
        val container = FrameLayout(this).apply { addView(iv, FrameLayout.LayoutParams(size, size)) }
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE
        lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = Prefs(this@FloatingBubble).bubbleX.takeIf { it >= 0 } ?: (resources.displayMetrics.widthPixels - size - 24)
            y = Prefs(this@FloatingBubble).bubbleY.takeIf { it >= 0 } ?: (resources.displayMetrics.heightPixels / 3)
        }
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        var downTime = 0L
        container.setOnTouchListener { v, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y; touchX = e.rawX; touchY = e.rawY
                    downTime = System.currentTimeMillis()
                    v.animate().scaleX(0.85f).scaleY(0.85f).setDuration(100).start()
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startY + (e.rawY - touchY).toInt()
                    try { wm.updateViewLayout(container, lp) } catch (ex: Exception) {}
                    true
                }
                MotionEvent.ACTION_UP -> {
                    v.animate().scaleX(1f).scaleY(1f).setInterpolator(OvershootInterpolator()).setDuration(200).start()
                    val moved = abs(e.rawX - touchX) > 20 || abs(e.rawY - touchY) > 20
                    if (!moved && System.currentTimeMillis() - downTime < 400) {
                        openAssistant()
                    } else {
                        // snap to nearest edge
                        val screenW = resources.displayMetrics.widthPixels
                        lp.x = if (lp.x + size / 2 < screenW / 2) 8 else screenW - size - 8
                        try { wm.updateViewLayout(container, lp) } catch (ex: Exception) {}
                        Prefs(this).bubbleX = lp.x
                        Prefs(this).bubbleY = lp.y
                    }
                    true
                }
                else -> false
            }
        }
        try {
            wm.addView(container, lp)
            bubble = container
        } catch (e: Exception) {
            stopSelf()
        }
    }

    private fun openAssistant() {
        try {
            startActivity(
                Intent(this, AssistActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    .putExtra("listen", true)
            )
        } catch (e: Exception) {
        }
    }

    private fun notif(): Notification {
        val ch = "aibhai_bubble"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26 && nm?.getNotificationChannel(ch) == null) {
            nm?.createNotificationChannel(NotificationChannel(ch, "AIBhai Floating Button", NotificationManager.IMPORTANCE_MIN))
        }
        val tap = PendingIntent.getActivity(
            this, 0, Intent(this, AssistActivity::class.java).putExtra("listen", true).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stop = PendingIntent.getService(
            this, 1, Intent(this, FloatingBubble::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, ch)
            .setSmallIcon(R.drawable.ic_stat_aibhai)
            .setContentTitle("AIBhai button on")
            .setContentText("Tap karke bolo • button ko kahin bhi khisko sakte ho")
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setContentIntent(tap)
            .addAction(0, "Band karo", stop)
            .build()
    }

    override fun onDestroy() {
        try {
            bubble?.let { wm.removeView(it) }
        } catch (e: Exception) {
        }
        bubble = null
        super.onDestroy()
    }

    companion object {
        fun canDraw(ctx: Context): Boolean = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(ctx)

        fun start(ctx: Context) {
            if (!canDraw(ctx)) return
            val i = Intent(ctx, FloatingBubble::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FloatingBubble::class.java))
        }

        fun openOverlaySettings(ctx: Context) {
            try {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, android.net.Uri.parse("package:" + ctx.packageName))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
            }
        }
    }
}

class BootReceiver : android.content.BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (Prefs(context).bubble && FloatingBubble.canDraw(context)) FloatingBubble.start(context)
    }
}
