package com.aibhai.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aibhai.app.AssistantController
import com.aibhai.app.BuildConfig
import com.aibhai.app.core.ActionLog
import com.aibhai.app.system.Perms
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
private fun Header(title: String, onBack: () -> Unit, right: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Color.White) }
        Text(title, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        right()
    }
}

@Composable
private fun Section(title: String, content: @Composable () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)) {
        Text(title, color = Muted, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 4.dp, bottom = 8.dp))
        Column(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(CardBg)
                .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(20.dp)).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) { content() }
    }
}

@Composable
private fun Field(label: String, initial: String, secret: Boolean = false, hint: String = "", lines: Int = 1, onChange: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    Column {
        Text(label, color = Color.White, fontSize = 13.sp)
        Spacer(Modifier.height(4.dp))
        OutlinedTextField(
            value = v, onValueChange = { v = it; onChange(it) }, singleLine = lines == 1, minLines = lines,
            visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
            keyboardOptions = KeyboardOptions(keyboardType = if (secret) KeyboardType.Password else KeyboardType.Text),
            placeholder = { Text(hint, color = Muted, fontSize = 13.sp) },
            colors = fieldColors(), shape = RoundedCornerShape(14.dp), modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun ToggleRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            Text(sub, color = Muted, fontSize = 12.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange, colors = SwitchDefaults.colors(checkedTrackColor = Rose))
    }
}

@Composable
private fun PermRow(title: String, sub: String, ok: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onClick() }.padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(26.dp).clip(CircleShape).background(if (ok) Mint.copy(alpha = 0.2f) else Amber.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) { Text(if (ok) "✓" else "!", color = if (ok) Mint else Amber, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 14.sp)
            Text(sub, color = Muted, fontSize = 12.sp)
        }
        Text(if (ok) "Done" else "Allow →", color = if (ok) Mint else Rose, fontSize = 13.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun VoiceCard(name: String, desc: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp))
            .background(if (selected) Rose.copy(alpha = 0.15f) else CardBg2)
            .border(1.5.dp, if (selected) Rose else Color.Transparent, RoundedCornerShape(16.dp))
            .clickable { onClick() }.padding(12.dp)
    ) {
        Text(name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Text(desc, color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun SettingsScreen(c: AssistantController, onBack: () -> Unit, onLog: () -> Unit, requestBasics: () -> Unit) {
    val ctx = LocalContext.current
    val p = c.prefs
    val tick = c.tick
    var voice by remember { mutableStateOf(p.voice) }
    var lang by remember { mutableStateOf(p.listenLang) }
    var offline by remember { mutableStateOf(p.preferOffline) }
    var speak by remember { mutableStateOf(p.speakReplies) }
    var refresh by remember { mutableIntStateOf(0) }
    Column(Modifier.fillMaxSize().background(Ink).systemBarsPadding()) {
        Header("Settings", onBack)
        LazyColumn(contentPadding = PaddingValues(bottom = 40.dp)) {
            item {
                Section("AAP") {
                    Field("Aapka naam", p.userName, hint = "jaise Sanjeev") { p.userName = it.trim() }
                }
            }
            item {
                Section("AWAAZ 🎙️  (free • unlimited)") {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        VoiceCard("Adam", "Male • bhaari, calm", voice == "adam", Modifier.weight(1f)) {
                            voice = "adam"; c.setVoice("adam")
                        }
                        VoiceCard("Nidhi", "Female • warm", voice == "nidhi", Modifier.weight(1f)) {
                            voice = "nidhi"; c.setVoice("nidhi")
                        }
                    }
                    Text(
                        "Phone ki Google voice use hoti hai — bilkul free, unlimited, bina internet. Neeche se ${if (voice == "nidhi") "Nidhi" else "Adam"} ke liye best awaaz chuno:",
                        color = Muted, fontSize = 12.sp
                    )
                    val voices = remember(refresh, voice) { c.voice.availableVoices() }
                    var chosen by remember(voice) { mutableStateOf(if (voice == "nidhi") p.nidhiTts else p.adamTts) }
                    if (voices.isEmpty()) {
                        Text("Hindi voice nahi mili. 'Voice data install' dabao → Hindi (India) download karo.", color = Amber, fontSize = 12.sp)
                    }
                    voices.take(12).forEach { v ->
                        val label = (if (v.locale.language == "hi") "Hindi" else "English (IN)") + " • " +
                            v.name.substringAfter("-x-").substringBefore("-").ifBlank { v.name } +
                            if (v.isNetworkConnectionRequired) " • online HD" else " • offline"
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
                                .background(if (chosen == v.name) Rose.copy(alpha = 0.15f) else Color.Transparent)
                                .clickable {
                                    chosen = v.name
                                    if (voice == "nidhi") p.nidhiTts = v.name else p.adamTts = v.name
                                    c.testVoice()
                                }.padding(horizontal = 8.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (chosen == v.name) "●" else "○", color = if (chosen == v.name) Rose else Muted)
                            Spacer(Modifier.width(10.dp))
                            Text(label, color = Color.White, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            Text("▶", color = Muted)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { c.testVoice() }) { Text("▶ Test", color = Rose) }
                        TextButton(onClick = {
                            try {
                                ctx.startActivity(Intent(android.speech.tts.TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            } catch (e: Exception) {
                                ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                            }
                        }) { Text("Voice data install", color = Muted) }
                        TextButton(onClick = { refresh++ }) { Text("Refresh", color = Muted) }
                    }
                    ToggleRow("Jawab bolkar sunao", "Off karoge to sirf screen pe dikhega", speak) {
                        speak = it; p.speakReplies = it
                    }
                    var eleven by remember { mutableStateOf(p.useEleven) }
                    ToggleRow("ElevenLabs premium voice (optional)", "Aur bhi human jaisi, par free plan mein limit hai + internet chahiye", eleven) {
                        eleven = it; p.useEleven = it
                    }
                    if (eleven) {
                        Field("ElevenLabs API key", p.elevenKey, secret = true, hint = "elevenlabs.io → API Keys") { p.elevenKey = it }
                        Field("Adam voice ID", p.adamVoiceId, hint = "pNInz6obpgDQGcFmaJgB") { p.adamVoiceId = it }
                        Field("Nidhi voice ID", p.nidhiVoiceId, hint = "Voice Library → 'Nidhi' → ID copy") { p.nidhiVoiceId = it }
                        val err = remember(refresh) { c.voice.lastError }
                        if (err.isNotBlank()) Text(err, color = Amber, fontSize = 12.sp)
                        Text("Limit khatam ya internet nahi → apne aap free Google voice pe aa jayega.", color = Muted, fontSize = 12.sp)
                    }
                }
            }
            item {
                Section("COLLEGE PORTAL 🎓 (Okie Dokie)") {
                    Field("Portal link", p.portalUrl, hint = "jo link browser mein attendance ke liye kholte ho") { p.portalUrl = it }
                    Field("Roll number", p.rollNo, hint = "jaise 28261212") { p.rollNo = it }
                    Text(
                        "Password save nahi hota. Pehli baar portal khulega → login karo → AIBhai session yaad rakhega. Phir bas bolo: \"Maths ki attendance kitni hai?\" ya \"Overall attendance batao\".",
                        color = Muted, fontSize = 12.sp
                    )
                }
            }
            item {
                Section("STUDY & LIFE TOOLS 📚") {
                    Text("✋ Manual-first: AIBhai sirf aapke bolne pe kaam karta hai. Neeche ke background options default OFF hain — chaho to ON karo.", color = Amber, fontSize = 12.sp, lineHeight = 17.sp)
                    Field(
                        "Timetable (har line: Day Start End Subject Room)", p.timetable, lines = 5,
                        hint = "Mon 9:00 10:00 Maths 204\nMon 10:00 11:00 BEEE 105\nTue 9:00 10:00 EGD Lab"
                    ) {
                        p.timetable = it
                        com.aibhai.app.skills.ClassMode.schedule(ctx)
                    }
                    var silent by remember { mutableStateOf(p.autoSilent) }
                    ToggleRow("Class time pe auto vibrate", "Timetable ke hisaab se", silent) {
                        silent = it; p.autoSilent = it; com.aibhai.app.skills.ClassMode.schedule(ctx)
                    }
                    var bat by remember { mutableStateOf(p.batteryAlerts) }
                    ToggleRow("Battery alerts", "20% pe charge karo, 100% pe charger hatao", bat) {
                        bat = it; p.batteryAlerts = it; com.aibhai.app.skills.BatteryGuard.schedule(ctx)
                    }
                    var calls by remember { mutableStateOf(p.announceCalls) }
                    ToggleRow("Caller ka naam bolo", "Call aaye to AIBhai naam bataye (Notification access chahiye)", calls) {
                        calls = it; p.announceCalls = it
                    }
                    var hf by remember { mutableStateOf(p.handsFree) }
                    ToggleRow("Hands-free baat-cheet", "Jawab ke baad khud sune; 'bas' bolo to ruke", hf) {
                        hf = it; p.handsFree = it
                    }
                    Field("Secret notes PIN", p.secretPin, secret = true, hint = "4-8 digit") { p.secretPin = it.filter { ch -> ch.isDigit() } }
                }
            }
            item {
                Section("FLOATING BUTTON 🫧") {
                    var bub by remember { mutableStateOf(p.bubble) }
                    PermRow("Screen ke upar dikhao (overlay)", "Button kisi bhi app ke upar", FloatingBubble.canDraw(ctx).also { tick }) { FloatingBubble.openOverlaySettings(ctx) }
                    ToggleRow("Floating AIBhai button", "Chhota icon jo kahin bhi khisko; tap = bolo. Band karne ke liye OFF", bub) {
                        if (it && !FloatingBubble.canDraw(ctx)) {
                            FloatingBubble.openOverlaySettings(ctx)
                        } else {
                            bub = it; p.bubble = it
                            if (it) FloatingBubble.start(ctx) else FloatingBubble.stop(ctx)
                        }
                    }
                    Text("💡 Button ko ungli se pakad ke kahin bhi le jao; chhodne pe kinare chipak jaata hai.", color = Muted, fontSize = 12.sp)
                }
            }
            item {
                Section("BATTERY 🍃") {
                    var ecoA by remember { mutableStateOf(p.ecoAuto) }
                    var ecoF by remember { mutableStateOf(p.ecoForce) }
                    ToggleRow("Eco mode (auto)", "Battery saver ON ya 15% se kam pe khud: background news/update band, hands-free band, sirf offline voice", ecoA) {
                        ecoA = it; p.ecoAuto = it
                    }
                    ToggleRow("Eco mode hamesha ON", "Sabse kam battery", ecoF) {
                        ecoF = it; p.ecoForce = it
                    }
                    Text(
                        "AIBhai hamesha mic nahi sunta, background mein koi service nahi chalti, saare kaam Android ke batched alarms se hote hain, aur orb sirf bolte/sunte waqt animate hota hai.",
                        color = Muted, fontSize = 12.sp, lineHeight = 17.sp
                    )
                }
            }
            item {
                Section("SECURITY 🔐") {
                    var bio by remember { mutableStateOf(p.bioForPersonal) }
                    ToggleRow("Personal kaam pe fingerprint/face", "Messages, call, WhatsApp, files, diary, kharcha — 5 min ke liye ek baar", bio) {
                        bio = it; p.bioForPersonal = it
                    }
                    Field("Secret vakya (voice passphrase)", p.passphrase, secret = true, hint = "jaise: Bhai Haryana zindabad 4521") { p.passphrase = it }
                    Text(
                        "🔒 Phone lock ho to AIBhai time, torch, alarm, news jaise safe kaam kar dega; personal kaam ke liye unlock/fingerprint maangega.\n" +
                            "🗣️ Secret vakya bolne se 5 minute ke liye personal features khul jaate hain. Ye awaaz-pehchaan (voiceprint) nahi hai — jo vakya jaanta hai woh bol sakta hai, isliye vakya kisi ko mat batana.\n" +
                            "🚫 3 galat koshish = 5 minute lock + Activity Log mein entry.\n" +
                            "ℹ️ Android kisi bhi app ko awaaz se phone ka screen-lock kholne nahi deta.",
                        color = Muted, fontSize = 12.sp, lineHeight = 17.sp
                    )
                }
            }
            item {
                Section("NEWS 📰") {
                    var alerts by remember { mutableStateOf(p.newsAlerts) }
                    ToggleRow("Roz subah 8 baje EV & Mechanical news (optional)", "Notification mein top updates", alerts) {
                        alerts = it
                        p.newsAlerts = it
                        com.aibhai.app.skills.NewsSkill.scheduleDaily(ctx)
                    }
                    Text("Kabhi bhi bolo: \"Aaj ki news kya hai?\" ya \"EV mein kya naya hai?\"", color = Muted, fontSize = 12.sp)
                }
            }
            item {
                Section("SUNNA 👂") {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        VoiceCard("Hindi / Hinglish", "Haryanvi, Bhojpuri bhi", lang == "hi-IN", Modifier.weight(1f)) {
                            lang = "hi-IN"; p.listenLang = "hi-IN"
                        }
                        VoiceCard("English", "Indian English", lang == "en-IN", Modifier.weight(1f)) {
                            lang = "en-IN"; p.listenLang = "en-IN"
                        }
                    }
                    ToggleRow("Offline sunna", "Bina internet ke (Google app mein Hindi offline pack chahiye)", offline) {
                        offline = it; p.preferOffline = it
                    }
                }
            }
            item {
                Section("PERMISSIONS (Level-3 agent ko full access)") {
                    PermRow("Mic, Contacts, Call, Notifications", "Sunne, call aur reminder ke liye", Perms.mic(ctx) && Perms.contacts(ctx) && Perms.postNotif(ctx).also { tick }) { requestBasics() }
                    PermRow("All files access", "PDF dhundna / move / organize", Perms.files(ctx)) { Perms.openAllFiles(ctx) }
                    PermRow("Notification access", "Important messages batane ke liye", Perms.notifAccess(ctx)) { Perms.openNotifAccess(ctx) }
                    PermRow("Default digital assistant", "Power/home button long-press pe AIBhai", Perms.isAssistant(ctx)) { Perms.openAssistant(ctx) }
                    PermRow("Phone control (Accessibility)", "Kisi bhi app mein tap/scroll/type, screen padhna", com.aibhai.app.skills.PhoneControl.enabled.also { tick }) { com.aibhai.app.skills.PhoneControl.openSettings(ctx) }
                    PermRow("Brightness / rotation control", "Modify system settings", android.provider.Settings.System.canWrite(ctx).also { tick }) {
                        try { ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
                    }
                    PermRow("Install updates", "AIBhai khud naya version install kare", if (android.os.Build.VERSION.SDK_INT >= 26) ctx.packageManager.canRequestPackageInstalls() else true) {
                        try { ctx.startActivity(Intent(android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) {}
                    }
                    PermRow("Battery: unrestricted", "Vivo app ko band na kare", Perms.battery(ctx)) { Perms.openBattery(ctx) }
                    PermRow("Restricted settings (Android 13+)", "Toggle grey ho to: App info → ⋮ → Allow restricted settings", true) { Perms.openAppDetails(ctx) }
                }
            }
            item {
                Section("VIVO TIPS 📱") {
                    Text(
                        "1. Settings → Apps → Default apps → Digital assistant app → AIBhai\n" +
                            "2. Settings → Shortcuts & accessibility → Power button → Digital assistant\n" +
                            "3. Settings → Battery → Background power consumption → AIBhai allow\n" +
                            "4. Recent apps mein AIBhai ko lock 🔒 kar do\n" +
                            "5. Quick Settings mein ✏️ → 'AIBhai' tile add karo",
                        color = Color.White, fontSize = 13.sp, lineHeight = 20.sp
                    )
                }
            }
            item {
                Section("PC BRAIN (optional, free)") {
                    Field("PC ka address", p.pcUrl, hint = "192.168.1.50  (Ollama)") { p.pcUrl = it }
                    Field("Model", p.pcModel, hint = "llama3.1") { p.pcModel = it }
                    Field("Vision model (photo captions)", p.pcVisionModel, hint = "llava") { p.pcVisionModel = it }
                    Text(
                        "PC pe Ollama chalao: OLLAMA_HOST=0.0.0.0. Phir jo AIBhai ko nahi aata, wo PC ka AI jawab dega (same Wi-Fi, bina internet).",
                        color = Muted, fontSize = 12.sp
                    )
                }
            }
            item {
                Section("AGENT") {
                    PermRow("Activity Log", "Har kaam ka record — kya suna, kya kiya, verify hua ya nahi", true) { onLog() }
                    PermRow("Seekhe hue words reset", "Jo 'Sikhao' se sikhaya tha", true) { p.clearLearned() }
                    PermRow("Update check karo", "Version ${BuildConfig.VERSION_NAME} • naya APK GitHub pe", true) {
                        val repo = BuildConfig.REPO_URL
                        val url = if (repo.isNotBlank()) "https://github.com/$repo/releases/latest" else "https://github.com"
                        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                }
            }
        }
    }
}

@Composable
fun LogScreen(c: AssistantController, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var ver by remember { mutableIntStateOf(0) }
    val entries = remember(ver, c.messages.size) { ActionLog.all(ctx) }
    val fmt = remember { SimpleDateFormat("d MMM, h:mm a", Locale.US) }
    Column(Modifier.fillMaxSize().background(Ink).systemBarsPadding()) {
        Header("Activity Log", onBack) {
            TextButton(onClick = { ActionLog.clear(ctx); ver++ }) { Text("Clear", color = Muted) }
        }
        val ok = entries.count { it.status == "ok" || it.status == "verified" || it.status == "approved" }
        Text(
            "${entries.size} actions • $ok successful • ${entries.count { it.status == "verified" }} verified • ${entries.count { it.status == "failed" }} failed",
            color = Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 20.dp)
        )
        LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (entries.isEmpty()) item { Text("Abhi koi action nahi. AIBhai se kuch karwao!", color = Muted) }
            items(entries) { e ->
                val col = when (e.status) {
                    "verified", "approved", "ok" -> Mint
                    "failed" -> Danger
                    "needs_input", "needs_approval" -> Amber
                    else -> Muted
                }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(CardBg).padding(12.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(8.dp).clip(CircleShape).background(col))
                        Spacer(Modifier.width(8.dp))
                        Text(e.skill, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Spacer(Modifier.width(8.dp))
                        Text(e.status.replace('_', ' ').uppercase(), color = col, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.weight(1f))
                        Text(fmt.format(Date(e.time)), color = Muted, fontSize = 11.sp)
                    }
                    if (e.heard.isNotBlank()) Text("🎙️ ${e.heard}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                    Text(e.result, color = Color.White, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
                }
            }
        }
    }
}
