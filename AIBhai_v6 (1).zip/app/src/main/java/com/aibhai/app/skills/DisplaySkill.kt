package com.aibhai.app.skills

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill

/** Direct control: brightness up/down/%, auto-brightness, auto-rotate, screen timeout. */
object DisplaySkill : Skill {
    private fun isBright(c: Cmd) = c.has("brightness", "brightnes", "britness", "roshni", "screen light", "chamak")
    private fun isRotate(c: Cmd) = c.has("auto rotate", "rotation", "rotate", "screen ghumao")
    private fun isTimeout(c: Cmd) = c.has("screen timeout", "sleep time", "screen off time")

    override fun matches(c: Cmd, env: Env): Boolean =
        (isBright(c) || isRotate(c) || isTimeout(c)) && !c.has("setting", "settings")

    private fun canWrite(env: Env) = try {
        Settings.System.canWrite(env.ctx)
    } catch (e: Exception) {
        false
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        if (!canWrite(env)) {
            return c.reply(
                "🔆 Brightness/rotation badalne ke liye ek baar 'Modify system settings' mein AIBhai ko Allow karo, phir dobara bolo.",
                "🔆 Allow AIBhai to 'Modify system settings' once, then ask again.",
                kind = Kind.WARN, status = "needs_input",
                actions = listOf(ReplyAction(c.t("Allow karo", "Allow")) {
                    env.launch(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + env.ctx.packageName)))
                    null
                })
            )
        }
        val cr = env.ctx.contentResolver
        val pct = Regex("(\\d{1,3})\\s*(?:%|percent|pratishat)?").find(c.norm)?.groupValues?.get(1)?.toIntOrNull()?.takeIf { it in 0..100 }
        try {
            when {
                isRotate(c) -> {
                    val on = !c.has("band", "off", "bandh", "lock", "hatao")
                    Settings.System.putInt(cr, Settings.System.ACCELEROMETER_ROTATION, if (on) 1 else 0)
                    val ok = Settings.System.getInt(cr, Settings.System.ACCELEROMETER_ROTATION, -1) == (if (on) 1 else 0)
                    return c.reply(
                        if (on) "🔄 Auto-rotate ON" else "🔒 Auto-rotate OFF",
                        if (on) "🔄 Auto-rotate on" else "🔒 Auto-rotate off",
                        kind = if (ok) Kind.SUCCESS else Kind.ERROR, status = if (ok) "verified" else "failed"
                    )
                }
                isTimeout(c) -> {
                    val sec = TimeSkill.durationSec(TimeSkill.wordsToNum(c.norm)).takeIf { it > 0 } ?: 60L
                    val ms = (sec * 1000).coerceIn(15_000L, 30 * 60_000L).toInt()
                    Settings.System.putInt(cr, Settings.System.SCREEN_OFF_TIMEOUT, ms)
                    return c.reply("⏲️ Screen timeout: ${ms / 1000} second", "⏲️ Screen timeout: ${ms / 1000} seconds", kind = Kind.SUCCESS, status = "verified")
                }
                else -> {
                    if (c.has("auto")) {
                        val on = !c.has("band", "off", "bandh", "hatao")
                        Settings.System.putInt(
                            cr, Settings.System.SCREEN_BRIGHTNESS_MODE,
                            if (on) Settings.System.SCREEN_BRIGHTNESS_MODE_AUTOMATIC else Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
                        )
                        return c.reply(
                            if (on) "🌗 Auto brightness ON" else "🔆 Auto brightness OFF",
                            if (on) "🌗 Auto brightness on" else "🔆 Auto brightness off",
                            kind = Kind.SUCCESS, status = "verified"
                        )
                    }
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS_MODE, Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL)
                    val cur = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, 128)
                    val target = when {
                        pct != null -> (pct * 255 / 100).coerceIn(5, 255)
                        c.has("full", "max", "poori", "puri", "sabse zyada") -> 255
                        c.has("sabse kam", "minimum", "min", "lowest") -> 10
                        c.has("kam", "ghata", "ghatao", "down", "decrease", "dim", "halki", "low", "lower") -> (cur - 64).coerceAtLeast(10)
                        else -> (cur + 64).coerceAtMost(255)
                    }
                    Settings.System.putInt(cr, Settings.System.SCREEN_BRIGHTNESS, target)
                    val now = Settings.System.getInt(cr, Settings.System.SCREEN_BRIGHTNESS, -1)
                    val shown = now * 100 / 255
                    val ok = now == target
                    return c.reply(
                        "🔆 Brightness: $shown%", "🔆 Brightness: $shown%",
                        speakHi = "Brightness $shown percent kar di", speakEn = "Brightness set to $shown percent",
                        kind = if (ok) Kind.SUCCESS else Kind.WARN, status = if (ok) "verified" else "failed"
                    )
                }
            }
        } catch (e: Exception) {
            return c.reply("Ye setting badal nahi payi: ${e.message}", "Couldn't change that: ${e.message}", kind = Kind.ERROR, status = "failed")
        }
    }
}
