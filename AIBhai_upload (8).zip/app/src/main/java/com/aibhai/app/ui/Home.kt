package com.aibhai.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.automirrored.rounded.VolumeUp
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.GraphicEq
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.Keyboard
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.ExperimentalTextApi
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aibhai.app.AssistantController
import com.aibhai.app.ChatItem
import com.aibhai.app.Status
import com.aibhai.app.core.Kind
import com.aibhai.app.core.ReplyAction
import java.util.Calendar

val Ink = Color(0xFF0A0A12)
val CardBg = Color(0xFF15151F)
val CardBg2 = Color(0xFF1F1F2D)
val Muted = Color(0xFF9A9AB2)
val Saffron = Color(0xFFFF8A00)
val Rose = Color(0xFFFF2E63)
val Violet = Color(0xFF7B2FF7)
val Mint = Color(0xFF2EE59D)
val Amber = Color(0xFFFFC145)
val Danger = Color(0xFFFF5470)
val BrandBrush = Brush.linearGradient(listOf(Saffron, Rose, Violet))

private val scheme: ColorScheme = darkColorScheme(
    primary = Rose,
    secondary = Saffron,
    tertiary = Violet,
    background = Ink,
    surface = CardBg,
    surfaceVariant = CardBg2,
    onSurface = Color.White,
    onBackground = Color.White,
    onSurfaceVariant = Muted,
    onPrimary = Color.White
)

@Composable
fun AIBhaiTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun AIBhaiApp(c: AssistantController, requestBasics: () -> Unit) {
    var screen by remember { mutableStateOf("home") }
    var teachFor by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = screen != "home") { screen = "home" }
    when (screen) {
        "settings" -> SettingsScreen(c, onBack = { screen = "home" }, onLog = { screen = "log" }, requestBasics = requestBasics)
        "log" -> LogScreen(c, onBack = { screen = "home" })
        else -> HomeScreen(c, onSettings = { screen = "settings" }, onLog = { screen = "log" }, onTeach = { teachFor = it })
    }
    if (c.pinRequest) PinDialog(onDismiss = { c.pinRequest = false }, onOk = { c.unlockSecret(it) })
    val t = teachFor
    if (t != null) TeachDialog(heard = t, onDismiss = { teachFor = null }, onSave = { h, m ->
        teachFor = null
        c.teach(h, m)
    })
}

@Composable
private fun TeachDialog(heard: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var h by remember { mutableStateOf(heard) }
    var m by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text("🧠 AIBhai ko sikhao", color = Color.White) },
        text = {
            Column {
                Text("Aapne kya bola:", color = Muted, fontSize = 13.sp)
                OutlinedTextField(value = h, onValueChange = { h = it }, singleLine = true, colors = fieldColors(), modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(10.dp))
                Text("Iska matlab kya hai (command):", color = Muted, fontSize = 13.sp)
                OutlinedTextField(
                    value = m, onValueChange = { m = it }, singleLine = true, colors = fieldColors(),
                    placeholder = { Text("jaise: notes kholo", color = Muted) }, modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = { TextButton(onClick = { if (h.isNotBlank() && m.isNotBlank()) onSave(h, m) }) { Text("Sikha do", color = Rose) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Rehne do", color = Muted) } }
    )
}

@Composable
private fun PinDialog(onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var pin by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text("🔒 Secret notes", color = Color.White) },
        text = {
            OutlinedTextField(
                value = pin, onValueChange = { pin = it.filter { ch -> ch.isDigit() }.take(8) }, singleLine = true,
                placeholder = { Text("PIN", color = Muted) },
                visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.NumberPassword),
                colors = fieldColors(), modifier = Modifier.fillMaxWidth()
            )
        },
        confirmButton = { TextButton(onClick = { onOk(pin) }) { Text("Kholo", color = Rose) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Rehne do", color = Muted) } }
    )
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Rose,
    unfocusedBorderColor = CardBg2,
    focusedTextColor = Color.White,
    unfocusedTextColor = Color.White,
    cursorColor = Rose,
    focusedContainerColor = CardBg,
    unfocusedContainerColor = CardBg
)

private fun greetingWord(): String = when (Calendar.getInstance().get(Calendar.HOUR_OF_DAY)) {
    in 4..11 -> "Good morning"
    in 12..16 -> "Good afternoon"
    in 17..21 -> "Good evening"
    else -> "Ram Ram"
}

private val suggestions = listOf(
    Triple("📬", "Aaj ke important messages", "bhai aaj kaun kaun se message aaye"),
    Triple("📝", "Aaj kya karna hai?", "aaj kya karna hai"),
    Triple("🗂️", "Downloads organize karo", "downloads organize karo"),
    Triple("📊", "Attendance status", "attendance batao"),
    Triple("📒", "Notes kholo", "notes kholo"),
    Triple("🔦", "Torch on", "torch on karo"),
    Triple("🧮", "500 N, 20 mm rod ka stress", "500 newton 20 mm diameter rod ka stress"),
    Triple("☀️", "Aaj ka briefing", "good morning"),
    Triple("📰", "Aaj ki news (EV pehle)", "aaj ki news kya hai"),
    Triple("📕", "Galti Diary", "galti diary"),
    Triple("📚", "Agla lecture kaunsa?", "agla lecture kaunsa hai"),
    Triple("🎯", "Focus mode 25 min", "focus mode 25 minute"),
    Triple("❓", "EV quiz lo", "EV quiz lo"),
    Triple("🌙", "Good night", "good night")
)

@OptIn(ExperimentalTextApi::class)
@Composable
fun HomeScreen(c: AssistantController, onSettings: () -> Unit, onLog: () -> Unit, onTeach: (String) -> Unit) {
    val listState = rememberLazyListState()
    var typing by remember { mutableStateOf(false) }
    var input by remember { mutableStateOf("") }
    val haptic = LocalHapticFeedback.current
    LaunchedEffect(c.messages.size) {
        if (c.messages.isNotEmpty()) listState.animateScrollToItem(c.messages.size)
    }
    val send = {
        if (input.isNotBlank()) {
            c.submitText(input.trim())
            input = ""
        }
    }
    Box(Modifier.fillMaxSize().background(Ink)) {
        Box(
            Modifier.fillMaxWidth().height(360.dp)
                .background(Brush.radialGradient(listOf(Violet.copy(alpha = 0.30f), Color.Transparent), radius = 900f))
        )
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            // ---- top bar
            Row(
                Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 10.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("AI", style = TextStyle(brush = BrandBrush, fontSize = 28.sp, fontWeight = FontWeight.Black))
                Text("Bhai", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black)
                Spacer(Modifier.width(10.dp))
                StatusPill(c.status)
                Spacer(Modifier.width(6.dp))
                Text(
                    (if (c.online) "🌐" else "📴") + (if (c.eco) " 🍃" else ""),
                    fontSize = 14.sp,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(CardBg2).padding(horizontal = 8.dp, vertical = 3.dp)
                )
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onLog) { Icon(Icons.Rounded.History, "Log", tint = Muted) }
                IconButton(onClick = onSettings) { Icon(Icons.Rounded.Settings, "Settings", tint = Muted) }
            }
            val missing = c.setupMissing
            if (missing > 0) {
                Row(
                    Modifier.padding(horizontal = 16.dp, vertical = 4.dp).fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp)).background(Amber.copy(alpha = 0.12f))
                        .clickable { onSettings() }.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("⚙️", fontSize = 16.sp)
                    Spacer(Modifier.width(8.dp))
                    Text("Setup baaki hai ($missing) — tap karke permissions do", color = Amber, fontSize = 13.sp)
                }
            }
            // ---- chat
            LazyColumn(
                state = listState,
                modifier = Modifier.weight(1f).fillMaxWidth(),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { if (c.messages.isEmpty()) Welcome(c) else Spacer(Modifier.height(1.dp)) }
                itemsIndexed(c.messages) { _, m ->
                    when (m) {
                        is ChatItem.User -> UserBubble(m.text)
                        is ChatItem.Bot -> BotCard(m, onAction = { c.runAction(it) }, onTeach = { onTeach(m.heard) })
                    }
                }
            }
            // ---- lecture live card
            if (c.lectureOn) {
                Column(
                    Modifier.padding(horizontal = 16.dp, vertical = 6.dp).fillMaxWidth().clip(RoundedCornerShape(18.dp))
                        .background(Rose.copy(alpha = 0.12f)).border(1.dp, Rose.copy(alpha = 0.5f), RoundedCornerShape(18.dp)).padding(14.dp)
                ) {
                    Text("🔴 Lecture recording… ${c.lectureText.split(' ').count { it.isNotBlank() }} words", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    Text(c.lectureText.takeLast(220).ifBlank { "Sun raha hoon…" }, color = Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
                    TextButton(onClick = { c.stopLecture() }) { Text("⏹ Stop & notes banao", color = Rose) }
                }
            }
            // ---- dock
            Column(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                if (c.status == Status.LISTENING && c.partial.isNotBlank()) {
                    Text(
                        "“${c.partial}”", color = Color.White.copy(alpha = 0.9f), fontSize = 17.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
                    )
                }
                if (typing) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = input, onValueChange = { input = it },
                            placeholder = { Text("Type karo… (Hindi / English)", color = Muted) },
                            singleLine = true, modifier = Modifier.weight(1f), shape = RoundedCornerShape(24.dp),
                            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                            keyboardActions = KeyboardActions(onSend = { send() }),
                            colors = fieldColors()
                        )
                        IconButton(onClick = { send() }) { Icon(Icons.AutoMirrored.Rounded.Send, "Send", tint = Rose) }
                        IconButton(onClick = { typing = false }) { Icon(Icons.Rounded.Mic, "Mic", tint = Muted) }
                    }
                } else {
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 32.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        RoundButton(onClick = { typing = true }) { Icon(Icons.Rounded.Keyboard, "Type", tint = Color.White) }
                        Orb(c.status, c.rms) {
                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            c.toggleListening()
                        }
                        RoundButton(onClick = { c.switchVoice() }) {
                            Text(if (c.voiceName == "nidhi") "N" else "A", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                        }
                    }
                    Text(
                        when (c.status) {
                            Status.LISTENING -> "Bolo… (dobara tap = bas)"
                            Status.THINKING -> "Soch raha hoon…"
                            Status.SPEAKING -> "Tap karke beech mein roko"
                            else -> "Tap karke bolo • ${if (c.voiceName == "nidhi") "Nidhi" else "Adam"} voice"
                        },
                        color = Muted, fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusPill(s: Status) {
    val (label, col) = when (s) {
        Status.LISTENING -> Pair("Sun raha hoon", Rose)
        Status.THINKING -> Pair("Soch raha hoon", Amber)
        Status.SPEAKING -> Pair("Bol raha hoon", Violet)
        else -> Pair("Ready", Mint)
    }
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(CardBg2).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(col))
        Spacer(Modifier.width(6.dp))
        Text(label, color = Color.White, fontSize = 11.sp)
    }
}

@Composable
private fun RoundButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(52.dp).clip(CircleShape).background(CardBg2).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
fun Orb(status: Status, rms: Float, onClick: () -> Unit) {
    // Battery: the orb only animates while AIBhai is listening/thinking/speaking.
    val active = status != Status.IDLE
    val target = when (status) {
        Status.LISTENING -> ((rms.coerceIn(-2f, 10f) + 2f) / 12f).coerceIn(0.15f, 1f)
        Status.THINKING -> 0.45f
        Status.SPEAKING -> 0.6f
        else -> 0f
    }
    val level by animateFloatAsState(target, label = "lvl")
    var rot = 0f
    var pulse = 1f
    if (active) {
        val inf = rememberInfiniteTransition(label = "orb")
        val r by inf.animateFloat(0f, 360f, infiniteRepeatable(tween(6000, easing = LinearEasing)), label = "rot")
        val p by inf.animateFloat(0.95f, 1.05f, infiniteRepeatable(tween(1300), RepeatMode.Reverse), label = "pulse")
        rot = r
        pulse = p
    }
    Box(
        Modifier.size(124.dp).clip(CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val rr = size.minDimension / 2f
            drawCircle(
                Brush.radialGradient(listOf(Rose.copy(alpha = 0.18f + 0.4f * level), Color.Transparent), center = center, radius = rr),
                radius = rr
            )
            val core = rr * 0.6f * (1f + 0.22f * level) * pulse
            rotate(rot) {
                drawCircle(Brush.sweepGradient(listOf(Saffron, Rose, Violet, Saffron), center = center), radius = core)
            }
            drawCircle(Color.White.copy(alpha = 0.10f), radius = core * 0.72f)
        }
        Icon(
            when (status) {
                Status.LISTENING -> Icons.Rounded.GraphicEq
                Status.THINKING -> Icons.Rounded.AutoAwesome
                Status.SPEAKING -> Icons.AutoMirrored.Rounded.VolumeUp
                else -> Icons.Rounded.Mic
            },
            contentDescription = "Mic", tint = Color.White, modifier = Modifier.size(36.dp)
        )
    }
}

@Composable
private fun Welcome(c: AssistantController) {
    Column(Modifier.fillMaxWidth().padding(top = 18.dp)) {
        Text("${greetingWord()}, ${c.prefs.userName} 👋", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold, lineHeight = 34.sp)
        Text(
            "Bolo ya type karo — Hindi, Hinglish, English, Haryanvi, Bhojpuri. Main kar dunga.",
            color = Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp)
        )
        Spacer(Modifier.height(18.dp))
        suggestions.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { s ->
                    Column(
                        Modifier.weight(1f).clip(RoundedCornerShape(18.dp)).background(CardBg)
                            .border(1.dp, Color.White.copy(alpha = 0.05f), RoundedCornerShape(18.dp))
                            .clickable { c.submitText(s.third) }.padding(14.dp)
                    ) {
                        Text(s.first, fontSize = 20.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(s.second, color = Color.White, fontSize = 13.sp, lineHeight = 17.sp)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun UserBubble(text: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
        Text(
            text, color = Color.White, fontSize = 15.sp,
            modifier = Modifier.widthIn(max = 300.dp)
                .clip(RoundedCornerShape(20.dp, 4.dp, 20.dp, 20.dp))
                .background(Brush.linearGradient(listOf(Rose.copy(alpha = 0.85f), Violet.copy(alpha = 0.85f))))
                .padding(horizontal = 14.dp, vertical = 10.dp)
        )
    }
}

private fun accent(k: Kind): Color = when (k) {
    Kind.SUCCESS -> Mint
    Kind.WARN -> Amber
    Kind.ERROR -> Danger
    Kind.MESSAGES -> Violet
    Kind.FILES -> Saffron
    Kind.TASKS -> Mint
    Kind.INFO -> Rose
}

@Composable
private fun BotCard(m: ChatItem.Bot, onAction: (ReplyAction) -> Unit, onTeach: () -> Unit) {
    val col = accent(m.reply.kind)
    val shape = RoundedCornerShape(4.dp, 20.dp, 20.dp, 20.dp)
    Row(Modifier.fillMaxWidth()) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(BrandBrush), contentAlignment = Alignment.Center) {
            Text("AI", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.width(10.dp))
        Column(
            Modifier.weight(1f).clip(shape).background(CardBg).border(1.dp, col.copy(alpha = 0.35f), shape).padding(14.dp)
        ) {
            if (m.reply.status == "verified" || m.reply.status == "needs_approval") {
                Text(
                    if (m.reply.status == "verified") "✓ VERIFIED" else "⏸ APPROVAL CHAHIYE",
                    color = if (m.reply.status == "verified") Mint else Amber,
                    fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp)
                )
            }
            Text(m.reply.text, color = Color.White, fontSize = 15.sp, lineHeight = 21.sp)
            m.reply.items.forEach {
                Text(it, color = Muted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 6.dp))
            }
            if (m.reply.actions.isNotEmpty() || m.reply.teachable) {
                Row(
                    Modifier.padding(top = 10.dp).horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    m.reply.actions.forEach { a ->
                        OutlinedButton(
                            onClick = { onAction(a) }, shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, col.copy(alpha = 0.7f)),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) { Text(a.label, color = Color.White, fontSize = 13.sp) }
                    }
                    if (m.reply.teachable) {
                        OutlinedButton(
                            onClick = onTeach, shape = RoundedCornerShape(50),
                            border = BorderStroke(1.dp, Violet.copy(alpha = 0.7f)),
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) { Text("🧠 Sikhao", color = Color.White, fontSize = 13.sp) }
                    }
                }
            }
        }
    }
}
