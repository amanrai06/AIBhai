package com.aibhai.app.skills

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import androidx.activity.ComponentActivity
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Txt
import com.aibhai.app.system.Perms
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.devanagari.DevanagariTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object OcrBridge {
    @Volatile
    var pending: CompletableDeferred<String>? = null
}

/** 📷 Photo → text (offline, Hindi + English) → read aloud / PDF / notes */
object OcrSkill : Skill {
    override fun matches(c: Cmd, env: Env) =
        c.has("photo", "camera", "image", "tasveer", "pic", "picture", "scan", "kamra") &&
            c.has("padho", "read", "text", "likha", "ocr", "samjhao", "pdf", "scan karo", "notes", "nikalo", "padh")

    override suspend fun run(c: Cmd, env: Env): Reply {
        val d = CompletableDeferred<String>()
        OcrBridge.pending = d
        val gallery = c.has("gallery", "galeri", "photos se", "gallery se")
        env.launch(Intent(env.ctx, PhotoActivity::class.java).putExtra("gallery", gallery))
        val text = withTimeoutOrNull(240_000) { d.await() }?.trim().orEmpty()
        OcrBridge.pending = null
        if (text.isBlank()) {
            return c.reply("📷 Photo mein text nahi mila (ya photo cancel hui). Seedha aur roshni mein photo lo.", "📷 No text found (or cancelled). Try a clear, well-lit photo.", kind = Kind.WARN, status = "failed")
        }
        val lines = text.lines().map { it.trim() }.filter { it.isNotBlank() }
        val toPdf = c.has("pdf")
        val pdfReply: suspend () -> Reply = {
            val f = withContext(Dispatchers.IO) { makePdf(env, lines) }
            if (f != null) {
                FileSkill.openFile(env, f)
                c.reply("📄 PDF ban gayi: ${f.name}", "📄 PDF created: ${f.name}", kind = Kind.FILES, status = "verified", items = listOf("📁 ${f.parent}"))
            } else c.reply("PDF nahi ban payi.", "Couldn't create PDF.", kind = Kind.ERROR, status = "failed")
        }
        if (toPdf) return pdfReply()
        return c.reply(
            "📷 Photo se ${lines.size} lines padhi", "📷 Read ${lines.size} lines from the photo",
            speakHi = "Photo mein likha hai: " + Txt.short(lines.joinToString(". "), 260),
            speakEn = "The photo says: " + Txt.short(lines.joinToString(". "), 260),
            kind = Kind.SUCCESS, status = "verified",
            items = lines.take(20) + if (lines.size > 20) listOf("… +${lines.size - 20} lines") else emptyList(),
            actions = listOf(
                ReplyAction(c.t("📄 PDF banao", "📄 Make PDF")) { pdfReply() },
                ReplyAction(c.t("📝 Notes mein save", "📝 Save to notes")) {
                    val f = withContext(Dispatchers.IO) { saveTxt(env, text) }
                    c.reply("📝 Save ho gaya: ${f.name}", "📝 Saved: ${f.name}", kind = Kind.FILES, status = "verified")
                },
                ReplyAction(c.t("📋 Copy", "📋 Copy")) {
                    env.ctx.getSystemService(ClipboardManager::class.java)?.setPrimaryClip(ClipData.newPlainText("AIBhai", text))
                    c.reply("📋 Copy ho gaya", "📋 Copied", kind = Kind.SUCCESS)
                }
            )
        )
    }

    private fun outDir(env: Env, sub: String): File {
        val base = if (Perms.files(env.ctx)) Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS)
        else env.ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: env.ctx.filesDir
        return File(base, "AIBhai/$sub").apply { mkdirs() }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())

    fun saveTxt(env: Env, text: String): File {
        val f = File(outDir(env, "Notes"), "Note_${stamp()}.txt")
        f.writeText(text)
        return f
    }

    fun makePdf(env: Env, lines: List<String>): File? = try {
        val doc = PdfDocument()
        val paint = Paint().apply { textSize = 12f; isAntiAlias = true }
        val w = 595
        val h = 842
        val margin = 40f
        val maxW = w - 2 * margin
        val wrapped = ArrayList<String>()
        for (l in lines) {
            var rest = l
            while (rest.isNotEmpty()) {
                val n = paint.breakText(rest, true, maxW, null).coerceAtLeast(1)
                wrapped.add(rest.substring(0, n))
                rest = rest.substring(n)
            }
        }
        var pageNo = 1
        var i = 0
        while (i < wrapped.size || pageNo == 1) {
            val page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, pageNo).create())
            var y = margin + 12
            if (pageNo == 1) {
                val title = Paint(paint).apply { textSize = 16f; isFakeBoldText = true }
                page.canvas.drawText("AIBhai Scan • ${SimpleDateFormat("d MMM yyyy, h:mm a", Locale.US).format(Date())}", margin, y, title)
                y += 28
            }
            while (i < wrapped.size && y < h - margin) {
                page.canvas.drawText(wrapped[i], margin, y, paint)
                y += 17
                i++
            }
            doc.finishPage(page)
            pageNo++
            if (i >= wrapped.size) break
        }
        val f = File(outDir(env, "Scans"), "Scan_${stamp()}.pdf")
        f.outputStream().use { doc.writeTo(it) }
        doc.close()
        f
    } catch (e: Exception) {
        null
    }
}

class PhotoActivity : ComponentActivity() {
    private var photoUri: Uri? = null
    private var finished = false

    private val takePic = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val u = photoUri
        if (ok && u != null) recognize(u) else done("")
    }
    private val pick = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) recognize(uri) else done("")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState != null) {
            photoUri = savedInstanceState.getString("uri")?.let { Uri.parse(it) }
            return
        }
        try {
            if (intent.getBooleanExtra("gallery", false)) {
                pick.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            } else {
                val f = File(cacheDir, "ocr_${System.currentTimeMillis()}.jpg")
                val u = FileProvider.getUriForFile(this, "$packageName.files", f)
                photoUri = u
                takePic.launch(u)
            }
        } catch (e: Exception) {
            done("")
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        photoUri?.let { outState.putString("uri", it.toString()) }
    }

    private fun recognize(uri: Uri) {
        val img = try {
            InputImage.fromFilePath(this, uri)
        } catch (e: Exception) {
            done("")
            return
        }
        val latin = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        val deva = TextRecognition.getClient(DevanagariTextRecognizerOptions.Builder().build())
        latin.process(img)
            .addOnSuccessListener { r1 ->
                deva.process(img)
                    .addOnSuccessListener { r2 -> done(if (r2.text.length > r1.text.length * 1.2) r2.text else r1.text) }
                    .addOnFailureListener { done(r1.text) }
            }
            .addOnFailureListener {
                deva.process(img).addOnSuccessListener { r2 -> done(r2.text) }.addOnFailureListener { done("") }
            }
    }

    private fun done(text: String) {
        if (finished) return
        finished = true
        OcrBridge.pending?.complete(text)
        finish()
    }

    override fun onDestroy() {
        if (!finished && isFinishing) OcrBridge.pending?.complete("")
        super.onDestroy()
    }
}
