package com.aibhai.app

import android.Manifest
import androidx.activity.ComponentActivity
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.aibhai.app.core.ActionLog
import com.aibhai.app.core.Brain
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Txt
import com.aibhai.app.system.Perms
import com.aibhai.app.voice.SpeechInput
import com.aibhai.app.voice.VoiceOutput
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

enum class Status { IDLE, LISTENING, THINKING, SPEAKING }

sealed class ChatItem {
    data class User(val text: String) : ChatItem()
    data class Bot(val reply: Reply, val heard: String) : ChatItem()
}

class AssistantController(
    private val activity: ComponentActivity,
    val prefs: Prefs,
    private val askPerms: (Array<String>) -> Unit
) : SpeechInput.Callback {
    val messages = mutableStateListOf<ChatItem>()
    var status by mutableStateOf(Status.IDLE)
        private set
    var rms by mutableFloatStateOf(0f)
        private set
    var partial by mutableStateOf("")
        private set
    var tick by mutableIntStateOf(0)
    var voiceName by mutableStateOf(prefs.voice)
        private set
    var online by mutableStateOf(com.aibhai.app.core.Net.online(activity))
        private set
    val eco: Boolean
        get() {
            tick
            return com.aibhai.app.core.Eco.active(activity)
        }
    private val pending = ArrayList<String>()
    var lectureOn by mutableStateOf(false)
        private set
    var lectureText by mutableStateOf("")
        private set
    var pinRequest by mutableStateOf(false)
    private var lastWasVoice = false
    private val stopWords = Regex("^(bas|bas karo|band karo|stop|thank you|thanks|shukriya|bye|ruk jao|बस|बंद करो)\\b", RegexOption.IGNORE_CASE)
    private val netCb = object : android.net.ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: android.net.Network) {
            activity.runOnUiThread { onNetworkChange() }
        }

        override fun onLost(network: android.net.Network) {
            activity.runOnUiThread { onNetworkChange() }
        }

        override fun onCapabilitiesChanged(network: android.net.Network, caps: android.net.NetworkCapabilities) {
            activity.runOnUiThread { onNetworkChange() }
        }
    }

    init {
        try {
            activity.getSystemService(android.net.ConnectivityManager::class.java)?.registerDefaultNetworkCallback(netCb)
        } catch (e: Exception) {
        }
    }

    private fun onNetworkChange() {
        val now = com.aibhai.app.core.Net.online(activity)
        val cameBack = now && !online
        online = now
        if (cameBack && pending.isNotEmpty()) {
            val todo = pending.toList()
            pending.clear()
            messages.add(ChatItem.Bot(Reply("🌐 Internet aa gaya! Pending ${todo.size} kaam kar raha hoon…", speak = null, kind = Kind.SUCCESS), ""))
            activity.lifecycleScope.launch {
                for (t in todo) {
                    val (heard, reply) = brain.handle(listOf(t))
                    messages.add(ChatItem.Bot(reply, heard))
                    speakReply(reply)
                }
            }
        }
    }

    val setupMissing: Int
        get() {
            tick
            return Perms.missingCount(activity)
        }

    private val env = Env(activity, prefs, askPerms, hideUi = { activity.moveTaskToBack(true) }, authGate = { reason -> authGate(reason) })
    private val brain = Brain(env)
    private val speech = SpeechInput(activity, this)
    val voice = VoiceOutput(activity.applicationContext, prefs)
    private var job: Job? = null
    private var pendingListen = false

    fun toggleListening() {
        if (lectureOn) {
            stopLecture()
            return
        }
        when (status) {
            Status.LISTENING -> stopListening()
            Status.SPEAKING -> {
                voice.stop()
                job?.cancel()
                status = Status.IDLE
                startListening()
            }
            else -> startListening()
        }
    }

    fun startListening() {
        if (!Perms.mic(activity)) {
            pendingListen = true
            askPerms(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        voice.stop()
        partial = ""
        status = Status.LISTENING
        speech.start(prefs.listenLang, prefs.preferOffline || !com.aibhai.app.core.Net.online(activity))
    }

    fun onPermissionsResult() {
        tick++
        if (pendingListen) {
            pendingListen = false
            if (Perms.mic(activity)) startListening()
        }
    }

    fun stopListening() {
        speech.stop()
        rms = 0f
    }

    fun cancelAll() {
        speech.destroy()
        voice.stop()
        if (status == Status.LISTENING || status == Status.SPEAKING) status = Status.IDLE
        rms = 0f
    }

    override fun onReady() {}
    override fun onRms(v: Float) {
        rms = v
    }

    override fun onPartial(t: String) {
        partial = t
    }

    override fun onResults(list: List<String>) {
        rms = 0f
        partial = ""
        if (lectureOn) {
            val t = list.firstOrNull().orEmpty()
            if (Regex("lecture (band|stop|khatam)|stop lecture|लेक्चर बंद", RegexOption.IGNORE_CASE).containsMatchIn(t)) {
                stopLecture()
            } else {
                if (t.isNotBlank()) lectureText = (lectureText + " " + t.trim() + ".").trim()
                speech.start(prefs.listenLang, prefs.preferOffline || !online)
            }
            return
        }
        lastWasVoice = true
        // voice passphrase: unlock personal features for 5 minutes
        if (list.any { isPassphrase(it) }) {
            if (lockedOut()) return
            failCount = 0
            authUntil = System.currentTimeMillis() + 5 * 60_000L
            ActionLog.add(activity, "voice passphrase", "Security", "Unlocked by passphrase", "verified")
            if (pinRequest) {
                pinRequest = false
                showSecret()
            } else {
                val r = Reply("🔓 Pehchan liya! 5 minute ke liye personal features unlocked.", speak = "Pehchan liya. Bolo kya karna hai?", kind = Kind.SUCCESS, status = "verified")
                messages.add(ChatItem.Bot(r, ""))
                activity.lifecycleScope.launch { speakReply(r) }
            }
            return
        }
        process(list)
    }

    override fun onError(msg: String) {
        rms = 0f
        partial = ""
        if (lectureOn && !msg.contains("permission", true)) {
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({ if (lectureOn) speech.start(prefs.listenLang, prefs.preferOffline || !online) }, 300)
            return
        }
        status = Status.IDLE
        messages.add(ChatItem.Bot(Reply(msg, speak = null, kind = Kind.WARN), ""))
    }

    fun submitText(t: String) {
        if (t.isBlank()) return
        speech.destroy()
        lastWasVoice = false
        process(listOf(t))
    }

    private fun process(cands: List<String>) {
        job?.cancel()
        job = activity.lifecycleScope.launch {
            status = Status.THINKING
            val (heard, reply) = brain.handle(cands)
            voiceName = prefs.voice
            if (heard.isNotBlank()) messages.add(ChatItem.User(heard))
            if (reply.status == "queued" && heard.isNotBlank()) pending.add(heard)
            messages.add(ChatItem.Bot(reply, heard))
            speakReply(reply)
            when (reply.status) {
                "lecture_start" -> startLecture()
                "lecture_stop" -> stopLecture()
                "pin_required" -> requestSecretUnlock()
                else -> if (prefs.handsFree && lastWasVoice && !stopWords.containsMatchIn(heard.trim()) && !com.aibhai.app.core.Eco.active(activity)) startListening()
            }
        }
    }

    private suspend fun speakReply(r: Reply) {
        val s = r.speak
        if (prefs.speakReplies && !s.isNullOrBlank()) {
            status = Status.SPEAKING
            try {
                voice.speak(s, r.lang)
            } catch (e: Exception) {
            }
        }
        status = Status.IDLE
    }

    fun runAction(a: ReplyAction) {
        activity.lifecycleScope.launch {
            val r = try {
                a.run()
            } catch (e: Exception) {
                Reply("Error: ${e.message}", kind = Kind.ERROR)
            }
            if (r != null) {
                messages.add(ChatItem.Bot(r, ""))
                speakReply(r)
            }
        }
    }

    fun teach(heard: String, meaning: String) {
        val k = Txt.normalize(heard)
        val v = Txt.normalize(meaning)
        if (k.isBlank() || v.isBlank()) return
        prefs.addLearned(k, v)
        ActionLog.add(activity, heard, "Teach", "'$heard' = '$meaning'", "ok")
        messages.add(ChatItem.Bot(Reply("🧠 Seekh liya! Ab '$heard' = '$meaning'", kind = Kind.SUCCESS, speak = "Seekh liya!"), ""))
        process(listOf(meaning))
    }

    fun switchVoice() {
        setVoice(if (prefs.voice == "adam") "nidhi" else "adam")
    }

    fun setVoice(v: String) {
        prefs.voice = v
        voiceName = v
        testVoice()
    }

    fun testVoice() {
        job?.cancel()
        job = activity.lifecycleScope.launch {
            status = Status.SPEAKING
            val line = if (prefs.voice == "adam") "Ram Ram ${prefs.userName}! Main Adam, aapka AIBhai. Bolo kya kaam hai?"
            else "Namaste ${prefs.userName}! Main Nidhi, aapki AIBhai. Batao, kya karna hai?"
            voice.speak(line, "hi")
            status = Status.IDLE
        }
    }

    // ---------------- lecture mode
    private fun startLecture() {
        if (!Perms.mic(activity)) {
            askPerms(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        lectureText = ""
        lectureOn = true
        activity.window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        voice.stop()
        status = Status.LISTENING
        speech.start(prefs.listenLang, prefs.preferOffline || !online)
    }

    fun stopLecture() {
        if (!lectureOn) return
        lectureOn = false
        speech.destroy()
        activity.window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        status = Status.IDLE
        rms = 0f
        val text = lectureText.trim()
        if (text.isBlank()) {
            messages.add(ChatItem.Bot(Reply("🎧 Lecture mein kuch record nahi hua.", speak = null, kind = Kind.WARN), ""))
            return
        }
        val words = text.split(Regex("\\s+")).size
        val notes = com.aibhai.app.skills.ModeSkill.summarize(text)
        val file = try {
            com.aibhai.app.skills.OcrSkill.saveTxt(env, "LECTURE NOTES\n\n" + notes.joinToString("\n") + "\n\nFULL TRANSCRIPT\n" + text)
        } catch (e: Exception) {
            null
        }
        ActionLog.add(activity, "lecture", "Lecture", "$words words saved", if (file != null) "verified" else "failed")
        val r = Reply(
            "🎧 Lecture notes ready • $words words" + (file?.let { " • ${it.name}" } ?: ""),
            speak = "Lecture ke notes ban gaye. " + notes.drop(1).take(2).joinToString(". ").replace("⭐", ""),
            kind = Kind.FILES, items = notes, status = if (file != null) "verified" else "failed",
            actions = listOf(ReplyAction("📄 PDF") {
                val f = com.aibhai.app.skills.OcrSkill.makePdf(env, notes + listOf("", "Full transcript:") + text.split(Regex("(?<=[.?!।])\\s+")))
                if (f != null) {
                    com.aibhai.app.skills.FileSkill.openFile(env, f)
                    Reply("📄 PDF ban gayi: ${f.name}", kind = Kind.FILES, status = "verified")
                } else Reply("PDF nahi ban payi", kind = Kind.ERROR)
            })
        )
        messages.add(ChatItem.Bot(r, "lecture"))
        activity.lifecycleScope.launch { speakReply(r) }
    }

    // ---------------- security: keyguard + fingerprint/face + voice passphrase
    private var authUntil = 0L
    private var failCount = 0
    private var lockedUntil = 0L

    private fun lockedOut(): Boolean = System.currentTimeMillis() < lockedUntil

    suspend fun authGate(reason: String): Boolean {
        if (lockedOut()) return false
        val km = activity.getSystemService(android.app.KeyguardManager::class.java)
        if (km?.isKeyguardLocked == true) return dismissKeyguard()
        if (System.currentTimeMillis() < authUntil) return true
        if (!prefs.bioForPersonal) return true
        return biometric(reason)
    }

    private suspend fun dismissKeyguard(): Boolean = kotlinx.coroutines.suspendCancellableCoroutine { cont ->
        val done = java.util.concurrent.atomic.AtomicBoolean(false)
        fun finish(v: Boolean) {
            if (done.compareAndSet(false, true)) cont.resumeWith(Result.success(v))
        }
        val km = activity.getSystemService(android.app.KeyguardManager::class.java)
        if (km == null) {
            finish(true)
        } else {
            km.requestDismissKeyguard(activity, object : android.app.KeyguardManager.KeyguardDismissCallback() {
                override fun onDismissSucceeded() {
                    authUntil = System.currentTimeMillis() + 5 * 60_000L
                    finish(true)
                }

                override fun onDismissCancelled() = finish(false)
                override fun onDismissError() = finish(false)
            })
        }
    }

    suspend fun biometric(reason: String): Boolean = kotlinx.coroutines.suspendCancellableCoroutine { cont ->
        val done = java.util.concurrent.atomic.AtomicBoolean(false)
        fun finish(v: Boolean) {
            if (done.compareAndSet(false, true)) cont.resumeWith(Result.success(v))
        }
        val fa = activity as? androidx.fragment.app.FragmentActivity
        val auth = androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK or
            androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val can = androidx.biometric.BiometricManager.from(activity).canAuthenticate(auth)
        if (fa == null || can != androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS) {
            finish(true) // no screen lock set on phone → nothing to verify against
        } else {
            val prompt = androidx.biometric.BiometricPrompt(
                fa, androidx.core.content.ContextCompat.getMainExecutor(activity),
                object : androidx.biometric.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: androidx.biometric.BiometricPrompt.AuthenticationResult) {
                        authUntil = System.currentTimeMillis() + 5 * 60_000L
                        failCount = 0
                        ActionLog.add(activity, reason, "Security", "Fingerprint/face OK", "verified")
                        finish(true)
                    }

                    override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                        ActionLog.add(activity, reason, "Security", "Auth cancelled: $errString", "cancelled")
                        finish(false)
                    }
                }
            )
            prompt.authenticate(
                androidx.biometric.BiometricPrompt.PromptInfo.Builder()
                    .setTitle("AIBhai 🔒")
                    .setSubtitle(reason)
                    .setAllowedAuthenticators(auth)
                    .build()
            )
        }
    }

    private fun registerFail(what: String) {
        failCount++
        ActionLog.add(activity, what, "Security", "Wrong attempt $failCount/3", "failed")
        if (failCount >= 3) {
            lockedUntil = System.currentTimeMillis() + 5 * 60_000L
            failCount = 0
            ActionLog.add(activity, what, "Security", "Locked for 5 min after 3 wrong attempts", "failed")
            messages.add(ChatItem.Bot(Reply("🚫 3 galat koshish — AIBhai ke personal features 5 minute ke liye lock.", speak = "Teen galat koshish. Personal features paanch minute ke liye lock.", kind = Kind.ERROR, status = "failed"), ""))
        }
    }

    /** Spoken secret sentence check (not a voiceprint — anyone who knows the sentence can say it). */
    private fun isPassphrase(said: String): Boolean {
        val p = prefs.passphrase
        if (p.isBlank()) return false
        val a = Txt.simplify(Txt.normalize(said)).replace(" ", "")
        val b = Txt.simplify(Txt.normalize(p)).replace(" ", "")
        if (a.isBlank() || b.length < 6) return false
        return a == b || (b.length >= 10 && Txt.lev(a, b) <= 2)
    }

    private fun showSecret() {
        messages.add(ChatItem.Bot(com.aibhai.app.skills.SecretSkill.unlocked(env), ""))
        ActionLog.add(activity, "secret notes", "Secret", "Unlocked", "verified")
    }

    /** Called when SecretSkill asks for unlock: try fingerprint/face first, else PIN / passphrase dialog. */
    private fun requestSecretUnlock() {
        if (lockedOut()) {
            messages.add(ChatItem.Bot(Reply("🚫 Abhi lock hai, thodi der baad try karo.", speak = null, kind = Kind.ERROR), ""))
            return
        }
        activity.lifecycleScope.launch {
            val ok = if (System.currentTimeMillis() < authUntil) true else biometricOrNull()
            if (ok == true) showSecret() else pinRequest = true
        }
    }

    private suspend fun biometricOrNull(): Boolean? {
        val auth = androidx.biometric.BiometricManager.Authenticators.BIOMETRIC_WEAK or
            androidx.biometric.BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val can = androidx.biometric.BiometricManager.from(activity).canAuthenticate(auth)
        return if (can == androidx.biometric.BiometricManager.BIOMETRIC_SUCCESS) biometric("Secret notes kholne ke liye") else null
    }

    fun unlockSecret(pin: String) {
        pinRequest = false
        if (lockedOut()) {
            messages.add(ChatItem.Bot(Reply("🚫 Abhi lock hai, 5 minute baad try karo.", speak = null, kind = Kind.ERROR), ""))
            return
        }
        if ((pin.trim() == prefs.secretPin && pin.isNotBlank()) || isPassphrase(pin)) {
            failCount = 0
            authUntil = System.currentTimeMillis() + 5 * 60_000L
            showSecret()
        } else {
            messages.add(ChatItem.Bot(Reply("❌ Galat PIN / vakya", speak = "Galat", kind = Kind.ERROR), ""))
            registerFail("secret notes")
        }
    }

    private var checkedOnce = false

    /** New apps installed + AIBhai self-update check (runs on resume). */
    fun onResumeChecks() {
        val fresh = try {
            com.aibhai.app.skills.AppWatcher.newApps(activity)
        } catch (e: Exception) {
            emptyList()
        }
        if (fresh.isNotEmpty()) {
            messages.add(
                ChatItem.Bot(
                    Reply(
                        "📲 Naye apps mile: ${fresh.joinToString()}. Ab bas bolo \"${fresh.first()} kholo\" 😎",
                        speak = null, kind = Kind.INFO, items = fresh.map { "✨ $it" }
                    ), ""
                )
            )
        }
        if (checkedOnce) return
        checkedOnce = true
        try {
            com.aibhai.app.skills.ClassMode.schedule(activity)
            com.aibhai.app.skills.BatteryGuard.schedule(activity)
        } catch (e: Exception) {
        }
        activity.lifecycleScope.launch {
            val r = try {
                com.aibhai.app.skills.UpdateSkill.autoCheck(activity)
            } catch (e: Exception) {
                null
            }
            if (r != null) {
                val c = com.aibhai.app.core.Cmd("update", "update")
                messages.add(ChatItem.Bot(com.aibhai.app.skills.UpdateSkill.offer(c, env, r), ""))
            }
        }
    }

    fun destroy() {
        try {
            activity.getSystemService(android.net.ConnectivityManager::class.java)?.unregisterNetworkCallback(netCb)
        } catch (e: Exception) {
        }
        speech.destroy()
        voice.shutdown()
    }
}
