package com.aibhai.app.skills

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import com.aibhai.app.Prefs
import com.aibhai.app.core.Cmd
import com.aibhai.app.core.Env
import com.aibhai.app.core.Kind
import com.aibhai.app.core.Reply
import com.aibhai.app.core.ReplyAction
import com.aibhai.app.core.Skill
import com.aibhai.app.core.Subjects
import com.aibhai.app.core.Txt
import com.aibhai.app.system.Notifs
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

private fun keyWords(s: String): List<String> {
    val stop = setOf(
        "kya", "tha", "thi", "hai", "hain", "mera", "meri", "mere", "ka", "ki", "ke", "ko", "se", "me", "mein", "batao", "bata",
        "the", "is", "my", "what", "was", "where", "when", "kahan", "kab", "kaun", "kon", "yaad", "rakh", "rakho", "rakhna", "ki",
        "bhai", "please", "tha", "number", "no", "naam", "name"
    )
    return Txt.simplify(Txt.normalize(s)).split(' ').filter { it.length >= 2 && it !in stop.map { w -> Txt.simplify(w) } }
}

// =================================================================== MEMORY ("yaad rakh…")

object MemorySkill : Skill {
    private val save = Regex("^(?:bhai\\s+)?(?:yaa?d rakh(?:o|na|lo)?|remember(?: that)?|note kar lo|dimag mein rakh(?:o|lo)?)\\s+(?:ki\\s+|that\\s+)?(.+)$")
    private val forget = Regex("^(?:bhool jao|bhul jao|forget)\\s+(.+)$")
    private val askCue = arrayOf("kya tha", "kya hai", "kahan", "kab", "kaun", "kitna", "what is", "what was", "where", "when", "batao", "yaad hai")

    private fun load(env: Env) = try {
        JSONArray(env.prefs.facts)
    } catch (e: Exception) {
        JSONArray()
    }

    private fun best(env: Env, c: Cmd): Pair<Int, JSONObject>? {
        val a = load(env)
        val q = keyWords(c.norm)
        if (q.isEmpty()) return null
        var bi = -1
        var bs = 0.0
        for (i in 0 until a.length()) {
            val f = keyWords(a.getJSONObject(i).optString("t"))
            val hit = q.count { w -> f.any { Txt.tokenMatch(it, w) } }
            val s = hit.toDouble() / q.size
            if (s > bs) {
                bs = s; bi = i
            }
        }
        return if (bi >= 0 && bs >= 0.5) Pair(bi, a.getJSONObject(bi)) else null
    }

    override fun matches(c: Cmd, env: Env): Boolean {
        if (save.containsMatchIn(c.norm) && !c.has("matlab", "means")) return true
        if (forget.containsMatchIn(c.norm)) return best(env, c) != null
        return c.has(*askCue) && best(env, c) != null
    }

    override suspend fun run(c: Cmd, env: Env): Reply {
        val a = load(env)
        forget.find(c.norm)?.let {
            val b = best(env, c) ?: return c.reply("Aisa kuch yaad nahi tha.", "Nothing like that saved.")
            a.remove(b.first)
            env.prefs.facts = a.toString()
            return c.reply("🧹 Bhool gaya: ${b.second.optString("t")}", "🧹 Forgot: ${b.second.optString("t")}", kind = Kind.SUCCESS)
        }
        val m = save.find(c.norm)
        if (m != null && !c.has(*askCue.filter { it != "kya hai" }.toTypedArray())) {
            val fact = (if (Txt.hasDevanagari(c.raw)) c.raw.substringAfter(" ").trim() else m.groupValues[1]).replaceFirstChar { it.uppercase() }
            a.put(JSONObject().put("t", fact).put("m", System.currentTimeMillis()))
            env.prefs.facts = a.toString()
            return c.reply("🧠 Yaad rakh liya: $fact", "🧠 Remembered: $fact", speakHi = "Yaad rakh liya.", speakEn = "Got it, I'll remember.", kind = Kind.SUCCESS, status = "verified")
        }
        val b = best(env, c) ?: return c.reply("Ye mujhe yaad nahi. Bolo 'yaad rakh …'", "I don't remember that. Say 'remember …'", kind = Kind.WARN)
        val t = b.second.optString("t")
        return c.reply("🧠 $t", "🧠 $t", speakHi = t, speakEn = t)
    }
}

// =================================================================== FORMULA BANK (offline)

object FormulaSkill : Skill {
    data class F(val keys: List<String>, val name: String, val formula: String, val note: String)

    val bank = listOf(
        F(listOf("bernoulli"), "Bernoulli equation", "P + ½ρv² + ρgh = constant", "Ideal, incompressible, steady flow along a streamline"),
        F(listOf("continuity"), "Continuity equation", "A₁v₁ = A₂v₂", "Incompressible flow — area × velocity constant"),
        F(listOf("stress"), "Stress", "σ = F / A  (N/mm² = MPa)", "A = πd²/4 for a round rod"),
        F(listOf("strain"), "Strain", "ε = ΔL / L", "Dimensionless"),
        F(listOf("young", "youngs modulus", "elastic modulus"), "Young's modulus", "E = σ / ε", "Steel ≈ 200 GPa"),
        F(listOf("hooke"), "Hooke's law", "σ = E·ε  (spring: F = k·x)", "Within elastic limit"),
        F(listOf("torque"), "Torque", "T = F × r ;  P = 2πNT / 60", "N in rpm, P in W, T in N·m"),
        F(listOf("power"), "Power", "P = W / t = F·v ;  P = V·I", "1 hp = 746 W"),
        F(listOf("kinetic energy", "ke"), "Kinetic energy", "KE = ½mv²", ""),
        F(listOf("potential energy", "pe"), "Potential energy", "PE = mgh", "g = 9.81 m/s²"),
        F(listOf("newton second", "second law", "force"), "Newton's 2nd law", "F = m·a", ""),
        F(listOf("momentum"), "Momentum", "p = m·v ;  Impulse = F·t = Δp", ""),
        F(listOf("efficiency"), "Efficiency", "η = Output / Input × 100%", ""),
        F(listOf("ohm"), "Ohm's law", "V = I·R", ""),
        F(listOf("kvl", "kirchhoff voltage"), "KVL", "ΣV = 0 around any closed loop", ""),
        F(listOf("kcl", "kirchhoff current"), "KCL", "ΣI in = ΣI out at a node", ""),
        F(listOf("series resistance", "series"), "Resistors in series", "R = R₁ + R₂ + …", ""),
        F(listOf("parallel resistance", "parallel"), "Resistors in parallel", "1/R = 1/R₁ + 1/R₂ + …", ""),
        F(listOf("ac power", "power factor"), "AC power", "P = V·I·cosφ ;  S = V·I ;  Q = V·I·sinφ", "cosφ = power factor"),
        F(listOf("rms"), "RMS value", "V_rms = V_max / √2", "Sinusoidal AC"),
        F(listOf("transformer"), "Transformer", "V₁/V₂ = N₁/N₂ = I₂/I₁", "Ideal transformer"),
        F(listOf("capacitor energy", "capacitance"), "Capacitor", "Q = C·V ;  E = ½CV²", ""),
        F(listOf("inductor"), "Inductor", "V = L·di/dt ;  E = ½LI²", ""),
        F(listOf("ev range", "range"), "EV range", "Range (km) = Battery (Wh) / Consumption (Wh/km)", "2-wheeler ≈ 25–40 Wh/km"),
        F(listOf("battery energy", "battery capacity", "kwh"), "Battery energy", "E (Wh) = V × Ah", "48 V × 30 Ah = 1.44 kWh"),
        F(listOf("charging time"), "Charging time", "t (h) ≈ Battery kWh / Charger kW × 1.1", "×1.1 for losses"),
        F(listOf("quadratic"), "Quadratic formula", "x = (−b ± √(b²−4ac)) / 2a", ""),
        F(listOf("derivative", "differentiation"), "Basic derivatives", "d/dx xⁿ = n·xⁿ⁻¹ ; d/dx sin x = cos x ; d/dx eˣ = eˣ ; d/dx ln x = 1/x", ""),
        F(listOf("integration", "integral"), "Basic integrals", "∫xⁿ dx = xⁿ⁺¹/(n+1) ; ∫sin x = −cos x ; ∫eˣ = eˣ ; ∫1/x = ln|x|", "+ C"),
        F(listOf("trigonometry", "trig", "sin cos"), "Trig identities", "sin²θ + cos²θ = 1 ; sin2θ = 2sinθcosθ ; cos2θ = cos²θ − sin²θ", ""),
        F(listOf("matrix", "determinant"), "2×2 determinant", "|A| = ad − bc", "Inverse = (1/|A|)·adj(A)"),
        F(listOf("area circle", "circle"), "Circle", "Area = πr² ; Circumference = 2πr", ""),
        F(listOf("volume cylinder", "cylinder"), "Cylinder", "V = πr²h ; CSA = 2πrh", ""),
        F(listOf("thermal efficiency", "carnot"), "Carnot efficiency", "η = 1 − T_L / T_H  (Kelvin)", ""),
        F(listOf("ideal gas", "gas law"), "Ideal gas law", "PV = nRT ;  PV = mRT", "R = 8.314 J/mol·K"),
        F(listOf("heat"), "Heat", "Q = m·c·ΔT", "Water c = 4186 J/kg·K"),
        F(listOf("first law", "thermodynamics"), "1st law of thermodynamics", "Q − W = ΔU", ""),
        F(listOf("gear ratio", "gear"), "Gear ratio", "GR = N_driven / N_driver = ω_driver / ω_driven", ""),
        F(listOf("scale", "drawing scale"), "Drawing scale (EGD)", "RF = Drawing size / Actual size", "Full 1:1, reducing 1:2, enlarging 2:1")
    )

    override fun matches(c: Cmd, env: Env) = c.has("formula", "formulas", "equation", "sutra", "identity", "identities", "law")

    override suspend fun run(c: Cmd, env: Env): Reply {
        val hits = bank.filter { f -> f.keys.any { c.has(it) } }.take(4)
        if (hits.isEmpty()) {
            return c.reply(
                "Ye formula abhi bank mein nahi hai. Bolo: Bernoulli, stress, torque, Ohm, KVL, transformer, EV range, quadratic, integration…",
                "Not in my formula bank yet. Try: Bernoulli, stress, torque, Ohm, KVL, EV range…",
                kind = Kind.WARN, teachable = true
            )
        }
        val f = hits.first()
        return c.reply(
            "📐 ${f.name}: ${f.formula}", "📐 ${f.name}: ${f.formula}",
            speakHi = "${f.name}: ${f.formula.replace("²", " square").replace("½", "half").replace("ρ", "rho").replace("σ", "sigma").replace("π", "pi")}",
            speakEn = "${f.name}: ${f.formula.replace("²", " squared").replace("½", "half").replace("ρ", "rho").replace("σ", "sigma").replace("π", "pi")}",
            kind = Kind.SUCCESS,
            items = hits.flatMap { listOfNotNull("📐 ${it.name}: ${it.formula}", it.note.takeIf { n -> n.isNotBlank() }?.let { n -> "   💡 $n" }) }
        )
    }
}

// =================================================================== QUIZ (offline MCQ with buttons)

object QuizSkill : Skill {
    data class Q(val subject: String, val q: String, val opts: List<String>, val ans: Int, val why: String)

    private val bank = listOf(
        Q("Maths", "d/dx (x³) = ?", listOf("3x²", "x²", "3x", "x⁴/4"), 0, "Power rule: n·xⁿ⁻¹"),
        Q("Maths", "∫ cos x dx = ?", listOf("−sin x", "sin x", "tan x", "−cos x"), 1, "Derivative of sin x is cos x"),
        Q("Maths", "|A| of [[2,3],[1,4]] = ?", listOf("5", "11", "8", "−5"), 0, "ad − bc = 8 − 3 = 5"),
        Q("Maths", "sin²θ + cos²θ = ?", listOf("0", "2", "1", "tanθ"), 2, "Basic identity"),
        Q("Maths", "lim(x→0) sin x / x = ?", listOf("0", "∞", "1", "Not defined"), 2, "Standard limit"),
        Q("BEEE", "Ohm's law is:", listOf("V = I/R", "V = I·R", "I = V·R", "P = V/R"), 1, "V = IR"),
        Q("BEEE", "Unit of inductance?", listOf("Farad", "Ohm", "Henry", "Tesla"), 2, "L in Henry"),
        Q("BEEE", "KCL is based on conservation of:", listOf("Energy", "Charge", "Momentum", "Power"), 1, "Current in = current out"),
        Q("BEEE", "V_rms of 230 V AC peak value ≈ ?", listOf("163 V", "325 V", "230 V", "460 V"), 1, "V_max = 230 × √2 ≈ 325 V"),
        Q("BEEE", "Two 10 Ω resistors in parallel = ?", listOf("20 Ω", "10 Ω", "5 Ω", "2 Ω"), 2, "R/2 = 5 Ω"),
        Q("BEEE", "A diode allows current in:", listOf("Both directions", "One direction", "No direction", "Only AC"), 1, "Forward bias only"),
        Q("EGD", "In first angle projection, top view is placed:", listOf("Above front view", "Below front view", "Left of FV", "Right of FV"), 1, "1st angle: TV below FV"),
        Q("EGD", "Scale 1:2 is a:", listOf("Full scale", "Enlarging scale", "Reducing scale", "Diagonal scale"), 2, "Drawing is half of actual"),
        Q("EGD", "Isometric axes are inclined at:", listOf("90°", "45°", "120° to each other", "60° to each other"), 2, "Three axes 120° apart"),
        Q("EGD", "Hidden edges are shown by:", listOf("Thick line", "Dashed line", "Chain line", "Wavy line"), 1, "Dashed (hidden) lines"),
        Q("Mechanics", "SI unit of stress?", listOf("N", "N/m²", "J", "W"), 1, "Pascal = N/m²"),
        Q("Mechanics", "Bernoulli's equation is based on conservation of:", listOf("Mass", "Momentum", "Energy", "Charge"), 2, "Energy per unit volume"),
        Q("Mechanics", "1 hp ≈ ?", listOf("746 W", "1000 W", "550 W", "100 W"), 0, "Mechanical horsepower"),
        Q("EV", "Battery 48 V × 30 Ah = ?", listOf("1.44 kWh", "14.4 kWh", "0.78 kWh", "144 Wh"), 0, "48 × 30 = 1440 Wh"),
        Q("EV", "Most common EV battery chemistry today:", listOf("Lead-acid", "Lithium-ion", "NiCd", "Alkaline"), 1, "Li-ion (NMC/LFP)"),
        Q("EV", "LFP stands for:", listOf("Lithium Iron Phosphate", "Lithium Ferro Plastic", "Lead Fluoro Phosphate", "Lithium Fast Power"), 0, "LiFePO₄"),
        Q("EV", "BMS mainly does:", listOf("Motor cooling", "Battery monitoring & protection", "Braking", "Navigation"), 1, "Cell voltage, temp, SOC, balancing"),
        Q("EV", "Regenerative braking converts:", listOf("Heat to electricity", "Kinetic energy to electrical", "Electrical to kinetic", "Light to heat"), 1, "Motor acts as generator")
    )

    override fun matches(c: Cmd, env: Env) = c.has("quiz", "mcq", "test lo", "sawal pucho", "sawal poocho", "question pucho", "quiz lo", "practice question")

    private fun score(env: Env): JSONObject = try {
        JSONObject(env.prefs.quizScore)
    } catch (e: Exception) {
        JSONObject()
    }

    fun ask(c: Cmd, env: Env, subject: String?): Reply {
        val pool = bank.filter { subject == null || it.subject == subject }.ifEmpty { bank }
        val q = pool.random()
        val letters = listOf("A", "B", "C", "D")
        return c.reply(
            "❓ [${q.subject}] ${q.q}", "❓ [${q.subject}] ${q.q}",
            speakHi = "${q.subject} ka sawal: ${q.q}. " + q.opts.mapIndexed { i, o -> "${letters[i]}: $o" }.joinToString(". "),
            speakEn = "${q.subject} question: ${q.q}",
            kind = Kind.INFO,
            items = q.opts.mapIndexed { i, o -> "${letters[i]}. $o" },
            actions = q.opts.mapIndexed { i, o ->
                ReplyAction("${letters[i]}. ${Txt.short(o, 18)}") {
                    val s = score(env)
                    val right = i == q.ans
                    s.put("total", s.optInt("total") + 1)
                    if (right) s.put("right", s.optInt("right") + 1)
                    env.prefs.quizScore = s.toString()
                    val sc = "${s.optInt("right")}/${s.optInt("total")}"
                    c.reply(
                        (if (right) "✅ Sahi jawab! " else "❌ Galat. Sahi: ${letters[q.ans]}. ${q.opts[q.ans]}. ") + "💡 ${q.why}  •  Score $sc",
                        (if (right) "✅ Correct! " else "❌ Wrong. Answer: ${letters[q.ans]}. ${q.opts[q.ans]}. ") + "💡 ${q.why}  •  Score $sc",
                        speakHi = if (right) "Shabash, sahi jawab!" else "Galat, sahi jawab hai ${q.opts[q.ans]}",
                        speakEn = if (right) "Correct!" else "Wrong, the answer is ${q.opts[q.ans]}",
                        kind = if (right) Kind.SUCCESS else Kind.WARN,
                        actions = listOf(ReplyAction(c.t("➡️ Agla sawal", "➡️ Next")) { ask(c, env, subject) })
                    )
                }
            }
        )
    }

    override suspend fun run(c: Cmd, env: Env): Reply = ask(c, env, Subjects.detect(c.s))
}

// =================================================================== EXAM COUNTDOWN

object ExamSkill : Skill {
    private val months = linkedMapOf(
        "january" to 0, "janvari" to 0, "jan" to 0, "february" to 1, "farvari" to 1, "feb" to 1, "march" to 2, "mar" to 2,
        "april" to 3, "aprail" to 3, "apr" to 3, "may" to 4, "mai" to 4, "june" to 5, "joon" to 5, "jun" to 5, "july" to 6, "julai" to 6, "jul" to 6,
        "august" to 7, "agast" to 7, "aug" to 7, "september" to 8, "sitambar" to 8, "sep" to 8, "sept" to 8, "october" to 9, "aktubar" to 9, "oct" to 9,
        "november" to 10, "navambar" to 10, "nov" to 10, "december" to 11, "disambar" to 11, "dec" to 11
    )
    private val dateRe = Regex("(\\d{1,2})\\s*(?:st|nd|rd|th)?\\s*(" + months.keys.joinToString("|") + ")\\b")
    private val examWords = arrayOf("exam", "exams", "paper", "mid sem", "midsem", "end sem", "endsem", "viva", "practical", "sessional", "test")

    override fun matches(c: Cmd, env: Env) = c.has(*examWords) &&
        (dateRe.containsMatchIn(c.norm) || c.has("kitne din", "kab hai", "countdown", "bache", "how many days", "when is", "kab"))

    private fun load(env: Env) = try {
        JSONArray(env.prefs.exams)
    } catch (e: Exception) {
        JSONArray()
    }

    private fun days(ts: Long): Long = ((ts - startOfToday()) / 86400_000L)

    override suspend fun run(c: Cmd, env: Env): Reply {
        val a = load(env)
        val m = dateRe.find(c.norm)
        if (m != null) {
            val day = m.groupValues[1].toInt()
            val mon = months[m.groupValues[2]] ?: 0
            val cal = Calendar.getInstance().apply {
                set(Calendar.MONTH, mon); set(Calendar.DAY_OF_MONTH, day)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                if (timeInMillis < startOfToday()) add(Calendar.YEAR, 1)
            }
            val name = (Subjects.detect(c.s)?.let { "$it " } ?: "") +
                (listOf("mid sem", "midsem", "end sem", "endsem", "viva", "practical", "sessional").firstOrNull { c.has(it) } ?: "exam")
            a.put(JSONObject().put("n", name.trim().replaceFirstChar { it.uppercase() }).put("d", cal.timeInMillis))
            env.prefs.exams = a.toString()
            val d = days(cal.timeInMillis)
            return c.reply("📅 ${name.trim()} set: $day ${m.groupValues[2]} • $d din bache", "📅 ${name.trim()} saved • $d days left", kind = Kind.SUCCESS, status = "verified")
        }
        val list = (0 until a.length()).map { a.getJSONObject(it) }.filter { days(it.optLong("d")) >= 0 }.sortedBy { it.optLong("d") }
        if (list.isEmpty()) return c.reply("Koi exam date save nahi hai. Bolo: 'Maths mid sem 20 november ko hai'", "No exams saved. Say: 'Maths mid sem on 20 November'", kind = Kind.INFO)
        val first = list.first()
        val d0 = days(first.optLong("d"))
        return c.reply(
            "⏳ ${first.optString("n")}: $d0 din bache", "⏳ ${first.optString("n")}: $d0 days left",
            speakHi = "${first.optString("n")} mein $d0 din bache hain." + if (d0 <= 7) " Ab full focus!" else "",
            speakEn = "$d0 days left for ${first.optString("n")}.",
            kind = if (d0 <= 7) Kind.WARN else Kind.INFO,
            items = list.map { "📅 ${it.optString("n")} — ${days(it.optLong("d"))} din" }
        )
    }
}

// =================================================================== TIMETABLE (+ auto class-mode)

object TimetableSkill : Skill {
    data class Slot(val day: Int, val start: Int, val end: Int, val subject: String, val room: String)

    private val dayMap = linkedMapOf(
        "monday" to Calendar.MONDAY, "mon" to Calendar.MONDAY, "somvar" to Calendar.MONDAY,
        "tuesday" to Calendar.TUESDAY, "tue" to Calendar.TUESDAY, "mangalvar" to Calendar.TUESDAY,
        "wednesday" to Calendar.WEDNESDAY, "wed" to Calendar.WEDNESDAY, "budhvar" to Calendar.WEDNESDAY,
        "thursday" to Calendar.THURSDAY, "thu" to Calendar.THURSDAY, "guruvar" to Calendar.THURSDAY, "veervar" to Calendar.THURSDAY,
        "friday" to Calendar.FRIDAY, "fri" to Calendar.FRIDAY, "shukravar" to Calendar.FRIDAY,
        "saturday" to Calendar.SATURDAY, "sat" to Calendar.SATURDAY, "shanivar" to Calendar.SATURDAY,
        "sunday" to Calendar.SUNDAY, "sun" to Calendar.SUNDAY, "ravivar" to Calendar.SUNDAY
    )
    private val dayNames = mapOf(
        Calendar.MONDAY to "Mon", Calendar.TUESDAY to "Tue", Calendar.WEDNESDAY to "Wed", Calendar.THURSDAY to "Thu",
        Calendar.FRIDAY to "Fri", Calendar.SATURDAY to "Sat", Calendar.SUNDAY to "Sun"
    )

    private fun hm(s: String): Int? {
        val m = Regex("(\\d{1,2})(?:[:.](\\d{2}))?").find(s) ?: return null
        var h = m.groupValues[1].toInt()
        val mm = m.groupValues[2].toIntOrNull() ?: 0
        if (h in 1..6) h += 12 // college hours: 1–6 means afternoon
        return h * 60 + mm
    }

    fun parse(text: String): List<Slot> = text.lines().mapNotNull { line ->
        val t = Txt.normalize(line)
        if (t.isBlank()) return@mapNotNull null
        val day = dayMap.entries.firstOrNull { (k, _) -> Regex("\\b$k\\b").containsMatchIn(t) }?.value ?: return@mapNotNull null
        val times = Regex("\\d{1,2}(?:[:.]\\d{2})?").findAll(t).map { it.value }.toList()
        val start = times.getOrNull(0)?.let { hm(it) } ?: return@mapNotNull null
        val end = times.getOrNull(1)?.takeIf { it.contains(':') || it.contains('.') }?.let { hm(it) }?.takeIf { it > start } ?: (start + 60)
        var rest = t
        dayMap.keys.forEach { rest = rest.replace(Regex("\\b$it\\b"), " ") }
        rest = rest.replace(Regex("\\d{1,2}(?:[:.]\\d{2})?"), " ").replace(Regex("\\b(baje|se|tak|to|am|pm|room|lab|class|lecture)\\b"), " ").replace(Regex("\\s+"), " ").trim()
        val room = Regex("\\b(?:room|lab)\\s*(\\w+)").find(t)?.groupValues?.get(1)
            ?: Regex("\\b(\\d{2,4}[a-z]?)$").find(t)?.groupValues?.get(1) ?: ""
        val subj = Subjects.detect(Txt.simplify(rest)) ?: rest.split(' ').firstOrNull()?.replaceFirstChar { it.uppercase() } ?: "Class"
        Slot(day, start, end, subj, room)
    }

    private fun fmt(min: Int): String {
        val h = min / 60
        val m = min % 60
        val h12 = if (h % 12 == 0) 12 else h % 12
        return "$h12:${m.toString().padStart(2, '0')} ${if (h < 12) "AM" else "PM"}"
    }

    fun slotsFor(env: Env, day: Int): List<Slot> = parse(env.prefs.timetable).filter { it.day == day }.sortedBy { it.start }

    override fun matches(c: Cmd, env: Env) = c.has("timetable", "time table", "agla lecture", "agli class", "next class", "next lecture",
        "aaj ki classes", "kal ki classes", "kaunsa lecture", "konsa lecture", "lecture kaunsa")

    override suspend fun run(c: Cmd, env: Env): Reply {
        if (c.has("add", "jodo", "daalo", "dalo") && c.has("timetable", "time table")) {
            val slot = parse(c.norm).firstOrNull()
                ?: return c.reply("Aise bolo: 'Timetable mein add karo Monday 9 baje Maths room 204'", "Say: 'Add to timetable Monday 9 Maths room 204'", kind = Kind.WARN, status = "needs_input")
            val line = "${dayNames[slot.day]} ${slot.start / 60}:${(slot.start % 60).toString().padStart(2, '0')} ${slot.end / 60}:${(slot.end % 60).toString().padStart(2, '0')} ${slot.subject} ${slot.room}".trim()
            env.prefs.timetable = (env.prefs.timetable.trim() + "\n" + line).trim()
            ClassMode.schedule(env.ctx)
            return c.reply("✅ Timetable mein add: $line", "✅ Added: $line", kind = Kind.SUCCESS, status = "verified")
        }
        if (parse(env.prefs.timetable).isEmpty()) {
            return c.reply(
                "📅 Timetable khaali hai. Settings → Timetable mein likho (har line: 'Mon 9:00 10:00 Maths 204') ya bolo 'timetable mein add karo Monday 9 baje Maths'.",
                "📅 Timetable is empty. Add it in Settings → Timetable.",
                kind = Kind.WARN, status = "needs_input"
            )
        }
        val now = Calendar.getInstance()
        val nowMin = now.get(Calendar.HOUR_OF_DAY) * 60 + now.get(Calendar.MINUTE)
        val tomorrow = c.has("kal", "tomorrow")
        if (c.has("agla", "agli", "next")) {
            for (offset in 0..6) {
                val cal = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, offset) }
                val list = slotsFor(env, cal.get(Calendar.DAY_OF_WEEK)).filter { offset > 0 || it.start > nowMin }
                val s = list.firstOrNull() ?: continue
                val inMin = if (offset == 0) s.start - nowMin else -1
                val whenTxt = if (offset == 0) "$inMin minute mein (${fmt(s.start)})" else "${dayNames[s.day]} ${fmt(s.start)}"
                return c.reply(
                    "📚 Agla lecture: ${s.subject}${if (s.room.isNotBlank()) " • Room ${s.room}" else ""} • $whenTxt",
                    "📚 Next: ${s.subject}${if (s.room.isNotBlank()) " • Room ${s.room}" else ""} • $whenTxt",
                    kind = Kind.INFO
                )
            }
        }
        val cal = Calendar.getInstance().apply { if (tomorrow) add(Calendar.DAY_OF_MONTH, 1) }
        val list = slotsFor(env, cal.get(Calendar.DAY_OF_WEEK))
        if (list.isEmpty()) return c.reply("🎉 ${if (tomorrow) "Kal" else "Aaj"} koi class nahi!", "🎉 No classes ${if (tomorrow) "tomorrow" else "today"}!", kind = Kind.SUCCESS)
        return c.reply(
            "📅 ${if (tomorrow) "Kal" else "Aaj"} ki ${list.size} classes", "📅 ${list.size} classes ${if (tomorrow) "tomorrow" else "today"}",
            speakHi = "${if (tomorrow) "Kal" else "Aaj"} ${list.size} classes hain: " + list.joinToString(", ") { "${fmt(it.start)} ${it.subject}" },
            speakEn = "${list.size} classes: " + list.joinToString(", ") { "${fmt(it.start)} ${it.subject}" },
            items = list.map { "🕘 ${fmt(it.start)}–${fmt(it.end)}  ${it.subject}${if (it.room.isNotBlank()) "  • ${it.room}" else ""}" }
        )
    }
}

/** Puts phone in vibrate when a class starts, back to normal when it ends. */
object ClassMode {
    fun schedule(ctx: Context) {
        val prefs = Prefs(ctx)
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        // cancel old
        for (i in 0 until 120) {
            val pi = PendingIntent.getBroadcast(ctx, 9000 + i, Intent(ctx, ClassModeReceiver::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_NO_CREATE)
            if (pi != null) am.cancel(pi)
        }
        if (!prefs.autoSilent) return
        val slots = TimetableSkill.parse(prefs.timetable)
        if (slots.isEmpty()) return
        var idx = 0
        for (offset in 0..6) {
            val day = Calendar.getInstance().apply { add(Calendar.DAY_OF_MONTH, offset) }
            for (s in slots.filter { it.day == day.get(Calendar.DAY_OF_WEEK) }) {
                for ((mins, mode) in listOf(Pair(s.start, "vibrate"), Pair(s.end, "normal"))) {
                    val at = Calendar.getInstance().apply {
                        timeInMillis = day.timeInMillis
                        set(Calendar.HOUR_OF_DAY, mins / 60); set(Calendar.MINUTE, mins % 60); set(Calendar.SECOND, 0)
                    }.timeInMillis
                    if (at <= System.currentTimeMillis() || idx >= 120) continue
                    val pi = PendingIntent.getBroadcast(
                        ctx, 9000 + idx,
                        Intent(ctx, ClassModeReceiver::class.java).putExtra("mode", mode).putExtra("subject", s.subject),
                        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    )
                    am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
                    idx++
                }
            }
        }
    }
}

class ClassModeReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val mode = intent.getStringExtra("mode") ?: return
        val am = context.getSystemService(AudioManager::class.java) ?: return
        try {
            am.ringerMode = if (mode == "vibrate") AudioManager.RINGER_MODE_VIBRATE else AudioManager.RINGER_MODE_NORMAL
        } catch (e: Exception) {
        }
        if (mode == "vibrate") Notifs.show(context, "📚 ${intent.getStringExtra("subject")} class shuru", "Phone class mode (vibrate) pe daal diya.", 9500)
    }
}

// =================================================================== FOCUS MODE (Pomodoro + app blocker)

object FocusMode {
    val distracting = listOf(
        "instagram", "youtube", "facebook.katana", "snapchat", "twitter", "reddit", "moj", "josh", "takatak", "sharechat",
        "pubg", "tencent.ig", "freefire", "dts.freefire", "netflix", "hotstar", "primevideo", "tiktok", "mxplayer", "jio.media"
    )

    fun active(ctx: Context) = Prefs(ctx).focusUntil > System.currentTimeMillis()
    fun isDistracting(pkg: String) = distracting.any { pkg.contains(it) }
}

object FocusSkill : Skill {
    override fun matches(c: Cmd, env: Env) = c.has("focus mode", "focus", "pomodoro", "padhai mode", "study mode", "deep work")

    override suspend fun run(c: Cmd, env: Env): Reply {
        if (c.has("band", "off", "stop", "khatam", "hatao")) {
            env.prefs.focusUntil = 0
            return c.reply("🔓 Focus mode band. Achha kaam kiya! 👏", "🔓 Focus mode off. Great work! 👏", kind = Kind.SUCCESS)
        }
        val min = (TimeSkill.durationSec(TimeSkill.wordsToNum(c.norm)) / 60).toInt().takeIf { it > 0 } ?: 25
        val until = System.currentTimeMillis() + min * 60_000L
        env.prefs.focusUntil = until
        try {
            env.ctx.getSystemService(AudioManager::class.java)?.ringerMode = AudioManager.RINGER_MODE_VIBRATE
        } catch (e: Exception) {
        }
        val am = env.ctx.getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            env.ctx, 7777,
            Intent(env.ctx, com.aibhai.app.system.ReminderReceiver::class.java).putExtra("msg", "⏰ $min min focus poora! 5 minute break lo ☕").putExtra("id", 7777),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        am?.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, until, pi)
        val blocker = PhoneControl.enabled
        return c.reply(
            "🎯 Focus mode ON — $min minute. Phone vibrate pe.${if (blocker) " Reels/games khologe to main wapas bhej dunga 😄" else ""}",
            "🎯 Focus mode on — $min minutes.${if (blocker) " I'll block distracting apps." else ""}",
            speakHi = "$min minute ka focus shuru. All the best!", speakEn = "$min minute focus started. Good luck!",
            kind = Kind.SUCCESS,
            items = if (blocker) listOf("🚫 Block: Instagram, YouTube, Snapchat, games…") else listOf("💡 Apps block karne ke liye Settings → Phone control ON karo"),
            actions = listOf(ReplyAction(c.t("⏹ Band karo", "⏹ Stop")) {
                env.prefs.focusUntil = 0
                c.reply("🔓 Focus band", "🔓 Focus off")
            })
        )
    }
}
