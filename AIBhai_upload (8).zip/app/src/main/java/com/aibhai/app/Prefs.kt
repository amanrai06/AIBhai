package com.aibhai.app

import android.content.Context
import org.json.JSONObject

class Prefs(ctx: Context) {
    private val p = ctx.applicationContext.getSharedPreferences("aibhai", Context.MODE_PRIVATE)

    private fun str(k: String, d: String): String = p.getString(k, d) ?: d
    private fun put(k: String, v: String) {
        p.edit().putString(k, v).apply()
    }

    var userName: String
        get() = str("name", "Bhai")
        set(v) = put("name", v)

    var voice: String
        get() = str("voice", "adam")
        set(v) = put("voice", v)

    var elevenKey: String
        get() = str("eleven_key", "")
        set(v) = put("eleven_key", v.trim())

    var adamVoiceId: String
        get() = str("adam_id", DEFAULT_ADAM)
        set(v) = put("adam_id", v.trim())

    var nidhiVoiceId: String
        get() = str("nidhi_id", "")
        set(v) = put("nidhi_id", v.trim())

    var listenLang: String
        get() = str("lang", "hi-IN")
        set(v) = put("lang", v)

    var preferOffline: Boolean
        get() = p.getBoolean("offline", false)
        set(v) {
            p.edit().putBoolean("offline", v).apply()
        }

    var speakReplies: Boolean
        get() = p.getBoolean("speak", true)
        set(v) {
            p.edit().putBoolean("speak", v).apply()
        }

    var pcUrl: String
        get() = str("pc_url", "")
        set(v) = put("pc_url", v.trim())

    var pcModel: String
        get() = str("pc_model", "llama3.1")
        set(v) = put("pc_model", v.trim())

    var attendance: String
        get() = str("attendance", "{}")
        set(v) = put("attendance", v)

    var undo: String
        get() = str("undo", "[]")
        set(v) = put("undo", v)

    var reminders: String
        get() = str("reminders", "[]")
        set(v) = put("reminders", v)

    var tasks: String
        get() = str("tasks", "[]")
        set(v) = put("tasks", v)

    var newsAlerts: Boolean
        get() = p.getBoolean("news_alerts", true)
        set(v) {
            p.edit().putBoolean("news_alerts", v).apply()
        }

    /** Android/Google TTS voice names (free + unlimited). Blank = auto pick */
    var adamTts: String
        get() = str("adam_tts", "")
        set(v) = put("adam_tts", v)

    var nidhiTts: String
        get() = str("nidhi_tts", "")
        set(v) = put("nidhi_tts", v)

    var useEleven: Boolean
        get() = p.getBoolean("use_eleven", false)
        set(v) {
            p.edit().putBoolean("use_eleven", v).apply()
        }

    // College portal (e.g. Okie Dokie). Stored only on this phone.
    var portalUrl: String
        get() = str("portal_url", "")
        set(v) = put("portal_url", v.trim())

    var rollNo: String
        get() = str("roll_no", "")
        set(v) = put("roll_no", v.trim())

    var portalLastPage: String
        get() = str("portal_last", "")
        set(v) = put("portal_last", v)

    var portalCache: String
        get() = str("portal_cache", "{}")
        set(v) = put("portal_cache", v)

    // ---- v2 features
    /** lines like: Mon 09:00 10:00 Maths 204 */
    var timetable: String
        get() = str("timetable", "")
        set(v) = put("timetable", v)

    var autoSilent: Boolean
        get() = p.getBoolean("auto_silent", true)
        set(v) {
            p.edit().putBoolean("auto_silent", v).apply()
        }

    var batteryAlerts: Boolean
        get() = p.getBoolean("battery_alerts", true)
        set(v) {
            p.edit().putBoolean("battery_alerts", v).apply()
        }

    var announceCalls: Boolean
        get() = p.getBoolean("announce_calls", true)
        set(v) {
            p.edit().putBoolean("announce_calls", v).apply()
        }

    var handsFree: Boolean
        get() = p.getBoolean("hands_free", false)
        set(v) {
            p.edit().putBoolean("hands_free", v).apply()
        }

    var secretPin: String
        get() = str("secret_pin", "")
        set(v) = put("secret_pin", v.trim())

    var facts: String
        get() = str("facts", "[]")
        set(v) = put("facts", v)

    var exams: String
        get() = str("exams", "[]")
        set(v) = put("exams", v)

    var expenses: String
        get() = str("expenses", "[]")
        set(v) = put("expenses", v)

    var quizScore: String
        get() = str("quiz_score", "{}")
        set(v) = put("quiz_score", v)

    var focusUntil: Long
        get() = p.getLong("focus_until", 0L)
        set(v) {
            p.edit().putLong("focus_until", v).apply()
        }

    // ---- security
    var bioForPersonal: Boolean
        get() = p.getBoolean("bio_personal", false)
        set(v) {
            p.edit().putBoolean("bio_personal", v).apply()
        }

    /** spoken secret sentence (voice passphrase) */
    var passphrase: String
        get() = str("passphrase", "")
        set(v) = put("passphrase", v.trim())

    var ecoAuto: Boolean
        get() = p.getBoolean("eco_auto", true)
        set(v) {
            p.edit().putBoolean("eco_auto", v).apply()
        }

    var ecoForce: Boolean
        get() = p.getBoolean("eco_force", false)
        set(v) {
            p.edit().putBoolean("eco_force", v).apply()
        }

    var reminderSeq: Int
        get() = p.getInt("rem_seq", 100)
        set(v) {
            p.edit().putInt("rem_seq", v).apply()
        }

    fun learned(): Map<String, String> {
        val o = try {
            JSONObject(str("learned", "{}"))
        } catch (e: Exception) {
            JSONObject()
        }
        val m = LinkedHashMap<String, String>()
        val it = o.keys()
        while (it.hasNext()) {
            val k = it.next()
            m[k] = o.optString(k)
        }
        return m
    }

    fun addLearned(k: String, v: String) {
        val o = try {
            JSONObject(str("learned", "{}"))
        } catch (e: Exception) {
            JSONObject()
        }
        o.put(k, v)
        put("learned", o.toString())
    }

    fun clearLearned() = put("learned", "{}")

    companion object {
        const val DEFAULT_ADAM = "pNInz6obpgDQGcFmaJgB"
    }
}
