package com.aibhai.app.core

import com.aibhai.app.Prefs
import com.aibhai.app.skills.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

class Brain(private val env: Env) {
    private val skills: List<Skill> = listOf(
        TeachSkill, MemorySkill, NightSkill, GreetSkill, MistakeSkill, SecretSkill, ModeSkill, MessagesSkill, NewsSkill,
        BriefingSkill, DailyReportSkill, TaskSkill, QuizSkill, ExamSkill, FormulaSkill, TimetableSkill, PortalSkill,
        AttendanceSkill, FocusSkill, UpdateSkill, EngSkill, ExpenseSkill, CalcSkill, TimeSkill, OcrSkill, FileSkill,
        CallSkill, WhatsAppSkill, ScreenSkill, DisplaySkill, SettingsSkill, PhoneSkill, WebSkill, AppSkill
    )

    fun prepare(raw: String): Cmd {
        var n = Txt.normalize(raw)
        n = Txt.applyDialect(n)
        n = Txt.applyLearned(n, env.prefs.learned())
        return Cmd(raw, n)
    }

    private fun safeMatch(s: Skill, c: Cmd): Boolean = try {
        s.matches(c, env)
    } catch (e: Exception) {
        false
    }

    /** Personal data / actions: need phone unlock (and fingerprint if enabled) */
    private val personal: Set<Skill> = setOf(
        MessagesSkill, CallSkill, WhatsAppSkill, SecretSkill, FileSkill, PortalSkill, MemorySkill, ExpenseSkill,
        MistakeSkill, ScreenSkill, DailyReportSkill
    )

    private val splitRe = Regex("\\s+(?:aur phir|aur fir|phir|fir|uske baad|then|and then|फिर|और फिर|उसके बाद)\\s+", RegexOption.IGNORE_CASE)

    /** "Torch on karo phir 10 minute ka timer lagao phir mummy ko call karo" → runs all steps */
    private suspend fun multiStep(raw: String): Pair<String, Reply>? {
        val parts = raw.split(splitRe).map { it.trim() }.filter { it.isNotBlank() }
        if (parts.size < 2) return null
        val whole = prepare(raw)
        val wholeSkill = skills.firstOrNull { safeMatch(it, whole) }
        if (wholeSkill === TaskSkill || wholeSkill === MistakeSkill || wholeSkill === MemorySkill || wholeSkill === SecretSkill) return null
        val planned = parts.map { p ->
            val pc = prepare(p)
            Pair(pc, skills.firstOrNull { safeMatch(it, pc) })
        }
        if (planned.any { it.second == null }) return null
        val results = ArrayList<Reply>()
        if (planned.any { it.second in personal } && !env.authGate(whole.t("Multi-step personal kaam", "Personal actions"))) {
            return Pair(raw, whole.reply("🔒 Pehle unlock karo.", "🔒 Please unlock first.", kind = Kind.WARN, status = "cancelled"))
        }
        for ((pc, sk) in planned) {
            val r = try {
                sk!!.run(pc, env)
            } catch (e: Exception) {
                pc.reply("Step fail: ${e.message}", "Step failed: ${e.message}", kind = Kind.ERROR)
            }
            ActionLog.add(env.ctx, pc.raw, sk!!.javaClass.simpleName.removeSuffix("Skill"), r.text, ActionLog.statusFor(r))
            results.add(r)
            delay(500)
        }
        val ok = results.count { it.kind != Kind.ERROR && it.kind != Kind.WARN }
        val all = ok == results.size
        return Pair(
            raw, Reply(
                text = whole.t("🔗 ${results.size} kaam ek saath — $ok ho gaye", "🔗 ${results.size} steps — $ok done"),
                speak = results.mapNotNull { it.speak }.joinToString(". "),
                kind = if (all) Kind.SUCCESS else Kind.WARN,
                items = results.mapIndexed { i, r -> "${i + 1}. ${r.text}" },
                actions = results.flatMap { it.actions }.take(4),
                status = if (all) "verified" else "failed",
                lang = whole.lang
            )
        )
    }

    suspend fun handle(candidates: List<String>): Pair<String, Reply> {
        val cands = candidates.map { it.trim() }.filter { it.isNotEmpty() }.distinct()
        if (cands.isEmpty()) {
            return Pair("", Reply("Kuch suna nahi bhai, phir se bolo 🙂", kind = Kind.WARN))
        }
        multiStep(cands.first())?.let { return it }
        for (raw in cands) {
            val c = prepare(raw)
            val skill = skills.firstOrNull { safeMatch(it, c) }
            if (skill != null) {
                if ((skill === NewsSkill || skill === UpdateSkill) && !Net.online(env.ctx)) {
                    val cached = if (skill === NewsSkill) NewsSkill.offlineReply(c, env) else null
                    val q = c.reply(
                        "📴 Abhi internet nahi hai. Internet aate hi main ye khud kar dunga ✅",
                        "📴 No internet right now. I'll do this automatically when you're back online ✅",
                        kind = Kind.INFO, status = "queued"
                    )
                    ActionLog.add(env.ctx, raw, skill.javaClass.simpleName.removeSuffix("Skill"), "Queued (offline)", "queued")
                    return Pair(raw, cached?.copy(status = "queued") ?: q)
                }
                if (skill in personal && !env.authGate(c.t("Personal kaam: ${skill.javaClass.simpleName.removeSuffix("Skill")}", "Personal action"))) {
                    ActionLog.add(env.ctx, raw, skill.javaClass.simpleName.removeSuffix("Skill"), "Blocked: not unlocked", "cancelled")
                    return Pair(raw, c.reply("🔒 Ye personal kaam hai — pehle unlock/fingerprint karo.", "🔒 Personal action — please unlock first.", kind = Kind.WARN, status = "cancelled"))
                }
                val r = try {
                    skill.run(c, env)
                } catch (e: Exception) {
                    c.reply(
                        "Arre, kuch gadbad ho gayi: ${e.message ?: e.javaClass.simpleName}",
                        "Oops, something went wrong: ${e.message ?: e.javaClass.simpleName}",
                        kind = Kind.ERROR
                    )
                }
                ActionLog.add(env.ctx, raw, skill.javaClass.simpleName.removeSuffix("Skill"), r.text, ActionLog.statusFor(r))
                return Pair(raw, r)
            }
        }
        val first = cands.first()
        val c = prepare(first)
        val ai = PcBrain.ask(env.prefs, first, c.lang)
        if (ai != null) {
            ActionLog.add(env.ctx, first, "PC Brain", Txt.short(ai, 120), "ok")
            return Pair(first, Reply(ai, kind = Kind.INFO, teachable = true, lang = c.lang))
        }
        ActionLog.add(env.ctx, first, "-", "Samjha nahi", "unknown")
        val r = c.reply(
            "Ye abhi mujhe nahi aata 😅 'Sikhao' dabake mujhe sikha do, ya Google pe dhundh deta hoon.",
            "I don't know this one yet 😅 Tap 'Teach' to teach me, or I can search Google.",
            kind = Kind.WARN,
            teachable = true,
            actions = listOf(ReplyAction(c.t("Google pe dhundo", "Search Google")) {
                WebSkill.google(env, first)
                null
            })
        )
        return Pair(first, r)
    }
}

/** Optional: talks to Ollama running on your PC over home Wi-Fi (free, offline). */
object PcBrain {
    suspend fun ask(prefs: Prefs, question: String, lang: String): String? = withContext(Dispatchers.IO) {
        var base = prefs.pcUrl.trim().trimEnd('/')
        if (base.isBlank()) return@withContext null
        if (!base.startsWith("http")) base = "http://$base"
        if (!base.substringAfter("://").contains(':')) base = "$base:11434"
        try {
            val sys = if (lang == "en") {
                "You are AIBhai, a friendly personal assistant for ${prefs.userName}, an engineering student. Answer in short, clear English (max 4 lines)."
            } else {
                "Tum AIBhai ho, ${prefs.userName} ke dost jaise personal assistant. Wo engineering student hai. Hamesha Hinglish (Roman script) mein chhota, friendly jawab do, max 4 lines."
            }
            val body = JSONObject()
                .put("model", prefs.pcModel.ifBlank { "llama3.1" })
                .put("stream", false)
                .put(
                    "messages", JSONArray()
                        .put(JSONObject().put("role", "system").put("content", sys))
                        .put(JSONObject().put("role", "user").put("content", question))
                )
            val con = URL("$base/api/chat").openConnection() as HttpURLConnection
            con.requestMethod = "POST"
            con.connectTimeout = 4000
            con.readTimeout = 90000
            con.doOutput = true
            con.setRequestProperty("Content-Type", "application/json")
            con.outputStream.use { it.write(body.toString().toByteArray()) }
            if (con.responseCode != 200) return@withContext null
            val txt = con.inputStream.bufferedReader().use { it.readText() }
            JSONObject(txt).getJSONObject("message").getString("content").trim().ifBlank { null }
        } catch (e: Exception) {
            null
        }
    }
}
